<template>
  <teleport to="body">
    <CxlLoading :label :display="showLoading" :class="tsClass" :unLockScrollbar />
  </teleport>
</template>

<script setup>
import { ref, computed } from 'vue';
import CxlLoading from './CxlLoading.vue';

const props = defineProps({
  isTsMode: {
    type: Boolean,
    default: false,
  },
});

const tsClass = computed(() => (props.isTsMode ? 'cxl-loading-ts' : ''));

const showLoading = ref(false);

const label = ref('');
const unLockScrollbar = ref(false);
const open = (options) => {
  showLoading.value = true;
  label.value = options?.label || '載入中';
  if (options?.unLockScrollbar) {
    unLockScrollbar.value = true;
  }
};

const close = () => {
  showLoading.value = false;
};

defineExpose({ open, close });
</script>
