<!--
　參考來源：https://linmasahiro.github.io/vue3-datepicker-lite/dist/
-->
<template>
  <div class="cxl-calendar">
    <div class="relative-position">
      <input
        :id="idAttr"
        v-model="selectedValue"
        class="cxl-input"
        :class="{ error: error || innerError }"
        type="text"
        :name="nameAttr"
        :autocomplete="autocompleteAttr"
        :placeholder="placeholderAttr"
        :maxlength="maxLength"
        :disabled="disableAttr"
        @keypress="filterText"
      />
      <div v-if="error || innerError" role="alert" class="cxl-text-danger-bright">
        {{ innerErrorMessage || errorMessage }}
      </div>

      <button type="button" style="cursor: pointer" :disabled="disableAttr" @click="onFocusEvent">
        <span
          class="cub-icon-date_24 cxl-font-24 cxl-text-gray-a7"
          style="vertical-align: -0.2em"
        ></span>
      </button>
    </div>

    <div v-if="datepicker.show" class="cxl-calendar-picker__mask" @click="close"></div>

    <div
      v-if="datepicker.show"
      class="cxl-calendar-picker__frame"
      :class="{ 'cxl-calendar-picker__frame_up': needMoveToUp }"
    >
      <div class="cxl-calendar-picker__warp">
        <div class="cxl-calendar-picker__box">
          <div class="cxl-calendar-picker__header">
            <div class="cxl-calendar-picker__year">
              <select v-model="datepicker.year">
                <option v-for="year in datepicker.yearList" :key="year" :value="year">
                  {{ datepicker.yearCountWay === 'ROC' ? '民國' + (year - 1911) : '西元' + year }}年
                </option>
              </select>
            </div>
            <div class="cxl-calendar-picker__month">
              <select v-model="datepicker.month">
                <option v-for="mon in datepicker.monthList" :key="mon" :value="mon">
                  {{
                    `${modifiedLocale.months[mon - 1] + (/[a-z]/.test(modifiedLocale.months[mon - 1]) ? '' : '月')}`
                  }}
                </option>
              </select>
            </div>
            <!-- 上一個月 -->
            <div class="cxl-calendar-picker__nav--prev" @click="prevMonth">
              <span class="cub-icon-chevronleft_24 cxl-font-14" style="margin-right: -10px"></span>
              <span class="cub-icon-chevronleft_24 cxl-font-14"></span>
            </div>
            <!-- 下一個月 -->
            <div class="cxl-calendar-picker__nav--next" @click="nextMonth">
              <span class="cub-icon-chevronright_24 cxl-font-14"></span>
              <span class="cub-icon-chevronright_24 cxl-font-14" style="margin-left: -10px"></span>
            </div>
          </div>
          <table class="cxl-calendar-picker__table">
            <thead>
              <tr>
                <th
                  v-for="weekday in modifiedLocale.weekday"
                  :key="weekday"
                  class="cxl-calendar-picker__weekday"
                >
                  {{ weekday }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(dateRow, i) in datepicker.dayList" :key="`row${dateRow[i].dateString}`">
                <td v-for="date in dateRow" :key="date.dateString" role="presentation">
                  <div
                    class="cxl-calendar-picker__day"
                    :class="{
                      'cxl-calendar-picker__day--outfocus': date.month != datepicker.month,
                      'cxl-calendar-picker__day--infocus': date.month == datepicker.month,
                      'cxl-calendar-picker__day--today': date.isToday,
                      'cxl-calendar-picker__day--selected cxl-calendar-picker__day--highlighted':
                        selectedValue == date.dateString,
                    }"
                    @click="select(date.dateString)"
                  >
                    {{ date.day }}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div v-if="showBottomButton" class="cxl-calendar-picker__footer">
            <button
              v-if="modifiedLocale.todayBtn"
              class="cxl-calendar-picker__button--today"
              type="button"
              @click="selectToday"
            >
              {{ modifiedLocale.todayBtn }}
            </button>
            <button
              v-if="modifiedLocale.clearBtn"
              class="cxl-calendar-picker__button--clear"
              type="button"
              @click="clear"
            >
              {{ modifiedLocale.clearBtn }}
            </button>
            <button
              v-if="modifiedLocale.closeBtn"
              class="cxl-calendar-picker__button--close"
              type="button"
              @click="close"
            >
              {{ modifiedLocale.closeBtn }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive, watch } from 'vue';
import {
  regex,
  defaultLocale,
  yearCountDiff,
  getDatePickerDefault,
  parseDateString,
  parseDateObject,
  goNextMonth,
  goPrevMonth,
  getDateList,
  formatInput,
  isRocEmptyPattern,
} from './dateUtils/datePickerUtils.js';

const props = defineProps({
  // 參數：ID
  idAttr: {
    type: String,
    default: '',
  },
  // 參數：name
  nameAttr: {
    type: String,
    default: '',
  },
  // 參數：placeholder
  placeholderAttr: {
    type: String,
    default: '',
  },
  // 參數：autocomplete
  autocompleteAttr: {
    type: String,
    default: 'off',
  },
  // 日期選擇器顯示資料用(變數datepicker)
  yearCountWay: {
    type: String,
    default: 'AD',
  },
  // 調整小日曆年份下拉選單一次出現範圍
  yearsRange: {
    type: Number,
    default: 80,
  },
  // 在限定年份下 from date 數值
  from: {
    type: String,
    default: '',
  },
  // 在限定年份下 end date 數值
  to: {
    type: String,
    default: '',
  },
  // 在地化設定，預設值在變數modifiedLocale中的defaultLocale設定。
  locale: {
    type: Object,
    default: () => {},
  },
  excludeDays: {
    type: Object,
    default: () => {},
  },
  // 禁止 input
  disableAttr: {
    type: Boolean,
    default: false,
  },
  // 小日曆上是否出現今日、清除、關閉之按鈕
  showBottomButton: {
    type: Boolean,
    default: true,
  },
  error: {
    type: Boolean,
    default: false,
  },
  errorMessage: {
    type: String,
    default: '',
  },
});

const emits = defineEmits(['valueChanged', 'valueVaildate']);

const modifiedLocale = {
  ...defaultLocale,
  ...props.locale,
};

/**
 * 確認鍵入事件值之合法性
 * @param {string} event 輸入事件物件資料
 */
const filterText = (event) => {
  if (event && !isRocEmptyPattern(event.key)) {
    event.preventDefault();
  }
};

/**
 * 檢查設定的上下限值格式(YYYY/MM/DD)
 */
const checkDateUpperAndLowerLimits = () => {
  try {
    // from、to傳入格式應為YYYY/MM/DD，如格式錯誤不另外處理，
    const propsFrom = props.from;
    if (propsFrom && !regex.AD.test(propsFrom)) {
      throw new Error('日期下限(props.from)格式應為YYYY/MM/DD');
    }
    const propsTo = props.to;
    if (propsTo && !regex.AD.test(propsTo)) {
      throw new Error('日期上限(props.to)格式應為YYYY/MM/DD');
    }
  } catch (err) {
    throw ('catch:', err);
  }
};
checkDateUpperAndLowerLimits();

// 日期選擇器用資料物件
const datepicker = reactive({
  ...getDatePickerDefault(props),
  ...{
    yearList: computed(() => getDateList(datepicker, 'year')),
    monthList: computed(() => getDateList(datepicker, 'month')),
    dayList: computed(() => getDateList(datepicker, 'day')),
  },
});

/**
 * 上一個月按鈕
 */
const prevMonth = () => {
  const prevObj = goPrevMonth(datepicker);
  if (prevObj.goPrev) {
    datepicker.year = prevObj.nextYear;
    datepicker.month = prevObj.nextMonth;
  }
};

/**
 * 下一個月按鈕
 */
const nextMonth = () => {
  const nextObj = goNextMonth(datepicker);
  if (nextObj.goNext) {
    datepicker.year = nextObj.nextYear;
    datepicker.month = nextObj.nextMonth;
  }
};

const selectedValue = defineModel('valueAttr', {
  type: String,
  default: '',
});

/**
 * 點擊今天將內容改為今天日期
 */
const selectToday = () => {
  select(datepicker.today);
  datepicker.show = false;
};

/**
 * Value clear event
 */
const clear = () => {
  selectedValue.value = '';
  datepicker.show = false;
};

/**
 * Close datepicker event
 */
const close = () => {
  datepicker.show = false;
};

const innerError = ref(false);
const innerErrorMessage = ref('');

const maxLength = ref(yearCountDiff.row[datepicker.yearCountWay]);

/** 監聽父層傳入預設資料 */
watch(
  () => props.valueAttr,
  (value) => {
    // 空值 歸零
    if (value === '') {
      selectedValue.value = '';
      return;
    }
    if (value.length < maxLength.value) {
      return;
    }
    select(value);
  },
);

/**
 * 日期輸入資料檢核
 * @param {string} value 輸入的日期資料
 * @returns {boolean} 檢核結果
 */
const validDate = (value) => {
  const target = parseDateObject(value);
  // 當輸入內容 與日期格式不符時 日期格式有誤
  if (target === null) {
    innerError.value = true;
    innerErrorMessage.value = '日期格式有誤';
    emits('valueVaildate', innerErrorMessage.value);
    return false;
  }
  //日期低於有效範圍
  if (datepicker.from) {
    const lower = parseDateObject(datepicker.from);
    if (lower > target) {
      innerError.value = true;
      innerErrorMessage.value = '日期低於有效範圍';
      emits('valueVaildate', innerErrorMessage.value);
      return false;
    }
  }

  // 日期高於有效範圍
  if (datepicker.to) {
    const upper = parseDateObject(datepicker.to);
    if (upper < target) {
      innerError.value = true;
      innerErrorMessage.value = '日期高於有效範圍';
      emits('valueVaildate', innerErrorMessage.value);
      return false;
    }
  }

  // 去除特定星期
  if (datepicker.excludeDays.weekday.includes(target.getDay())) {
    innerError.value = true;
    innerErrorMessage.value = '日期不可被特定星期選取';
    emits('valueVaildate', innerErrorMessage.value);
    return false;
  }

  // 去除特定日期
  if (
    datepicker.excludeDays.days.length > 0 &&
    parseDateString(target, 'AD').includes(datepicker.excludeDays.days)
  ) {
    innerError.value = true;
    innerErrorMessage.value = '日期不可被特定日期選取';
    emits('valueVaildate', innerErrorMessage.value);
    return false;
  }
  emits('valueVaildate', '');
  return true;
};

// 初始化時設定預設直不觸發emit valueChanged
let dontSendEvent = true;

/**
 * 監聽: selectedValue
 * 計算方式提出來用
 */
watch(selectedValue, (value, prevValue) => {
  innerError.value = false;
  innerErrorMessage.value = '';

  // 空值
  if (!value) {
    return;
  }

  // 鍵入前置檢查
  // const searchText = value.indexOf(yearCountDiff.slash.text);
  // if (searchText != -1) {
  //   for (let index = 0; index < value.length; index++) {
  //     if (
  //       value[index] == yearCountDiff.slash.text &&
  //       !yearCountDiff.slash.offset[datepicker.yearCountWay].includes(index + 1)
  //     ) {
  //       selectedValue.value = prevValue;
  //     }
  //   }
  // }

  selectedValue.value = formatInput(value, prevValue, datepicker);
  // 檢核沒錯誤，且年份類型均正確時發出更新事件
  if (validDate(value) && regex[datepicker.yearCountWay].test(value)) {
    innerError.value = false;
    innerErrorMessage.value = '';
    if (dontSendEvent) {
      dontSendEvent = false;
      return;
    }
    emits('valueChanged', value);
  }
});

/**
 * 監聽datepicker.show
 */
watch(
  () => datepicker.show,
  (state) => {
    if (state) {
      if (selectedValue.value) {
        // 先確認是否是成形的日期字串
        const date = parseDateObject(selectedValue.value);
        if (date != null) {
          datepicker.year = date.getFullYear();
          datepicker.month = date.getMonth() + 1;
          return;
        }
        // 看是不是有輸入年份
        if (selectedValue.value.includes(yearCountDiff.slash.text)) {
          const part = selectedValue.value.split(yearCountDiff.slash.text);
          if (part.length === 2) {
            if (yearCountDiff.filed[datepicker.yearCountWay].year == part[0].length) {
              datepicker.year =
                datepicker.yearCountWay === 'ROC' ? Number(part[0]) + 1911 : Number(part[0]);
            }
          }
          if (part.length === 3) {
            if (yearCountDiff.filed[datepicker.yearCountWay].year == part[0].length) {
              datepicker.year =
                datepicker.yearCountWay === 'ROC' ? Number(part[0]) + 1911 : Number(part[0]);
            }
            if (yearCountDiff.filed[datepicker.yearCountWay].month == part[1].length) {
              datepicker.month = Number(part[1]);
            }
          }
          return;
        }
      }
      const today = parseDateObject(datepicker.today);
      const upper = parseDateObject(datepicker.to);
      // 用上限日期
      if (today > upper) {
        datepicker.year = upper.getFullYear();
        datepicker.month = upper.getMonth() + 1;
        return;
      }
      // 用今天日期
      datepicker.year = today.getFullYear();
      datepicker.month = today.getMonth() + 1;
    }
  },
);

/**
 * Modified datepicker position
 */
const needMoveToUp = ref(false);

/**
 * onFocusEvent
 * 開啟小月曆
 * @param {object} event 點擊事件資料物件
 */
const onFocusEvent = (event) => {
  const potisionY = event.target.getBoundingClientRect().y;
  // 元件位置高度至少要 290 才在上方顯示，避免高度不足(往上增長不會有scroll bar)
  needMoveToUp.value = potisionY >= 290 && window.innerHeight - potisionY <= 290;
  datepicker.show = true;
};

/**
 * 修改內容
 * @param {string} value 修改值
 */
const select = async (value) => {
  // 民國年轉譯
  const tmpValue = await parseDateString(parseDateObject(value), datepicker.yearCountWay);
  // 元件資料年份類型不對時，轉換西元/民國
  if (tmpValue && tmpValue !== selectedValue.value) {
    selectedValue.value = tmpValue;
  }
};

/** 設置初始化數值 */
select(props.valueAttr);
</script>
