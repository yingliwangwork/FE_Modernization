<template>
  <q-drawer
    v-model="myDrawer"
    class="cxl-sidebar"
    side="left"
    show-if-above
    :width="240"
    :breakpoint="991"
  >
    <q-scroll-area class="fit">
      <div v-if="props.sidebarTitle" class="cxl-sidebar-title">
        {{ props.sidebarTitle }}
      </div>
      <q-list class="menu-list cxl-nested-menu">
        <!-- 第一層選單 -->
        <template v-for="nav in props.navItems" :key="nav">
          <q-expansion-item
            v-if="checkRole(nav)"
            v-bind="realUrlHandle(nav)"
            :default-opened="setDefOpened(nav)"
            class="cxl-nested-menu-link"
          >
            <template #header>
              <q-item-section avatar>
                <template v-if="nav.iconType == 'quasar'">
                  <q-icon :name="nav.icon" class="cxl-font-28 self-center" />
                </template>
                <template v-else-if="nav.iconType == 'fontawesome'">
                  <FontAwesomeIcon :icon="nav.icon" class="cxl-font-18 self-center" />
                </template>
                <template v-else>
                  <span :class="nav.icon" class="cxl-font-32 self-center"></span>
                </template>
              </q-item-section>
              <q-item-section @click="refresh(nav.url)">{{ nav.label }}</q-item-section>
              <q-item-section v-if="nav.items && nav.items.length > 0" side>
                <span class="arrow-icon cxl-nested-menu-link-arrow-icon"></span>
              </q-item-section>
            </template>
            <!-- 第二層選單 -->
            <template v-if="nav.items">
              <template v-for="items in nav.items" :key="items">
                <q-expansion-item
                  v-if="checkRole(items)"
                  v-bind="realUrlHandle(items)"
                  :header-inset-level="1"
                  :default-opened="setDefOpened(items)"
                  header-style="padding-left: 64px"
                  class="cxl-nested-menu-content"
                  :active-class="!items.items ? 'active' : ''"
                >
                  <template #header>
                    <q-item-section @click="refresh(items.url)">{{ items.label }}</q-item-section>
                    <q-item-section v-if="items.items && items.items.length > 0" side>
                      <span class="arrow-icon cxl-nested-menu-content-arrow-icon"></span>
                    </q-item-section>
                  </template>
                  <!-- 第三層選單 -->
                  <template v-if="items.items">
                    <template v-for="nestedItems in items.items" :key="nestedItems">
                      <q-item
                        v-if="checkRole(nestedItems)"
                        v-bind="realUrlHandle(nestedItems)"
                        :active="selectedNav === nestedItems.url"
                        clickable
                        class="cxl-nested-menu-click"
                        active-class="active"
                      >
                        <q-item-section
                          style="padding-left: 40px"
                          @click="refresh(nestedItems.url)"
                        >
                          {{ nestedItems.label }}
                        </q-item-section>
                      </q-item>
                    </template>
                  </template>
                </q-expansion-item>
              </template>
            </template>
          </q-expansion-item>
        </template>
      </q-list>
    </q-scroll-area>
  </q-drawer>
</template>
<script setup>
import { ref, watch } from 'vue';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  sidebarTitle: {
    type: String,
    default: '',
  },
  navItems: {
    type: Array,
    default: () => [],
  },
  authRoles: {
    type: Array,
    default: () => [],
  },
  route: {
    type: Object,
    default: () => {
      console.warn('⚠ 匯入 vue-router 異常, 請在 CxlLayoutSidebar 傳入 :route="useRoute()"');
      return { path: '', name: '' };
    },
  },
});

// 目前選到哪一個選單 (側選單)
const selectedNav = ref(props.route.path);
watch(
  () => props.route.path,
  (nowObj) => {
    selectedNav.value = nowObj;
  },
);

const myDrawer = defineModel({
  type: Boolean,
  default: true,
});

const emit = defineEmits(['routerReload']);

/**
 *
 * @param toUrl
 */
const refresh = (toUrl) => {
  if (toUrl == props.route.path) {
    emit('routerReload');
  } else if (props.route.name == 'error') {
    emit('routerReload');
  }
};

/**
 *
 * @param navObj
 */
const realUrlHandle = (navObj) => {
  const targetAttr = {};
  if (!navObj.realURL) {
    targetAttr.to = !navObj.items ? navObj.url : '';
  } else {
    targetAttr.href = !navObj.items ? navObj.url : '';
    targetAttr.target = '_blank';
  }
  return targetAttr;
};

// TODO 待優化, setDefOpened 在 quasar 的元件上, 每次操作都會執行, 感覺效能不好
/**
 *
 * @param navObj
 */
const setDefOpened = (navObj) => {
  if (!navObj.items) {
    return false;
  }
  let needOpened = false;
  navObj.items.some((obj) => {
    if (obj.items) {
      needOpened = setDefOpened(obj);
      return needOpened;
    }
    if (obj.url === props.route.path && checkRole(obj)) {
      needOpened = true;
      return needOpened;
    }
    return false;
  });
  return needOpened;
};

/**
 * 判斷是否有權限顯示menu
 * @param {object} menu - 清單內容
 * @param {Array} menu.roles - 角色權限
 * @param {boolean} menu.hidden - 是否顯示
 * @param {boolean} menu.display - 是否顯示
 * @returns {boolean} 是否顯示此清單
 */
const checkRole = (menu) => {
  // 如果不顯示該選單則直接回傳false
  if (menu.display === false) {
    return false;
  }

  // 如果該使用者沒有設定權限, 則顯示該選單 (display判斷大於roles)
  const roles = menu.roles;
  if (!roles) {
    return true;
  }

  // 使用者無權限(或未登入)下，並roles(角色控制)存在, 則返回false
  if (!props.authRoles || props.authRoles.length <= 0) {
    return false;
  }

  // 有角色，且ALL_ROLE
  if (roles.length == 1 && roles[0] === 'ALL_ROLE') {
    return true;
  }

  let checked = false;
  props.authRoles.every((uRole) => {
    if (checked) {
      return false;
    }

    roles.every((mRole) => {
      if (uRole == mRole) {
        checked = true;
        return false;
      }
      return true;
    });
    return true;
  });

  return checked;
};
</script>
