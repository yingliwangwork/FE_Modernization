<template>
  <div>
    <q-stepper
      ref="stepper"
      v-model="currentStep"
      header-nav
      flat
      alternative-labels
      active-icon="none"
      class="cxl-stepper"
      @click="clickStep"
    >
      <q-step
        v-for="step in props.steps"
        :key="step"
        :name="step.counter"
        :title="step.title"
        :prefix="step.counter"
        :done="!!step.done"
        :error="!!step.edit"
        :disable="!!step.disable"
      />
    </q-stepper>

    <div class="row q-gutter-x-sm items-center cxl-stepper__actions">
      <slot>
        <CxlButton
          v-if="actions.check?.show"
          class="cxl-btn-ts"
          label="檢核"
          prevIcon="cxl-icon-filecheck-ts"
          stack
          :disable="actions.check?.disable"
          @click="$emit('stepCheck')"
        />
        <CxlButton
          v-if="actions.upload?.show"
          class="cxl-btn-ts"
          label="資料上傳"
          prevIcon="cxl-icon-upload-ts"
          stack
          :disable="actions.upload?.disable"
          @click="$emit('stepUpload')"
        />
        <CxlButton
          v-if="actions.view?.show"
          class="cxl-btn-ts"
          label="檢視"
          prevIcon="cxl-icon-eye-open-ts"
          stack
          :disable="actions.view?.disable"
          @click="$emit('stepView')"
        />
        <slot name="extra-actions"></slot>
      </slot>
    </div>
  </div>
</template>

<script setup>
import { ref, nextTick } from 'vue';
import CxlButton from './CxlButton.vue';

const currentStep = defineModel({
  type: Number,
  default: 1,
});

const props = defineProps({
  steps: {
    type: Array,
    default: () => [],
  },
  actions: {
    type: Object,
    default: () => ({
      // 檢核按鈕狀態
      check: { show: false, disable: false },
      // 資料上傳按鈕狀態
      upload: { show: false, disable: false },
      // 檢視按鈕狀態
      view: { show: false, disable: false },
    }),
  },
});

// 點擊步驟圈圈時，觸發的行為
const emit = defineEmits([
  'clickStep',
  'setStepErrorHandler',
  'stepCheck',
  'stepUpload',
  'stepView',
]);
const stepHistory = [currentStep.value];
/**
 * 直接點擊 stepper
 */
const clickStep = () => {
  // 為了想記錄上一步與當前步，若超出兩步則移除
  if (stepHistory.length >= 2) {
    stepHistory.shift();
  }

  // 紀錄下一步 (最多到兩步)
  stepHistory.push(currentStep.value);

  // 上一步的資料
  const previousStepData = props.steps.filter((step) => {
    return step.counter === stepHistory[0];
  })[0];
  emit('clickStep', previousStepData);
};

// 取得 stepper DOM
const stepper = ref(null);

/**
 * 下一步
 */
const nextStep = async () => {
  stepper.value.next();
  await nextTick();
  clickStep();
};

/**
 * 前一步
 */
const previousStep = async () => {
  stepper.value.previous();
  await nextTick();
  clickStep();
};

/**
 * 替換指定 step 的狀態
 * @param {number} step 指定步驟
 * @param {object} options 替換的物件
 * @param {string} options.title step 顯示文字
 * @param {boolean} options.edit 是否需 edit (顯示為黃色)
 * @param {boolean} options.done 是否已完成 (顯示為綠色勾)
 * @param {boolean} options.disable 是否為 disable
 */
const setStepStatus = (step, options) => {
  const stepData = props.steps.filter((data) => {
    return data.counter === step;
  })[0];

  // 步驟輸入錯誤, 故不更新, 觸發 setStepErrorHandler
  if (!stepData) {
    emit('setStepErrorHandler');
    return;
  }

  Object.assign(stepData, options);
};

// 暴露該元件的方法，以供外面使用
defineExpose({
  nextStep,
  previousStep,
  setStepStatus,
});
</script>
