<template>
  <q-dialog class="cxl-modal" :class="[sizeClass, statusClass]">
    <q-card>
      <q-bar>
        <q-space />
        <span
          v-if="!disableCloseButton"
          v-close-popup
          class="cub-icon-close_40_m cxl-font-40 cxl-text-gray-a7"
        ></span>
      </q-bar>
      <q-card-section v-if="props.title" class="column">
        <div class="cxl-modal-title">{{ props.title }}</div>
      </q-card-section>

      <q-card-section>
        <!-- 內容 -->
        <slot></slot>
      </q-card-section>
      <q-card-actions class="row justify-center">
        <slot name="bottom">
          <CxlButton padding="8px 54px" :label="props.closeText" @click="buttonClick()" />
        </slot>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { computed } from 'vue';
import CxlButton from './CxlButton.vue';

const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  closeText: {
    type: String,
    default: '關閉',
  },
  status: {
    type: String,
    default: '',
  },
  size: {
    type: String,
    default: 'sm',
  },
  disableCloseButton: {
    type: Boolean,
    default: false,
  },
});

const statusClass = computed(() => `cxl-modal-${props.status}`);

// modal 寬度
const sizeClass = computed(() => `cxl-modal-${props.size}`);

const emit = defineEmits(['buttonClick']);
/**
 *
 */
const buttonClick = () => {
  emit('buttonClick');
};
</script>
