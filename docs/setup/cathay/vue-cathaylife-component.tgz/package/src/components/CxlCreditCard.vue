<template>
  <div class="row items-center credit-card">
    <CxlInput
      ref="input1"
      v-model="numbers.first"
      :maxlength="maxLength"
      inputmode="numeric"
      mask="####"
      :inputStyle="inputStyle"
      :type="switchType(1)"
      :rules="[(val) => inputRules(val, 'first')]"
      :error="cardValidErr || errObj.first.length > 0"
      @update:modelValue="(value) => inputCheck(value, 'first', input2)"
    />
    <span class="q-mx-sm">-</span>
    <CxlInput
      ref="input2"
      v-model="numbers.second"
      :maxlength="maxLength"
      inputmode="numeric"
      mask="####"
      :inputStyle="inputStyle"
      :type="switchType(2)"
      :rules="[(val) => inputRules(val, 'second')]"
      :error="cardValidErr || errObj.second.length > 0"
      @update:modelValue="(value) => inputCheck(value, 'second', input3)"
    />
    <span class="q-mx-sm">-</span>
    <CxlInput
      ref="input3"
      v-model="numbers.third"
      :maxlength="maxLength"
      inputmode="numeric"
      mask="####"
      :inputStyle="inputStyle"
      :type="switchType(3)"
      :rules="[(val) => inputRules(val, 'third')]"
      :error="cardValidErr || errObj.third.length > 0"
      @update:modelValue="(value) => inputCheck(value, 'third', input4)"
    />
    <span class="q-mx-sm">-</span>
    <CxlInput
      ref="input4"
      v-model="numbers.fourth"
      :maxlength="maxLength"
      inputmode="numeric"
      mask="####"
      :inputStyle="inputStyle"
      :type="switchType(4)"
      :rules="[(val) => inputRules(val, 'fourth')]"
      :error="cardValidErr || errObj.fourth.length > 0"
      @update:modelValue="(value) => inputCheck(value, 'fourth')"
    />
    <span
      class="cxl-font-24 cxl-text-primary q-ml-sm"
      :class="isPwd ? 'cxl-icon-eye-close' : 'cxl-icon-eye-open'"
      @click="isPwd = !isPwd"
    ></span>
  </div>
  <p class="cxl-font-16 cxl-text-danger-bright q-mt-sm text-left">
    {{ errorMsg }}
  </p>
</template>

<script setup>
import { ref, reactive, computed } from 'vue';
import CxlInput from './CxlInput.vue';

// 各 input 的 ref, 用來做 focus 動作
const input1 = ref(null);
const input2 = ref(null);
const input3 = ref(null);
const input4 = ref(null);

const inputStyle = { width: '80px', textAlign: 'center' };

// 限制一欄輸入長度
const maxLength = ref(4);

//defineModel(版本限制vue3.4+) 同步父子組件變數值
//卡號
const numbers = defineModel('numbers', {
  type: Object,
  default: () => {
    return { first: '', second: '', third: '', fourth: '' };
  },
});

//卡號驗證結果
const cardValid = defineModel('cardValid', { type: Boolean, default: false });

const props = defineProps({
  // 閉眼時，哪個欄位要顯示
  fieldShow: {
    type: Number,
    default: 4,
  },
});

// 決定顯示開眼或閉眼
const isPwd = ref(true);

/**
 * 轉換是否為text / password
 * @param {number} index 目前呼叫此方法的 input index
 * @returns {string} input type
 */
const switchType = (index) => {
  if (index === props.fieldShow) {
    return 'text';
  }
  return isPwd.value ? 'password' : 'text';
};

/**
 * user輸入時檢查 並自動跳到下一輸入框
 * @param {*} value input值
 * @param {*} storeVal numbers 中的欄位
 * @param {*} nextEvent 下一組event 符合條件後focus到當下欄位
 */
const inputCheck = (value, storeVal, nextEvent) => {
  cardValid.value = false;
  numbers.value[storeVal] = value;
  if (value.length == maxLength.value && !!nextEvent?.$el) {
    nextEvent.$el.focus();
  }
};

const errorMsg = ref('');
//卡號未滿16位數不顯示cardValid結果
const cardValidErr = computed(() => {
  const cardno =
    numbers.value.first + numbers.value.second + numbers.value.third + numbers.value.fourth;
  return cardno.length === 16 ? !cardValid.value : false;
});

//個別欄位錯誤訊息
const errObj = reactive({
  first: '',
  second: '',
  third: '',
  fourth: '',
});

//for固定順序用 Object.keys(errObj)取值順序會不正確
const errKeys = ['first', 'second', 'third', 'fourth'];
/**
 * 檢核單一欄位資料是符合字數及號碼規則
 * @param {number} val 輸入值
 * @param {string} key 分辨觸發的errObj
 * @returns {boolean} 是否通過檢核
 */
const inputRules = (val, key) => {
  errObj[key] = '';
  if (!val) {
    errorMsg.value = '請輸入信用卡號碼';
    errObj[key] = '請輸入信用卡號碼';
    return true;
  }

  const length = val.length;
  if (length > 0 && length <= 3) {
    errorMsg.value = '信用卡號碼有誤';
    errObj[key] = '信用卡號碼有誤';
    return true;
  }

  const cardno =
    numbers.value.first + numbers.value.second + numbers.value.third + numbers.value.fourth;

  // 尚未輸入完成，不檢查
  if (cardno.length === 16) {
    if (!checkCardno(cardno)) {
      errorMsg.value = '無效信用卡號碼';
      return true;
    }
    cardValid.value = true;
  }

  errorMsg.value = '';
  //其他欄位仍有錯時依順序顯示錯誤訊息
  //ex 游標在third驗證已無錯誤，second與fourth有錯誤訊息，優先顯示second錯誤訊息。
  for (let i = 0; i < errKeys.length; i++) {
    const errKey = errKeys[i];
    if (errKey === key) {
      continue;
    }
    if (errObj[errKey].length > 0) {
      errorMsg.value = errObj[errKey];
      break;
    }
  }
  return true;
};

/**
 * 檢查有無符合信用卡格式
 * @param {string} cardno 完整卡號
 * @returns {boolean} 是否符合
 */
const checkCardno = (cardno) => {
  let iSumCheck = 0;
  for (let i = 16; i > 0; i--) {
    const iC = cardno.substring(17 - i - 1, 17 - i);

    const iCS = iC * (((i + 1) % 2) + 1);
    iSumCheck += (iCS - (iCS % 10)) / 10 + (iCS % 10);
  }
  return iSumCheck % 10 === 0;
};
</script>
