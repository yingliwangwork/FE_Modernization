<template>
  <q-table
    ref="qTableRef"
    v-model:pagination="pagination"
    class="cxl-table"
    table-header-class="cxl-table-header"
    square
    flat
    bordered
    dense
    no-data-label="查無資料"
  >
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
    <template v-if="!$slots.bottom" #bottom="scope">
      <CxlPaginatorForTable
        v-model:pagination="pagination"
        :scope
        :totalItemLength="totalItemLength"
        :pageAlign="$attrs.pageAlign"
        :dropdownOptions="$attrs.dropdownOptions"
      />
    </template>
    <template v-if="!$slots['no-data']" #no-data="{ message }">
      <div class="cxl-table-null">
        <span>{{ message }}</span>
      </div>
    </template>
  </q-table>
</template>
<script setup>
import { ref, reactive, onMounted, watch, computed } from 'vue';
import CxlPaginatorForTable from './CxlPaginatorForTable.vue';

const pagination = defineModel('pagination', {
  type: Object,
  default: () => {
    return {
      page: 1,
      rowsPerPage: 10,
    };
  },
});

const properties = [
  'toggleFullscreen',
  'setFullscreen',
  'exitFullscreen',
  'requestServerInteraction',
  'setPagination',
  'firstPage',
  'prevPage',
  'nextPage',
  'lastPage',
  'isRowSelected',
  'clearSelection',
  'isRowExpanded',
  'setExpanded',
  'sort',
  'resetVirtualScroll',
  'scrollTo',
  'filteredSortedRows',
  'computedRows',
  'computedRowsNumber',
];

const qTableRef = ref(null);
const totalItemLength = computed(() => qTableRef.value?.computedRowsNumber);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qTableRef.value[key];
  });
});

watch(
  () => [
    qTableRef.value?.filteredSortedRows,
    qTableRef.value?.computedRows,
    qTableRef.value?.computedRowsNumber,
  ],
  ([filteredSortedRows, computedRows, computedRowsNumber]) => {
    exposedProperties.filteredSortedRows = filteredSortedRows;
    exposedProperties.computedRows = computedRows;
    exposedProperties.computedRowsNumber = computedRowsNumber;
  },
);

defineExpose(exposedProperties);
</script>
