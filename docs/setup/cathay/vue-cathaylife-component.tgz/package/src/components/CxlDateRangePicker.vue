<!--
　參考來源：https://linmasahiro.github.io/vue3-datepicker-lite/dist/
-->
<template>
  <div class="cxl-calendar">
    <div
      class="row cxl-range-row"
      :class="
        error.start || innerError.start || error.end || innerError.end
          ? 'cxl-border-danger-bright'
          : ''
      "
    >
      <input
        :id="`${idAttr}-start`"
        v-model="selectedValues.start"
        class="cxl-input cxl-range"
        :class="{ error: error.start || innerError.start }"
        type="text"
        :name="nameAttr"
        :autocomplete="autocompleteAttr"
        :placeholder="placeholderAttr?.start || ''"
        :maxlength="maxLength"
        @keypress="filterText"
      />

      <p class="cxl-date-range__p">至</p>

      <input
        :id="`${idAttr}-end`"
        v-model="selectedValues.end"
        class="cxl-input cxl-range"
        :class="{ error: error.end || innerError.end }"
        type="text"
        :name="nameAttr"
        :autocomplete="autocompleteAttr"
        :placeholder="placeholderAttr?.end || ''"
        :maxlength="maxLength"
        @keypress="filterText"
      />
      <button
        type="button"
        style="cursor: pointer"
        class="cxl-date-multi__btn"
        @click="onFocusEvent"
      >
        <span
          class="cub-icon-date_24 cxl-font-24 cxl-text-gray-a7"
          style="vertical-align: -0.2em"
        />
      </button>
    </div>
    <div class="column">
      <div v-if="error.start || innerError.start" role="alert" class="cxl-text-danger-bright">
        {{ innerErrorMessage.start || errorMessage.start }}
      </div>
      <div v-if="error.end || innerError.end" role="alert" class="cxl-text-danger-bright">
        {{ innerErrorMessage.end || errorMessage.end }}
      </div>
    </div>
    <div v-if="datepicker.show" class="cxl-calendar-picker__mask" @click="close"></div>
    <div
      v-if="datepicker.show"
      class="cxl-calendar-picker__frame"
      :class="{ 'cxl-calendar-picker__frame_up': needMoveToUp }"
    >
      <div class="cxl-calendar-picker__warp">
        <div class="cxl-calendar-picker__box">
          <div class="cxl-calendar-picker__header">
            <div class="cxl-calendar-picker__year">
              <select v-model="datepicker.year">
                <option v-for="year in datepicker.yearList" :key="year" :value="year">
                  {{ datepicker.yearCountWay === 'ROC' ? '民國' + (year - 1911) : '西元' + year }}年
                </option>
              </select>
            </div>
            <div class="cxl-calendar-picker__month">
              <select v-model="datepicker.month">
                <option v-for="mon in datepicker.monthList" :key="mon" :value="mon">
                  {{
                    `${modifiedLocale.months[mon - 1] + (/[a-z]/.test(modifiedLocale.months[mon - 1]) ? '' : '月')}`
                  }}
                </option>
              </select>
            </div>

            <div class="cxl-calendar-picker__nav--prev" @click="prevMonth">
              <span class="cub-icon-chevronleft_24 cxl-font-14" style="margin-right: -10px"></span>
              <span class="cub-icon-chevronleft_24 cxl-font-14"></span>
            </div>
            <div class="cxl-calendar-picker__nav--next" @click="nextMonth">
              <span class="cub-icon-chevronright_24 cxl-font-14"></span>
              <span class="cub-icon-chevronright_24 cxl-font-14" style="margin-left: -10px"></span>
            </div>
          </div>
          <table class="cxl-calendar-picker__table">
            <thead>
              <tr>
                <th
                  v-for="val in modifiedLocale.weekday"
                  :key="val"
                  class="cxl-calendar-picker__weekday"
                >
                  {{ val }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(dateRow, i) in datepicker.dayList" :key="`row${dateRow[i].dateString}`">
                <td v-for="date in dateRow" :key="date.dateString" role="presentation">
                  <div
                    class="cxl-calendar-picker__day"
                    :class="{
                      'cxl-calendar-picker__day--outfocus': date.month != datepicker.month,
                      'cxl-calendar-picker__day--infocus': date.month == datepicker.month,
                      'cxl-calendar-picker__day--today': date.isToday,
                      'cxl-calendar-picker__day--disabled': date.isDisabled,
                      'cxl-calendar-picker__day--preview': date.dateString == selectedValues.start,
                      'cxl-calendar-picker__day--selected cxl-calendar-picker__day--highlighted':
                        !(innerError.start || innerError.end) &&
                        (selectedValues.start == date.dateString ||
                          selectedValues.end == date.dateString),
                      'cxl-calendar-picker__day--selected cxl-calendar-picker__day--range ':
                        !(innerError.start || innerError.end) &&
                        selectedValues.start < date.dateString &&
                        selectedValues.end > date.dateString,
                    }"
                    @click="date.isDisabled ? false : select(date.dateString)"
                  >
                    {{ date.day }}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <div class="cxl-calendar-picker__footer">
            <button
              type="button"
              class="cxl-btn cxl-btn-primary-outline q-mx-xs"
              flat
              @click="cancelDates"
            >
              取消
            </button>
            <button
              type="button"
              class="cxl-btn cxl-btn-primary q-mx-xs"
              flat
              @click="confirmDates"
            >
              確認
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive, watch } from 'vue';
import {
  regex,
  defaultLocale,
  yearCountDiff,
  getDatePickerDefault,
  parseDateString,
  parseDateObject,
  goNextMonth,
  goPrevMonth,
  getDateList,
  formatInput,
  isRocEmptyPattern,
} from './dateUtils/datePickerUtils.js';

const props = defineProps({
  // 參數：ID
  idAttr: {
    type: String,
    default: '',
  },
  // 參數：name
  nameAttr: {
    type: String,
    default: '',
  },
  // 參數：placeholder
  placeholderAttr: {
    type: Object,
    default: () => {},
  },
  // 參數：autocomplete
  autocompleteAttr: {
    type: String,
    default: 'off',
  },
  // 日期選擇器顯示資料用(變數datepicker)
  yearCountWay: {
    type: String,
    default: 'AD',
  },
  // 調整小日曆年份下拉選單一次出現範圍
  yearsRange: {
    type: Number,
    default: 80,
  },
  // 在限定年份下 from date 數值
  from: {
    type: String,
    default: '',
  },
  // 在限定年份下 end date 數值
  to: {
    type: String,
    default: '',
  },
  excludeDays: {
    type: Object,
    default: () => {},
  },
  // 在地化設定，預設值在變數modifiedLocale中的defaultLocale設定。
  locale: {
    type: Object,
    default: () => {},
  },
  error: {
    type: Object,
    default: () => {
      return { start: false, end: false };
    },
  },
  errorMessage: {
    type: Object,
    default: () => {
      return { start: '', end: '' };
    },
  },
});

const emits = defineEmits(['updateValueAttr', 'valueVaildate']);

// Merge locale setting and default locale setting
const modifiedLocale = {
  ...defaultLocale,
  ...props.locale,
};

/**
 * 確認鍵入事件值之合法性
 * @param {string} event 輸入事件物件資料
 */
const filterText = (event) => {
  if (event && !isRocEmptyPattern(event.key)) {
    event.preventDefault();
  }
};

/**
 * 檢查設定的上下限值格式(YYYY/MM/DD)
 */
const checkDateUpperAndLowerLimits = () => {
  try {
    // from、to傳入格式應為YYYY/MM/DD，如格式錯誤不另外處理，
    const propsFrom = props.from;
    if (propsFrom && !regex.AD.test(propsFrom)) {
      throw new Error('日期下限(props.from)格式應為YYYY/MM/DD');
    }
    const propsTo = props.to;
    if (propsTo && !regex.AD.test(propsTo)) {
      throw new Error('日期上限(props.to)格式應為YYYY/MM/DD');
    }
  } catch (err) {
    throw ('catch:', err);
  }
};
checkDateUpperAndLowerLimits();

const datepicker = reactive({
  ...getDatePickerDefault(props),
  ...{
    yearList: computed(() => getDateList(datepicker, 'year')),
    monthList: computed(() => getDateList(datepicker, 'month')),
    dayList: computed(() => getDateList(datepicker, 'day')),
  },
});

const maxLength = ref(yearCountDiff.row[datepicker.yearCountWay]);

/**
 * 上一個月按鈕
 */
const prevMonth = () => {
  const prevObj = goPrevMonth(datepicker);
  if (prevObj.goPrev) {
    datepicker.year = prevObj.nextYear;
    datepicker.month = prevObj.nextMonth;
  }
};

/**
 * 下一個月按鈕
 */
const nextMonth = () => {
  const nextObj = goNextMonth(datepicker);
  if (nextObj.goNext) {
    datepicker.year = nextObj.nextYear;
    datepicker.month = nextObj.nextMonth;
  }
};

const selectedValues = defineModel('valueAttr', {
  type: Object,
  default: {
    start: '',
    end: '',
  },
});

const innerError = reactive({ start: false, end: false });
const innerErrorMessage = reactive({ start: '', end: '' });

/**
 * 輸入資料檢核
 * @param {string}value 輸入的日期資料
 * @param {string}keyName 觸發物件類型(start(起)/end(訖))
 * @returns {boolean} 檢核結果
 */
const validDate = (value, keyName) => {
  innerError[keyName] = false;
  innerErrorMessage[keyName] = '';
  const target = parseDateObject(value);
  // 當輸入內容 與日期格式不符時 日期格式有誤
  if (target === null) {
    innerError[keyName] = true;
    innerErrorMessage[keyName] = `${keyName === 'start' ? '起始日' : '結束日'}日期格式有誤`;
    emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
    return false;
  }
  //日期低於有效範圍
  if (datepicker.from) {
    const lower = parseDateObject(datepicker.from);
    if (lower > target) {
      innerError[keyName] = true;
      innerErrorMessage[keyName] = `${keyName === 'start' ? '起始日' : '結束日'}超過有效範圍`;
      emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
      return false;
    }
  }
  // 日期高於有效範圍
  if (datepicker.to) {
    const upper = parseDateObject(datepicker.to);
    if (upper < target) {
      innerError[keyName] = true;
      innerErrorMessage[keyName] = `${keyName === 'start' ? '起始日' : '結束日'}超過有效範圍`;
      emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
      return false;
    }
  }
  // 起始日與結束日有值 選擇起始日後會有大於結束日的可能
  if (selectedValues.value.start && selectedValues.value.end) {
    const start = parseDateObject(selectedValues.value.start);
    const end = parseDateObject(selectedValues.value.end);
    if (start > end) {
      innerError.start = true;
      innerErrorMessage.start = '起始日不可大於結束日';
      emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
      return false;
    }
    innerError.start = false;
    innerErrorMessage.start = '';
  }

  // 去除特定星期
  if (datepicker.excludeDays.weekday.includes(target.getDay())) {
    innerError[keyName] = true;
    innerErrorMessage[keyName] =
      `${keyName === 'start' ? '起始日' : '結束日'}日期不可被特定星期選取`;
    emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
    return false;
  }

  // 去除特定日期
  if (
    datepicker.excludeDays.days.length > 0 &&
    parseDateString(target, 'AD', false).includes(datepicker.excludeDays.days)
  ) {
    innerError[keyName] = true;
    innerErrorMessage[keyName] =
      `${keyName === 'start' ? '起始日' : '結束日'}日期不可被特定日期選取`;
    emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
    return false;
  }
  emits('valueVaildate', { err: innerError, msg: innerErrorMessage });
  return true;
};

/**
 * 預設值處理(props.valueAttr)
 * @param {object} value 預設值清單
 */
const doSetSelectedValues = (value) => {
  const selectedObjKeys = Object.keys(value);
  if (!value.start && !value.end) {
    // 空值 歸零
    if (selectedValues.value.start && selectedValues.value.end) {
      selectedValues.value = { start: '', end: '' };
    }
    return;
  }
  const tmpSelected = {};
  selectedObjKeys.forEach((key) => {
    const dateItem = value[key];

    // 格式不對進行轉換
    if (dateItem && !regex[datepicker.yearCountWay].test(dateItem)) {
      // 西元/民國年轉譯
      tmpSelected[key] = parseDateString(parseDateObject(dateItem), datepicker.yearCountWay);
      return;
    }
    tmpSelected[key] = dateItem;
  });

  const diffDateKeys = selectedObjKeys.filter(
    (key) => selectedValues.value[key] !== tmpSelected[key],
  );
  if (diffDateKeys.length === 0) {
    return;
  }
  selectedValues.value.start = tmpSelected.start;
  selectedValues.value.end = tmpSelected.end;
};

// 初始化數值
if (props.valueAttr.start && props.valueAttr.end) {
  doSetSelectedValues(props.valueAttr);
  // 檢查初始值
  validDate(selectedValues.value.start, 'start');
  validDate(selectedValues.value.end, 'end');
}

// 不觸發emit
const dontSendEvent = ref({ start: false, end: false });
let resetDate = { ...selectedValues.value };

/**
 * 觸發emit updateValueAttr
 * @param {string} keyName 觸發物件類型(start(起)/end(訖))
 */
const emitUpdateEvent = (keyName) => {
  if (keyName && dontSendEvent.value[keyName]) {
    dontSendEvent.value[keyName] = false;
    return;
  }
  const changedType = Object.keys(selectedValues.value).filter(
    (checkKey) => resetDate[checkKey] !== selectedValues.value[checkKey],
  );
  if (changedType.length <= 0) {
    return;
  }
  resetDate = { ...selectedValues.value };
  emits('updateValueAttr', { ...selectedValues.value });
};

/**
 * 監聽: selectedValues.start
 */
watch(
  () => selectedValues.value.start,
  (value, prevValue) => {
    if (!value) {
      return;
    }
    const keyName = 'start';
    selectedValues.value.start = formatInput(value, prevValue, datepicker);
    // 檢核沒錯誤，且年份類型均正確時發出更新事件
    if (validDate(value, keyName) && regex[datepicker.yearCountWay].test(value)) {
      emitUpdateEvent(keyName);
    }
  },
);

/**
 * 監聽: selectedValues.end
 */
watch(
  () => selectedValues.value.end,
  (value, prevValue) => {
    if (!value) {
      return;
    }
    const keyName = 'end';
    selectedValues.value.end = formatInput(value, prevValue, datepicker);
    if (validDate(value, keyName) && regex[datepicker.yearCountWay].test(value)) {
      emitUpdateEvent(keyName);
    }
  },
);

/**
 * 監聽datepicker.show
 */
watch(
  () => datepicker.show,
  (state) => {
    // 小日曆被打開的時候
    if (state) {
      if (selectedValues.value.start) {
        const start = parseDateObject(selectedValues.value.start);
        if (start) {
          datepicker.year = start.getFullYear();
          datepicker.month = start.getMonth() + 1;
          return;
        }
      }

      if (selectedValues.value.end) {
        const end = parseDateObject(selectedValues.value.end);
        if (end) {
          datepicker.year = end.getFullYear();
          datepicker.month = end.getMonth() + 1;
          return;
        }
      }
      const today = parseDateObject(datepicker.today);
      const upper = parseDateObject(datepicker.to);
      // 用上限日期
      if (today > upper) {
        datepicker.year = upper.getFullYear();
        datepicker.month = upper.getMonth() + 1;
        return;
      }
      // 用今天日期
      datepicker.year = today.getFullYear();
      datepicker.month = today.getMonth() + 1;
    }
  },
);

/**
 * Watch valueAttr's state
 */
watch(
  () => props.valueAttr,
  (value) => {
    doSetSelectedValues(value);
  },
);

/**
 * 選擇日期
 * @param {string} value 修改值
 */
const select = (value) => {
  if (!value) {
    return;
  }
  // 首先start和end都是空值 || start空值 end為有值
  if ((selectedValues.value.start && selectedValues.value.end) || !selectedValues.value.start) {
    dontSendEvent.value.start = true;
    selectedValues.value.start = value;
    selectedValues.value.end = '';
    return;
  }
  dontSendEvent.value.end = true;
  selectedValues.value.end = value;
  reserveDate();
};

/**
 * 比較與賦予值
 */
const reserveDate = () => {
  const from = parseDateObject(selectedValues.value.start);
  const to = parseDateObject(selectedValues.value.end);
  // 起訖互換
  if (to < from) {
    dontSendEvent.value.start = true;
    dontSendEvent.value.end = true;
    const end = selectedValues.value.start;
    const start = selectedValues.value.end;
    selectedValues.value.start = start;
    selectedValues.value.end = end;
  }
};

/**
 * Modified datepicker position
 */
const needMoveToUp = ref(false);

/**
 * onFocusEvent
 * 開啟小月曆
 * @param {object} event 點擊事件資料物件
 */
const onFocusEvent = (event) => {
  const potisionY = event.target.getBoundingClientRect().y;
  // 元件位置高度至少要 290 才在上方顯示，避免高度不足(往上增長不會有scroll bar)
  needMoveToUp.value = potisionY >= 290 && window.innerHeight - potisionY <= 290;
  datepicker.show = true;
};

/**
 * 確認選取日期
 */
const confirmDates = () => {
  emitUpdateEvent();

  datepicker.show = false;
};

/**
 * 關閉datepicker
 */
const close = () => {
  selectedValues.value = { ...resetDate };
  datepicker.show = false;
};

/**
 * 取消選取日期
 */
const cancelDates = () => {
  close();
};
</script>
