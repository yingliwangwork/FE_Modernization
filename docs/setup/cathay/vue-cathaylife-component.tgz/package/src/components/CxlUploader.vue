<template>
  <div class="cxl-uploader" :class="{ picked: !isFileEmpty }">
    <q-file
      v-model="qFiles"
      use-chips
      borderless
      clearable
      :multiple="props.multiple"
      :accept="accept"
      :name="props.name"
      :max-file-size="props.maxSize * 1024 * 1024"
      :filter="checkFile"
      @rejected="onRejected"
      @update:modelValue="stateUpdate"
    ></q-file>
    <span v-show="isFileEmpty" class="cxl-uploader-label">Upload Files</span>
  </div>
  <div class="row q-py-sm">
    <CxlInput
      v-model="inputValue"
      class="q-mr-sm col"
      :placeholder="`限 ${props.maxSize} MB，檔案名稱限 ${props.maxLength} 字`"
      readonly
    />
    <CxlButton class="q-mr-sm" label="瀏覽" style="position: relative">
      <q-file
        v-model="qFiles"
        borderless
        :multiple="props.multiple"
        :accept="accept"
        :name="props.name"
        :max-file-size="props.maxSize * 1024 * 1024"
        :filter="checkFile"
        style="position: absolute; opacity: 0"
        @rejected="onRejected"
        @update:modelValue="stateUpdate"
      ></q-file>
    </CxlButton>
    <CxlButton label="上傳" @click="emit('uploadFiles')" />
  </div>
  <CxlInfo
    v-model="openInfoModal"
    title="檔案錯誤"
    close-text="確定"
    status="negative"
    size="sm"
    @buttonClick="openInfoModal = false"
  >
    <!-- 這裡可以放 HTML -->
    <div class="row justify-center">
      <p class="cxl-font-18">{{ errMsg }}</p>
    </div>
  </CxlInfo>
</template>

<script setup>
import { ref, computed } from 'vue';
import CxlInput from './CxlInput.vue';
import CxlButton from './CxlButton.vue';
import CxlInfo from './CxlInfo.vue';

const props = defineProps({
  name: { type: String, default: 'files' },
  ext: {
    type: Array,
    default: () => [],
  },
  maxSize: {
    type: Number,
    default: 8,
  },
  maxLength: {
    type: Number,
    default: 35,
  },
  multiple: {
    type: Boolean,
    default: true,
  },
});

// 檔案雙向綁定
const qFiles = ref(null);
const isFileEmpty = computed(() => {
  if (!qFiles.value) {
    return true;
  }
  return qFiles.value.length <= 0;
});

// 限制副檔名
const accept = computed(() => {
  if (Array.isArray(props.ext) && props.ext.length) {
    let rtnValue = '';
    props.ext.forEach((value, index) => {
      if (index != 0) {
        rtnValue += ',';
      }
      rtnValue += '.' + value;
    });
    return rtnValue;
  }
  return '';
});

// 檢查檔案名稱長度
const checkFile = (files) => {
  return files.filter((file) => {
    const fileNameLength = file.name.substring(0, file.name.lastIndexOf('.')).length;
    return fileNameLength <= props.maxLength;
  });
};

// 檢查沒有通過驗證的檔案
const computedFileRestrictSize = computed(() => {
  return props.maxSize + ' MB';
});

// 控制 Infomodal 開啟與否
const openInfoModal = ref(false);
const errMsg = ref('');
const onRejected = (rejectedEntries) => {
  errMsg.value = '';
  rejectedEntries.forEach((elem) => {
    errMsg.value = errMsg.value.concat(', ', elem.file.name).substring(1);
    switch (elem.failedPropValidation) {
      case 'max-file-size':
        errMsg.value += ' 超出 ' + computedFileRestrictSize.value;
        break;
      case 'duplicate':
        errMsg.value += ' 已存在相同檔案';
        break;
      case 'filter':
        errMsg.value += ` 檔案名稱超過 ${props.maxLength} 個字`;
        break;
      default:
        errMsg.value += ' 檔案格式錯誤';
        break;
    }
  });
  openInfoModal.value = true;
};

// 綁定 input 輸入的值
const inputValue = ref('');
// 連結檔案名稱 (顯示在輸入框)
const concatenateFileName = (formData) => {
  inputValue.value = '';
  formData.forEach((file) => {
    inputValue.value = inputValue.value.concat(', ', file.name).substring(1);
  });
};

// 取得瀏覽或拖曳的檔案們
const emit = defineEmits(['getFiles', 'uploadFiles']);
const stateUpdate = (files) => {
  const formData = new FormData();
  const uploadName = props.name;
  formData.delete(uploadName); // 全部刪掉後, callback 會再將剩餘的 file 放回 formData 內
  if (files) {
    if (props.multiple) {
      files.forEach((value) => {
        formData.append(uploadName, value); // 透過迴圈將檔案存入 formData 的同一個 name 中
      });
    } else {
      formData.append(uploadName, files); // 透過迴圈將檔案存入 formData 的同一個 name 中
    }
  }

  if (formData.getAll(props.name).length) {
    concatenateFileName(formData, formData.getAll(props.name).length);
  } else {
    inputValue.value = '';
  }
  emit('getFiles', formData);
};

// 清空檔案
const clear = () => {
  qFiles.value = null;
  stateUpdate(null);
};

defineExpose({ clear });
</script>
