<template>
  <div class="cxl-news-ticker">
    <span class="cxl-news-ticker-icon cub-icon-speaker_40_m cxl-font-40 cxl-text-primary"></span>
    <div ref="newsContent" class="cxl-news-ticker-content">
      <div
        v-for="(data, index) in props.news"
        :key="data"
        class="cxl-news-ticker-message"
        :class="{ fadein: index === 0 }"
      >
        {{ data }}
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue';

const props = defineProps({
  news: {
    type: Array,
    default: () => [
      'First announcement of news ticker.',
      'Second announcement of news ticker.',
      'Third announcement of news ticker.',
    ],
  },
  timeSpeed: {
    type: [Number, String],
    default: 3000,
  },
});

let newsInterval;
const newsContent = ref();
const controlNewsTicker = () => {
  if (props.news.length <= 1) {
    return;
  }

  newsInterval = setInterval(() => {
    const oldFade = newsContent.value.querySelector('.fadeout');
    if (oldFade) {
      oldFade.classList.remove('fadeout');
    }
    const news = newsContent.value.querySelector('.fadein');
    news.classList.remove('fadein');
    news.classList.add('fadeout');
    let nextNews = news.nextElementSibling;
    if (!nextNews) {
      nextNews = newsContent.value.querySelector('.cxl-news-ticker-message');
    }
    nextNews.classList.add('fadein');
  }, props.timeSpeed);
};

onMounted(() => {
  controlNewsTicker();
});

// 當 timeSpeed 被父元件改動時, 應重新啟動 newsInterval
watch(
  () => props.timeSpeed,
  () => {
    if (newsInterval) {
      clearInterval(newsInterval);
    }
    controlNewsTicker();
  },
);

// 離開此頁面應關閉 newsInterval, 否則 querySelector 會出錯
onUnmounted(() => {
  if (newsInterval) {
    clearInterval(newsInterval);
  }
});
</script>
