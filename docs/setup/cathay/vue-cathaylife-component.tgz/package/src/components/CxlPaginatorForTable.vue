<template>
  <div
    class="cxl-paginator"
    :class="{
      'cxl-border-gray-overlay': props.withBorder,
      'cxl-paginator-left': props.pageAlign === 'left',
    }"
  >
    <div class="cxl-paginator-spacer"></div>
    <div class="cxl-paginator-page">
      <button
        type="button"
        class="q-mr-sm"
        :disable="$attrs.scope.isFirstPage"
        @click="$attrs.scope.prevPage"
      >
        <span class="cxl-paginator-icon cxl-paginator-previous-icon"></span>
      </button>
      <input type="text" :value="pagination.page" @input="changeCurrentPage" />
      <span class="cxl-paginator-total">/ {{ $attrs.scope.pagesNumber }}</span>
      <button
        type="button"
        class="q-ml-sm"
        :disable="$attrs.scope.isLastPage"
        @click="$attrs.scope.nextPage"
      >
        <span class="cxl-paginator-icon cxl-paginator-next-icon"></span>
      </button>
    </div>
    <div class="cxl-paginator-info">
      <CxlDropdown
        v-model="pagination.rowsPerPage"
        :options="props.dropdownOptions"
        class="q-mr-sm"
        @update:modelValue="updDropVal"
      />
      <span class="ng-star-inserted">筆 / 頁</span>
      <span class="cxl-paginator-info-totalitem ng-star-inserted">
        ，共 {{ props.totalItemLength }} 筆
      </span>
    </div>
  </div>
</template>

<script setup>
import { useAttrs } from 'vue';
import CxlDropdown from './CxlDropdown.vue';

const pagination = defineModel('pagination', {
  type: Object,
  default: () => {
    return {
      page: 1,
      rowsPerPage: 10,
    };
  },
});

const props = defineProps({
  // 是否啟用邊框樣式，預設為啟用。
  withBorder: {
    type: Boolean,
    default: false,
  },
  // 資料總筆數
  totalItemLength: {
    type: [Number, String],
    default: 0,
  },
  // 一頁幾筆顯示在右邊或左邊
  pageAlign: {
    type: String,
    default: 'right',
  },
  dropdownOptions: {
    type: Array,
    default: () => [
      { label: '5', value: 5 },
      { label: '10', value: 10 },
      { label: '30', value: 30 },
      { label: '50', value: 50 },
      { label: '100', value: 100 },
      { label: 'All', value: 'All' },
    ],
  },
});

const attrs = useAttrs();
/**
 * 根據輸入值更改當前頁面
 * @param {object} event - 事件對象
 * @returns {void}
 */
const changeCurrentPage = (event) => {
  // 僅限輸入數字
  const regex = /^[0-9\s]*$/;
  if (!regex.test(event.target.value)) {
    return;
  }

  if (!event.target.value) {
    return;
  }

  // 以下會使用對象展開語法來更新 pagination 的值，以確保 Vue 的 reactivity 系統能夠檢測到變化並更新視圖
  // 直接修改對象的屬性無法觸發 value 更新，因此需要創建一個新的對象，似乎是包太多層 defineModel，而且也沒給預設的 ref 宣告

  if (event.target.value > attrs.scope.pagesNumber) {
    pagination.value = {
      ...pagination.value,
      page: attrs.scope.pagesNumber,
      rowsPerPage: pagination.value.rowsPerPage,
    };
    return;
  }

  pagination.value = {
    ...pagination.value,
    page: parseInt(event.target.value, 10),
    rowsPerPage: pagination.value.rowsPerPage,
  };
};

/**
 * 根據輸入值更新 RowsPerPage 的值，或者如果輸入值為"All"，則更新為總數
 * @param {object} val - 包含值屬性的物件。
 * @returns {void}
 */
const updDropVal = (val) => {
  pagination.value = {
    ...pagination.value,
    page: pagination.value.page,
    rowsPerPage: val.value === 'All' ? props.totalItemLength : val.value,
  };
};
</script>
