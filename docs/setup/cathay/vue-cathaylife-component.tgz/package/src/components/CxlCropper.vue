<template>
  <CxlButton padding="6px 15px" :label="props.label" theme="primary" :prevIcon="props.prevIcon">
    <input
      type="file"
      name="image"
      onkeypress="return false;"
      accept="image/*"
      capture="camera"
      style="position: absolute; opacity: 0; cursor: pointer; width: 100px"
      @change="getImage"
      @click="reset"
    />
  </CxlButton>
  <CxlModal
    v-model="openModal"
    :title="props.modalTitle"
    :cancelText="props.cancelText"
    :confirmText="props.confirmText"
    @confirm="crop"
    @cancel="openModal = false"
  >
    <div>
      <img ref="targetImg" :src="image" class="mw-100" />
    </div>
  </CxlModal>
</template>

<script setup>
import { ref, onUpdated, onMounted } from 'vue';
import CxlButton from './CxlButton.vue';
import CxlModal from './CxlModal.vue';
import 'cropperjs/dist/cropper.css';
import Cropper from 'cropperjs';

const props = defineProps({
  modalTitle: {
    type: String,
    default: '標題',
  },
  label: {
    type: String,
    default: '上傳檔案',
  },
  prevIcon: {
    type: String,
    default: 'cxl-icon-camera',
  },
  cancelText: {
    type: String,
    default: '取消',
  },
  confirmText: {
    type: String,
    default: '裁切',
  },
});

// 控制 modal 開啟與否
const openModal = ref(false);
// modal DOM 更新時，產生
onUpdated(() => {
  if (openModal.value) {
    createCrop();
  }
});

/* 為了使取得同一張圖片時，也可以觸發裁切 */
let fileInput;
onMounted(() => {
  fileInput = document.querySelector('input[name=image]');
});

/**
 *
 */
const reset = () => {
  if (fileInput.value) {
    fileInput.value = null;
  }
};

/**
 *
 * @param e
 */
const getImage = (e) => {
  const files = e.target.files;

  if (files && files.length > 0) {
    const file = files[0];
    if (URL) {
      done(URL.createObjectURL(file));
    } else if (FileReader) {
      const reader = new FileReader();
      reader.onload = () => {
        done(reader.result);
      };
      reader.readAsDataURL(file);
    }
  }
};

const image = ref('');
/**
 *
 * @param url
 */
const done = (url) => {
  image.value = url;
  openModal.value = true;
};

const targetImg = ref();
const cropper = ref();
/**
 *
 */
const createCrop = () => {
  cropper.value = new Cropper(targetImg.value, {
    movable: false,
    aspectRatio: 17 / 9,
    zoomable: false,
    rotatable: false,
    scalable: false,
    minContainerHeight: 159,
  });
};

const emit = defineEmits(['getCroppedImage']);

// 按裁切時的行為
const dataURL = ref('');
/**
 *
 */
const crop = () => {
  if (!cropper.value) {
    return;
  }
  const crop_canvas = cropper.value.getCroppedCanvas({
    width: 558,
    height: 295,
  });

  const canvas = document.createElement('canvas');
  canvas.width = 558;
  canvas.height = 295;
  const ctx = canvas.getContext('2d');

  const upload_img = new Image();
  upload_img.src = crop_canvas.toDataURL();

  upload_img.onload = () => {
    ctx.drawImage(upload_img, 0, 0);
    dataURL.value = canvas.toDataURL();
    openModal.value = false;
    emit('getCroppedImage', dataURL.value);
  };
};
</script>
