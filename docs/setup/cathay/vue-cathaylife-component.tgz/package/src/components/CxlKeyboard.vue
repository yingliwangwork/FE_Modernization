<template>
  <q-dialog class="cxl-modal cxl-keyboard" persistent>
    <q-card class="cxl-keyboard-radis-10">
      <q-card-section class="column">
        <div class="cxl-modal-title">{{ props.title }}</div>
        <CxlInput v-model="inputVal" readonly type="password" />
      </q-card-section>
      <div class="cxl-keyboard-number-container">
        <CxlButton
          v-for="item in numbers"
          :key="item"
          padding="10px 26px"
          :label="item.toString()"
          theme="primary-outline"
          class="cxl-keyboard-number"
          @click="append(`${item}`)"
        />
        <CxlButton
          label="刪除"
          theme="primary-outline"
          class="cxl-keyboard-number cxl-keyboard-del"
          @click="clear"
        />
      </div>
      <q-card-actions class="row justify-center">
        <CxlButton
          v-close-popup
          padding="8.21px 27px"
          theme="primary-outline"
          label="取消"
          @click="cancel()"
        />
        <CxlButton padding="8.21px 27px" label="確定" @click="confirm()" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { ref, onBeforeMount, onBeforeUpdate } from 'vue';
import CxlButton from './CxlButton.vue';
import CxlInput from './CxlInput.vue';

const props = defineProps({
  title: {
    type: String,
    default: '請輸入密碼',
  },
  suffle: {
    type: Boolean,
    default: true,
  },
  maxLength: {
    type: [String, Number],
    default: 100,
  },
});

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
onBeforeMount(() => {
  if (!props.suffle) {
    return;
  }
  numbers.sort(() => {
    return 0.5 - Math.random();
  });
});

onBeforeUpdate(() => {
  if (!props.suffle) {
    return;
  }
  numbers.sort(() => {
    return 0.5 - Math.random();
  });
});

// 綁定 input 輸入的值
const inputVal = ref('');

// 增加數字
const append = (number) => {
  if (props.maxLength > 0 && inputVal.value.length >= props.maxLength) {
    return;
  }
  inputVal.value = `${inputVal.value}${number}`;
};

// 刪除數字
const clear = () => {
  inputVal.value = inputVal.value.slice(0, -1);
};

const emit = defineEmits(['confirm', 'cancel']);
const confirm = () => {
  emit('confirm', inputVal.value);
};

const cancel = () => {
  inputVal.value = '';
  emit('cancel');
};
</script>
