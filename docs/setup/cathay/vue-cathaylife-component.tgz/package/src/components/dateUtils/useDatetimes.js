import { computed } from 'vue';

import { format } from 'quasar';

const { pad } = format;
const calendars = ['gregorian', 'ROC'];
const outputTypes = ['gregorian', 'ROC'];

export const useDatetimeProps = {
  // should define modelValue in the target component
  modelValue: {
    required: true,
  },
  mask: {
    type: String,
  },
  locale: Object,

  calendar: {
    type: String,
    validator: (v) => calendars.includes(v),
    default: 'gregorian',
  },
  outputType: {
    type: String,
    validator: (v) => outputTypes.includes(v),
    default: 'gregorian',
  },

  landscape: Boolean,

  color: String,
  textColor: String,

  square: Boolean,
  flat: Boolean,
  bordered: Boolean,

  readonly: Boolean,
  disable: Boolean,
};

export const useDatetimeEmits = ['update:modelValue'];

export function getDayHash(date) {
  return date.year + '/' + pad(date.month) + '/' + pad(date.day);
}

export default function (props, $q) {
  const editable = computed(() => {
    return props.disable !== true && props.readonly !== true;
  });

  const tabindex = computed(() => {
    return editable.value === true ? 0 : -1;
  });

  const headerClass = computed(() => {
    const cls = [];
    if (props.color !== undefined) {
      cls.push(`bg-${props.color}`);
    }
    if (props.textColor !== undefined) {
      cls.push(`text-${props.textColor}`);
    }
    return cls.join(' ');
  });

  function getLocale() {
    return props.locale !== undefined ? { ...$q.lang.date, ...props.locale } : $q.lang.date;
  }

  function getCurrentDate(dateOnly) {
    const d = new Date();
    const timeFill = dateOnly === true ? null : 0;

    return {
      year: d.getFullYear(),
      month: d.getMonth() + 1,
      day: d.getDate(),
      hour: timeFill,
      minute: timeFill,
      second: timeFill,
      millisecond: timeFill,
    };
  }

  return {
    editable,
    tabindex,
    headerClass,

    getLocale,
    getCurrentDate,
  };
}
