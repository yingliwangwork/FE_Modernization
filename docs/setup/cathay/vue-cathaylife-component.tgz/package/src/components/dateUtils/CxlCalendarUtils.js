import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';

dayjs.extend(customParseFormat);

/**
 * 將 ROC 字串（含 mask）轉為 [yyyy, mm, dd] 陣列
 * @param rocStr
 * @param mask
 * @returns {string}
 */
const rocToAdDateParts = (input, mask) => {
  // 將 mask 中的組合轉換為對應正則
  const regexStr = mask
    .replace(/YYYY|YYY/, '(\\d{1,3})') // 年：1~3碼數字
    .replace(/MM/, '(\\d{1,2})') // 月：1~2碼數字
    .replace(/DD/, '(\\d{1,2})') // 日：1~2碼數字
    .replace(/[-\/]/g, (m) => '\\' + m); // 處理特殊字元

  const regex = new RegExp('^' + regexStr + '$');
  const match = input?.match(regex);
  if (!match) {
    return '';
  }
  // 找出各個欄位對應的位置
  const fields = { year: '', month: '', day: '' };
  let index = 1;

  const tokens = mask.match(/YYYY|YYY|MM|DD/g);
  if (!tokens) {
    return '';
  }
  Object.values(tokens).forEach((token) => {
    const value = match[index];
    switch (token) {
      case 'YYYY':
      case 'YYY':
        fields.year = value.padStart(3, '0');
        break;
      case 'MM':
        fields.month = value.padStart(2, '0');
        break;
      case 'DD':
        fields.day = value.padStart(2, '0');
        break;
      default:
        break;
    }
    index += 1;
  });

  const textYear =
    fields.year === '' ? dayjs().format('YYYY') : String(parseInt(fields.year, 10) + 1911);
  const textMonth = fields.month === '' ? dayjs().format('MM') : fields.month;
  const textDay = fields.day === '' ? dayjs().format('DD') : fields.day;

  return `${textYear}/${textMonth}/${textDay}`;
};

/**
 * 將 AD YYYY/MM/DD 轉為 ROC [yyy, mm, dd]
 * @param adStr
 * @returns {[number,number,1-31]}
 */
const adToRocDateParts = (adStr, mask) => {
  const date = dayjs(adStr, 'YYYY/MM/DD');
  if (!date.isValid()) {
    return adStr;
  }
  const rocYear = (date.year() - 1911).toString().padStart(3, '0');
  const month = (date.month() + 1).toString().padStart(2, '0');
  const day = date.date().toString().padStart(2, '0');

  // 將 mask 中的欄位依序替換
  return mask
    .replace(/YYYY|YYY/, rocYear)
    .replace(/MM/, month)
    .replace(/DD/, day);
};

/**
 * 將傳入 modelValue 根據 calendar + mask 轉成 YYYY/MM/DD（qDate 格式）
 * @param value
 * @param calendar
 * @param mask
 * @returns {*|string}
 */
export const parseFromInput = (value, calendar, mask) => {
  if (!value) {
    return '';
  }

  if (calendar === 'ROC') {
    return rocToAdDateParts(value, mask);
  }
  // AD
  return dayjs(value, mask).format('YYYY/MM/DD');
};

/**
 * 將 YYYY/MM/DD 轉為 outputType + mask
 * @param adStr
 * @param outType
 * @param mask
 * @returns {*|string}
 */
export const formatToOutput = (adStr, outType, mask) => {
  if (!adStr) {
    return '';
  }
  if (outType === 'ROC') {
    return adToRocDateParts(adStr, mask);
  }
  // AD
  return dayjs(adStr, 'YYYY/MM/DD', true).format(mask);
};
