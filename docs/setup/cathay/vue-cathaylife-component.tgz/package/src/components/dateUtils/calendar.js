import {
  h,
  ref,
  computed,
  watch,
  Transition,
  nextTick,
  getCurrentInstance,
  markRaw,
  defineComponent,
} from 'vue';

import { QBtn, useQuasar, useRenderCache, is, format, date as quasarDate } from 'quasar';
import useDatetime, { useDatetimeProps, useDatetimeEmits, getDayHash } from './useDatetimes.js';
import { useFormProps, useFormAttrs, useFormInject } from './useForm.js';

const createComponent = (raw) => markRaw(defineComponent(raw));
const hSlot = (slot, otherwise) => {
  return slot ? slot() || otherwise : otherwise;
};

const { getDateDiff, formatDate } = quasarDate;

const { pad } = format;
const yearsInterval = 20;
const views = ['Calendar', 'Years', 'Months'];
const viewIsValid = (v) => views.includes(v);
const yearMonthValidator = (v) => /^-?[\d]+\/[0-1]\d$/.test(v);
const lineStr = ' \u007E ';

function getMonthHash(date) {
  return date.year + '/' + pad(date.month);
}

function getDateLocale(paramDateLocale, langProps) {
  return paramDateLocale || (langProps ? langProps.date : defaultLang.date);
}
const regexStore = {};
function getRegexData(mask, dateLocale) {
  const days = '(' + dateLocale.days.join('|') + ')';
  const key = mask + days;

  if (regexStore[key]) {
    return regexStore[key];
  }

  const daysShort = '(' + dateLocale.daysShort.join('|') + ')';
  const months = '(' + dateLocale.months.join('|') + ')';
  const monthsShort = '(' + dateLocale.monthsShort.join('|') + ')';

  const map = {};
  let index = 0;

  const reverseToken =
    /(\[[^\]]*\])|d{1,4}|M{1,4}|m{1,2}|w{1,2}|Qo|Do|D{1,4}|YY(?:YY)?|H{1,2}|h{1,2}|s{1,2}|S{1,3}|Z{1,2}|a{1,2}|[AQExX]|([.*+:?^,\s${}()|\\]+)/g;

  const regexText = mask.replace(reverseToken, (match) => {
    index += 1;
    switch (match) {
      case 'YY':
        map.YY = index;
        return '(-?\\d{1,2})';
      case 'YYYY':
        map.YYYY = index;
        return '(-?\\d{1,4})';
      case 'M':
        map.M = index;
        return '(\\d{1,2})';
      case 'MM':
        map.M = index; // bumping to M
        return '(\\d{2})';
      case 'MMM':
        map.MMM = index;
        return monthsShort;
      case 'MMMM':
        map.MMMM = index;
        return months;
      case 'D':
        map.D = index;
        return '(\\d{1,2})';
      case 'Do':
        index += 1;
        map.D = index; // bumping to D
        return '(\\d{1,2}(st|nd|rd|th))';
      case 'DD':
        map.D = index; // bumping to D
        return '(\\d{2})';
      case 'H':
        map.H = index;
        return '(\\d{1,2})';
      case 'HH':
        map.H = index; // bumping to H
        return '(\\d{2})';
      case 'h':
        map.h = index;
        return '(\\d{1,2})';
      case 'hh':
        map.h = index; // bumping to h
        return '(\\d{2})';
      case 'm':
        map.m = index;
        return '(\\d{1,2})';
      case 'mm':
        map.m = index; // bumping to m
        return '(\\d{2})';
      case 's':
        map.s = index;
        return '(\\d{1,2})';
      case 'ss':
        map.s = index; // bumping to s
        return '(\\d{2})';
      case 'S':
        map.S = index;
        return '(\\d{1})';
      case 'SS':
        map.S = index; // bump to S
        return '(\\d{2})';
      case 'SSS':
        map.S = index; // bump to S
        return '(\\d{3})';
      case 'A':
        map.A = index;
        return '(AM|PM)';
      case 'a':
        map.a = index;
        return '(am|pm)';
      case 'aa':
        map.aa = index;
        return '(a\\.m\\.|p\\.m\\.)';

      case 'ddd':
        return daysShort;
      case 'dddd':
        return days;
      case 'Q':
      case 'd':
      case 'E':
        return '(\\d{1})';
      case 'Qo':
        return '(1st|2nd|3rd|4th)';
      case 'DDD':
      case 'DDDD':
        return '(\\d{1,3})';
      case 'w':
        return '(\\d{1,2})';
      case 'ww':
        return '(\\d{2})';

      case 'Z': // to split: (?:(Z)()()|([+-])?(\\d{2}):?(\\d{2}))
        map.Z = index;
        return '(Z|[+-]\\d{2}:\\d{2})';
      case 'ZZ':
        map.ZZ = index;
        return '(Z|[+-]\\d{2}\\d{2})';

      case 'X':
        map.X = index;
        return '(-?\\d+)';
      case 'x':
        map.x = index;
        return '(-?\\d{4,})';

      default:
        index -= 1;
        if (match[0] === '[') {
          match = match.substring(1, match.length - 1);
        }
        return match.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
  });

  const res = { map, regex: new RegExp('^' + regexText) };
  regexStore[key] = res;

  return res;
}

export default createComponent({
  name: 'clx-calendar',

  props: {
    ...useDatetimeProps,
    ...useFormProps,

    multiple: Boolean,
    range: Boolean,

    title: String,
    subtitle: String,

    mask: {
      // this mask is forced
      // when using persian calendar
      default: 'YYYY/MM/DD',
    },

    defaultYearMonth: {
      type: String,
      validator: yearMonthValidator,
    },

    yearsInMonthView: Boolean,

    events: [Array, Function],
    eventColor: [String, Function],

    emitImmediately: Boolean,

    options: [Array, Function],

    navigationMinYearMonth: {
      type: String,
      validator: yearMonthValidator,
    },

    navigationMaxYearMonth: {
      type: String,
      validator: yearMonthValidator,
    },

    noUnset: Boolean,

    firstDayOfWeek: [String, Number],
    todayBtn: Boolean,
    minimal: Boolean,
    defaultView: {
      type: String,
      default: 'Calendar',
      validator: viewIsValid,
    },
  },

  emits: [...useDatetimeEmits, 'rangeStart', 'rangeEnd', 'navigation'],

  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance();
    const { $q } = proxy;
    const $d = useQuasar();

    const isDark = $d.dark.isActive;
    // useDark(props, $q);
    const { getCache } = useRenderCache();
    const { tabindex, headerClass, getLocale, getCurrentDate } = useDatetime(props, $q);
    let lastEmitValue;

    const formAttrs = useFormAttrs(props);
    const injectFormInput = useFormInject(formAttrs);

    const blurTargetRef = ref(null);
    const innerMask = ref(getMask());
    const innerLocale = ref(getLocale());

    const mask = computed(() => getMask());
    const locale = computed(() => getLocale());

    const today = computed(() => getCurrentDate());

    // model of current calendar view:
    const viewModel = ref(getViewModel(innerMask.value, innerLocale.value));

    const view = ref(props.defaultView);

    const direction = $q.lang.rtl === true ? 'right' : 'left';
    const monthDirection = ref(direction.value);
    const yearDirection = ref(direction.value);

    const year = viewModel.value.year;
    const startYear = ref(year - (year % yearsInterval) - (year < 0 ? yearsInterval : 0));
    const editRange = ref(null);

    const classes = computed(() => {
      const type = props.landscape === true ? 'landscape' : 'portrait';
      let noChangeClass = '';
      if (props.disable) {
        noChangeClass = ' disabled';
      } else if (props.readonly) {
        noChangeClass = ' q-date--readonly';
      }

      return (
        `q-date q-date--${type} q-date--${type}-${props.minimal === true ? 'minimal' : 'standard'}` +
        (isDark.value === true ? ' q-date--dark q-dark' : '') +
        (props.bordered === true ? ' q-date--bordered' : '') +
        (props.square === true ? ' q-date--square no-border-radius' : '') +
        (props.flat === true ? ' q-date--flat no-shadow' : '') +
        noChangeClass
      );
    });

    const computedColor = computed(() => {
      return props.color || 'primary';
    });

    const computedTextColor = computed(() => {
      return props.textColor || 'white';
    });

    const isImmediate = computed(
      () => props.emitImmediately === true && props.multiple !== true && props.range !== true,
    );

    const normalizedModel = computed(() => {
      if (Array.isArray(props.modelValue) === true) {
        return props.modelValue;
      }

      if (props.modelValue !== null && props.modelValue !== undefined) {
        return [props.modelValue];
      }

      return [];
    });

    const daysModel = computed(() =>
      normalizedModel.value
        .filter((date) => typeof date === 'string')
        .map((date) => decodeString(date, innerMask.value, innerLocale.value))
        .filter(
          (date) =>
            date.dateHash !== null &&
            date.day !== null &&
            date.month !== null &&
            date.year !== null,
        ),
    );

    const rangeModel = computed(() => {
      const fn = (date) => decodeString(date, innerMask.value, innerLocale.value);
      return normalizedModel.value
        .filter(
          (date) => is.object(date) === true && date.from !== undefined && date.to !== undefined,
        )
        .map((range) => ({ from: fn(range.from), to: fn(range.to) }))
        .filter(
          (range) =>
            range.from.dateHash !== null &&
            range.to.dateHash !== null &&
            range.from.dateHash < range.to.dateHash,
        );
    });

    const getNativeDateFn = computed(() => {
      return (model) => new Date(model.year, model.month - 1, model.day);
    });

    const encodeObjectFn = computed(
      () => (date, tempMask, tempLocale) =>
        formatDate(
          new Date(
            date.year,
            date.month - 1,
            date.day,
            date.hour,
            date.minute,
            date.second,
            date.millisecond,
          ),
          tempMask === undefined ? innerMask.value : tempMask,
          tempLocale === undefined ? innerLocale.value : tempLocale,
          date.year,
          date.timezoneOffset,
        ),
    );

    const daysInModel = computed(
      () =>
        daysModel.value.length +
        rangeModel.value.reduce(
          (acc, range) =>
            acc +
            1 +
            getDateDiff(getNativeDateFn.value(range.to), getNativeDateFn.value(range.from)),
          0,
        ),
    );

    const headerTitle = computed(() => {
      if (props.title !== undefined && props.title !== null && props.title.length !== 0) {
        return props.title;
      }

      if (editRange.value !== null) {
        const model = editRange.value.init;
        const date = getNativeDateFn.value(model);

        return (
          innerLocale.value.daysShort[date.getDay()] +
          ', ' +
          innerLocale.value.monthsShort[model.month - 1] +
          ' ' +
          model.day +
          lineStr +
          '?'
        );
      }

      if (daysInModel.value === 0) {
        return lineStr;
      }

      if (daysInModel.value > 1) {
        return `${daysInModel.value} ${innerLocale.value.pluralDay}`;
      }

      const model = daysModel.value[0];
      const date = getNativeDateFn.value(model);

      if (isNaN(date.valueOf()) === true) {
        return lineStr;
      }

      if (innerLocale.value.headerTitle !== undefined) {
        return innerLocale.value.headerTitle(date, model);
      }

      return (
        innerLocale.value.daysShort[date.getDay()] +
        ', ' +
        innerLocale.value.monthsShort[model.month - 1] +
        ' ' +
        model.day
      );
    });

    const minSelectedModel = computed(() => {
      const model = daysModel.value
        .concat(rangeModel.value.map((range) => range.from))
        .sort((a, b) => a.year - b.year || a.month - b.month);

      return model[0];
    });

    const maxSelectedModel = computed(() => {
      const model = daysModel.value
        .concat(rangeModel.value.map((range) => range.to))
        .sort((a, b) => b.year - a.year || b.month - a.month);

      return model[0];
    });

    const headerSubtitle = computed(() => {
      if (props.subtitle !== undefined && props.subtitle !== null && props.subtitle.length !== 0) {
        return props.subtitle;
      }

      if (daysInModel.value === 0) {
        return lineStr;
      }

      if (daysInModel.value > 1) {
        const from = minSelectedModel.value;
        const to = maxSelectedModel.value;
        const month = innerLocale.value.monthsShort;

        let label = `${convertLabelYear(from.year)} ${month[from.month - 1]}`;

        if (from.year !== to.year) {
          label += ` ${lineStr} ${convertLabelYear(to.year)} ${month[to.month - 1]}`;
        } else if (from.month !== to.month) {
          label += ` ${lineStr} ${month[to.month - 1]}`;
        }

        return label;
      }

      return convertLabelYear(daysModel.value[0].year);
    });

    /**
     * 判斷props轉換年份
     * @param {*} tempYear 年份
     * @param needText 是否需要文字呈現
     * @returns String 轉換後年份文字
     */
    const convertLabelYear = (tempYear, needText = true) => {
      if ('ROC' !== props.calendar) {
        return tempYear;
      }

      const ROCNum = parseInt(tempYear, 10) - 1911;
      if (ROCNum < 1) {
        return needText ? `西元 ${tempYear} 年` : tempYear;
      }

      return needText ? `民國 ${ROCNum} 年` : ROCNum;
    };

    const dateArrow = computed(() => {
      const val = [$q.iconSet.datetime.arrowLeft, $q.iconSet.datetime.arrowRight];
      return $q.lang.rtl === true ? val.reverse() : val;
    });

    const computedFirstDayOfWeek = computed(() =>
      props.firstDayOfWeek !== undefined
        ? Number(props.firstDayOfWeek)
        : innerLocale.value.firstDayOfWeek,
    );

    const daysOfWeek = computed(() => {
      const days = innerLocale.value.daysShort;
      const first = computedFirstDayOfWeek.value;

      return first > 0 ? days.slice(first, 7).concat(days.slice(0, first)) : days;
    });

    const daysInMonth = computed(() => {
      const date = viewModel.value;
      return new Date(date.year, date.month, 0).getDate();
    });

    const evtColor = computed(() =>
      typeof props.eventColor === 'function' ? props.eventColor : () => props.eventColor,
    );

    const minNav = computed(() => {
      if (props.navigationMinYearMonth === undefined) {
        return null;
      }

      const data = props.navigationMinYearMonth.split('/');
      return { year: parseInt(data[0], 10), month: parseInt(data[1], 10) };
    });

    const maxNav = computed(() => {
      if (props.navigationMaxYearMonth === undefined) {
        return null;
      }

      const data = props.navigationMaxYearMonth.split('/');
      return { year: parseInt(data[0], 10), month: parseInt(data[1], 10) };
    });

    const navBoundaries = computed(() => {
      const data = {
        month: { prev: true, next: true },
        year: { prev: true, next: true },
      };

      if (minNav.value !== null && minNav.value.year >= viewModel.value.year) {
        data.year.prev = false;
        if (
          minNav.value.year === viewModel.value.year &&
          minNav.value.month >= viewModel.value.month
        ) {
          data.month.prev = false;
        }
      }

      if (maxNav.value !== null && maxNav.value.year <= viewModel.value.year) {
        data.year.next = false;
        if (
          maxNav.value.year === viewModel.value.year &&
          maxNav.value.month <= viewModel.value.month
        ) {
          data.month.next = false;
        }
      }

      return data;
    });

    const daysMap = computed(() => {
      const map = {};

      daysModel.value.forEach((entry) => {
        const hash = getMonthHash(entry);

        if (map[hash] === undefined) {
          map[hash] = [];
        }

        map[hash].push(entry.day);
      });

      return map;
    });

    const rangeMap = computed(() => {
      const map = {};

      rangeModel.value.forEach((entry) => {
        const hashFrom = getMonthHash(entry.from);
        const hashTo = getMonthHash(entry.to);

        if (map[hashFrom] === undefined) {
          map[hashFrom] = [];
        }

        map[hashFrom].push({
          from: entry.from.day,
          to: hashFrom === hashTo ? entry.to.day : undefined,
          range: entry,
        });

        if (hashFrom < hashTo) {
          let hash;
          const { year: tempYear, month } = entry.from;
          const cur =
            month < 12 ? { year: tempYear, month: month + 1 } : { year: tempYear + 1, month: 1 };

          while (getMonthHash(cur) <= hashTo) {
            hash = getMonthHash(cur);
            if (map[hash] === undefined) {
              map[hash] = [];
            }

            map[hash].push({
              from: undefined,
              to: hash === hashTo ? entry.to.day : undefined,
              range: entry,
            });

            cur.month += 1;
            if (cur.month > 12) {
              cur.year += 1;
              cur.month = 1;
            }
          }
        }
      });

      return map;
    });

    const rangeView = computed(() => {
      if (editRange.value === null) {
        return undefined;
      }

      const { init, initHash, final, finalHash } = editRange.value;

      const [from, to] = initHash <= finalHash ? [init, final] : [final, init];

      const fromHash = getMonthHash(from);
      const toHash = getMonthHash(to);

      if (fromHash !== viewMonthHash.value && toHash !== viewMonthHash.value) {
        return undefined;
      }

      const tempView = {};

      if (fromHash === viewMonthHash.value) {
        tempView.from = from.day;
        tempView.includeFrom = true;
      } else {
        tempView.from = 1;
      }

      if (toHash === viewMonthHash.value) {
        tempView.to = to.day;
        tempView.includeTo = true;
      } else {
        tempView.to = daysInMonth.value;
      }

      return tempView;
    });

    const viewMonthHash = computed(() => getMonthHash(viewModel.value));

    const selectionDaysMap = computed(() => {
      const map = {};

      if (props.options === undefined) {
        for (let i = 1; i <= daysInMonth.value; i++) {
          map[i] = true;
        }

        return map;
      }

      const fn =
        typeof props.options === 'function'
          ? props.options
          : (date) => props.options.includes(date);

      for (let i = 1; i <= daysInMonth.value; i++) {
        const dayHash = viewMonthHash.value + '/' + pad(i);
        map[i] = fn(dayHash);
      }

      return map;
    });

    const eventDaysMap = computed(() => {
      const map = {};

      if (props.events === undefined) {
        for (let i = 1; i <= daysInMonth.value; i++) {
          map[i] = false;
        }
      } else {
        const fn =
          typeof props.events === 'function' ? props.events : (date) => props.events.includes(date);

        for (let i = 1; i <= daysInMonth.value; i++) {
          const dayHash = viewMonthHash.value + '/' + pad(i);
          map[i] = fn(dayHash) === true && evtColor.value(dayHash);
        }
      }

      return map;
    });

    const viewDays = computed(() => {
      const { year: tempYear, month } = viewModel.value;

      const date = new Date(tempYear, month - 1, 1);
      const endDay = new Date(tempYear, month - 1, 0).getDate();

      return {
        days: date.getDay() - computedFirstDayOfWeek.value - 1,
        endDay,
      };
    });

    const days = computed(() => {
      const res = [];
      const { days: tempDays, endDay } = viewDays.value;

      const len = tempDays < 0 ? tempDays + 7 : tempDays;
      if (len < 6) {
        for (let i = endDay - len; i <= endDay; i++) {
          res.push({ i, fill: true });
        }
      }

      const index = res.length;

      for (let i = 1; i <= daysInMonth.value; i++) {
        const day = { i, event: eventDaysMap.value[i], classes: [] };

        if (selectionDaysMap.value[i] === true) {
          day.in = true;
          day.flat = true;
        }

        res.push(day);
      }

      // if current view has days in model
      if (daysMap.value[viewMonthHash.value] !== undefined) {
        daysMap.value[viewMonthHash.value].forEach((day) => {
          const i = index + day - 1;
          Object.assign(res[i], {
            selected: true,
            unelevated: true,
            flat: false,
            color: computedColor.value,
            textColor: computedTextColor.value,
          });
        });
      }

      // if current view has ranges in model
      if (rangeMap.value[viewMonthHash.value] !== undefined) {
        rangeMap.value[viewMonthHash.value].forEach((entry) => {
          if (entry.from !== undefined) {
            const from = index + entry.from - 1;
            const to = index + (entry.to || daysInMonth.value) - 1;

            for (let day = from; day <= to; day++) {
              Object.assign(res[day], {
                range: entry.range,
                unelevated: true,
                color: computedColor.value,
                textColor: computedTextColor.value,
              });
            }

            Object.assign(res[from], {
              rangeFrom: true,
              flat: false,
            });

            if (entry.to !== undefined) {
              Object.assign(res[to], {
                rangeTo: true,
                flat: false,
              });
            }
          } else if (entry.to !== undefined) {
            const to = index + entry.to - 1;

            for (let day = index; day <= to; day++) {
              Object.assign(res[day], {
                range: entry.range,
                unelevated: true,
                color: computedColor.value,
                textColor: computedTextColor.value,
              });
            }

            Object.assign(res[to], {
              flat: false,
              rangeTo: true,
            });
          } else {
            const to = index + daysInMonth.value - 1;
            for (let day = index; day <= to; day++) {
              Object.assign(res[day], {
                range: entry.range,
                unelevated: true,
                color: computedColor.value,
                textColor: computedTextColor.value,
              });
            }
          }
        });
      }

      if (rangeView.value !== undefined) {
        const from = index + rangeView.value.from - 1;
        const to = index + rangeView.value.to - 1;

        for (let day = from; day <= to; day++) {
          res[day].color = computedColor.value;
          res[day].editRange = true;
        }

        if (rangeView.value.includeFrom === true) {
          res[from].editRangeFrom = true;
        }
        if (rangeView.value.includeTo === true) {
          res[to].editRangeTo = true;
        }
      }

      if (
        viewModel.value.year === today.value.year &&
        viewModel.value.month === today.value.month
      ) {
        res[index + today.value.day - 1].today = true;
      }

      const left = res.length % 7;
      if (left > 0) {
        const afterDays = 7 - left;
        for (let i = 1; i <= afterDays; i++) {
          res.push({ i, fill: true });
        }
      }

      res.forEach((day) => {
        let cls = 'q-date__calendar-item ';

        if (day.fill === true) {
          cls += 'q-date__calendar-item--fill';
        } else {
          cls += `q-date__calendar-item--${day.in === true ? 'in' : 'out'}`;

          if (day.range !== undefined) {
            if (day.rangeTo === true) {
              cls += ' q-date__range-to';
            } else if (day.rangeFrom === true) {
              cls += ' q-date__range-from';
            } else {
              cls += ' q-date__range';
            }
          }

          if (day.editRange === true) {
            cls += ` q-date__edit-range${day.editRangeFrom === true ? '-from' : ''}${day.editRangeTo === true ? '-to' : ''}`;
          }

          if (day.range !== undefined || day.editRange === true) {
            cls += ` text-${day.color}`;
          }
        }

        day.classes = cls;
      });

      return res;
    });

    const attributes = computed(() => (props.disable === true ? { 'aria-disabled': 'true' } : {}));

    watch(
      () => props.modelValue,
      (v) => {
        if (lastEmitValue === v) {
          lastEmitValue = 0;
        } else {
          const model = getViewModel(innerMask.value, innerLocale.value);
          updateViewModel(model.year, model.month, model);
        }
      },
    );

    watch(view, () => {
      if (blurTargetRef.value !== null && proxy.$el.contains(document.activeElement) === true) {
        blurTargetRef.value.focus();
      }
    });

    watch(
      () => viewModel.value.year + '|' + viewModel.value.month,
      () => {
        emit('navigation', {
          year: viewModel.value.year,
          month: viewModel.value.month,
        });
      },
    );

    watch(mask, (val) => {
      updateValue(val, innerLocale.value, 'mask');
      innerMask.value = val;
    });

    watch(locale, (val) => {
      updateValue(innerMask.value, val, 'locale');
      innerLocale.value = val;
    });

    function setToday() {
      const { year: tempYear, month, day } = today.value;

      const date = {
        // contains more props than needed (hour, minute, second, millisecond)
        // but those aren't used in the processing of this "date" variable
        ...viewModel.value,

        // overwriting with today's date
        year: tempYear,
        month,
        day,
      };

      const monthMap = daysMap.value[getMonthHash(date)];

      if (monthMap === undefined || monthMap.includes(date.day) === false) {
        addToModel(date);
      }

      setCalendarTo(date.year, date.month);
    }

    function setView(viewMode) {
      if (viewIsValid(viewMode) === true) {
        view.value = viewMode;
      }
    }

    function offsetCalendar(type, descending) {
      if (['month', 'year'].includes(type)) {
        const fn = type === 'month' ? goToMonth : goToYear;
        fn(descending === true ? -1 : 1);
      }
    }

    function setCalendarTo(tempYear, month) {
      view.value = 'Calendar';
      updateViewModel(tempYear, month);
    }
    function __splitDate(str, tempMask, dateLocale, calendar, defaultModel) {
      const date = {
        year: null,
        month: null,
        day: null,
        hour: null,
        minute: null,
        second: null,
        millisecond: null,
        timezoneOffset: null,
        dateHash: null,
        timeHash: null,
      };

      if (!defaultModel) {
        Object.assign(date, defaultModel);
      }

      if (!str || str === '' || typeof str !== 'string') {
        return date;
      }

      if (!tempMask) {
        tempMask = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
      }

      // const langOpts = getDateLocale(dateLocale, Lang.props);
      const langOpts = getDateLocale(dateLocale, $d.lang.date);
      const months = langOpts.months;
      const monthsShort = langOpts.monthsShort;

      const { regex, map } = getRegexData(tempMask, langOpts);

      const match = str.match(regex);

      if (!match) {
        return date;
      }

      let tzString = '';

      if (map.X || map.x) {
        const stamp = parseInt(match[map.X ? map.X : map.x], 10);

        if (isNaN(stamp) === true || stamp < 0) {
          return date;
        }

        const d = new Date(stamp * (map.X ? 1000 : 1));

        date.year = d.getFullYear();
        date.month = d.getMonth() + 1;
        date.day = d.getDate();
        date.hour = d.getHours();
        date.minute = d.getMinutes();
        date.second = d.getSeconds();
        date.millisecond = d.getMilliseconds();
      } else {
        if (map.YYYY) {
          date.year = parseInt(match[map.YYYY], 10);
        } else if (map.YY) {
          const y = parseInt(match[map.YY], 10);
          date.year = y < 0 ? y : 2000 + y;
        }

        if (map.M) {
          date.month = parseInt(match[map.M], 10);
          if (date.month < 1 || date.month > 12) {
            return date;
          }
        } else if (map.MMM) {
          date.month = monthsShort.indexOf(match[map.MMM]) + 1;
        } else if (map.MMMM) {
          date.month = months.indexOf(match[map.MMMM]) + 1;
        }

        if (map.D) {
          date.day = parseInt(match[map.D], 10);

          if (!date.year || !date.month || date.day < 1) {
            return date;
          }

          const maxDay = new Date(date.year, date.month, 0).getDate();

          if (date.day > maxDay) {
            return date;
          }
        }

        if (map.H) {
          date.hour = parseInt(match[map.H], 10) % 24;
        } else if (map.h) {
          date.hour = parseInt(match[map.h], 10) % 12;
          if (
            (map.A && match[map.A] === 'PM') ||
            (map.a && match[map.a] === 'pm') ||
            (map.aa && match[map.aa] === 'p.m.')
          ) {
            date.hour += 12;
          }
          date.hour %= 24;
        }

        if (map.m) {
          date.minute = parseInt(match[map.m], 10) % 60;
        }

        if (map.s) {
          date.second = parseInt(match[map.s], 10) % 60;
        }

        if (map.S) {
          date.millisecond = parseInt(match[map.S], 10) * 10 ** (3 - match[map.S].length);
        }

        if (map.Z || map.ZZ) {
          tzString = map.Z ? match[map.Z].replace(':', '') : match[map.ZZ];
          date.timezoneOffset =
            (tzString[0] === '+' ? -1 : 1) * (60 * tzString.slice(1, 3) + 1 * tzString.slice(3, 5));
        }
      }

      date.dateHash = pad(date.year, 6) + '/' + pad(date.month) + '/' + pad(date.day);
      date.timeHash = pad(date.hour) + ':' + pad(date.minute) + ':' + pad(date.second) + tzString;

      return date;
    }

    function setEditingRange(from, to) {
      if (props.range === false || !from) {
        editRange.value = null;
        return;
      }

      const init = { ...viewModel.value, ...from };
      const final = to !== undefined ? { ...viewModel.value, ...to } : init;

      editRange.value = {
        init,
        initHash: getDayHash(init),
        final,
        finalHash: getDayHash(final),
      };

      setCalendarTo(init.year, init.month);
    }

    function getMask() {
      return props.mask;
    }

    function decodeString(date, tempMask, tempLocale) {
      return __splitDate(date, tempMask, tempLocale, props.calendar, {
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0,
      });
    }

    function getViewModel(tempMask, tempLocale) {
      const model =
        Array.isArray(props.modelValue) === true
          ? props.modelValue
          : props.modelValue
            ? [props.modelValue]
            : [];

      if (model.length === 0) {
        return getDefaultViewModel();
      }

      const target = model[model.length - 1];
      const decoded = decodeString(
        target.from !== undefined ? target.from : target,
        tempMask,
        tempLocale,
      );

      return decoded.dateHash === null ? getDefaultViewModel() : decoded;
    }

    function getDefaultViewModel() {
      let tempYear;
      let tempMonth;

      if (props.defaultYearMonth !== undefined) {
        const d = props.defaultYearMonth.split('/');
        tempYear = parseInt(d[0], 10);
        tempMonth = parseInt(d[1], 10);
      } else {
        // may come from data() where computed
        // props are not yet available
        const d = today.value !== undefined ? today.value : getCurrentDate();

        tempYear = d.year;
        tempMonth = d.month;
      }

      return {
        year: tempYear,
        month: tempMonth,
        day: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0,
        dateHash: tempYear + '/' + pad(tempMonth) + '/01',
      };
    }

    function goToMonth(offset) {
      let tempYear = viewModel.value.year;
      let month = Number(viewModel.value.month) + offset;

      if (month === 13) {
        month = 1;
        tempYear += 1;
      } else if (month === 0) {
        month = 12;
        tempYear -= 1;
      }

      updateViewModel(tempYear, month);
      if (isImmediate.value === true) {
        emitImmediately('month');
      }
    }

    function goToYear(offset) {
      const tempYear = Number(viewModel.value.year) + offset;
      updateViewModel(tempYear, viewModel.value.month);
      if (isImmediate.value) {
        emitImmediately('year');
      }
    }

    function setYear(tempYear) {
      updateViewModel(tempYear, viewModel.value.month);
      view.value = props.defaultView === 'Years' ? 'Months' : 'Calendar';
      if (isImmediate.value) {
        emitImmediately('year');
      }
    }

    function setMonth(month) {
      updateViewModel(viewModel.value.year, month);
      view.value = 'Calendar';
      if (isImmediate.value) {
        emitImmediately('month');
      }
    }

    function toggleDate(date, monthHash) {
      const month = daysMap.value[monthHash];

      const fn =
        month !== undefined && month.includes(date.day) === true ? removeFromModel : addToModel;

      fn(date);
    }

    function getShortDate(date) {
      return {
        year: date.year,
        month: date.month,
        day: date.day,
      };
    }

    function updateViewModel(tempYear, month, time) {
      if (minNav.value !== null && tempYear <= minNav.value.year) {
        if (month < minNav.value.month || tempYear < minNav.value.year) {
          month = minNav.value.month;
        }
        tempYear = minNav.value.year;
      }

      if (maxNav.value !== null && tempYear >= maxNav.value.year) {
        if (month > maxNav.value.month || tempYear > maxNav.value.year) {
          month = maxNav.value.month;
        }
        tempYear = maxNav.value.year;
      }

      if (time !== undefined) {
        const { hour, minute, second, millisecond, timezoneOffset, timeHash } = time;
        Object.assign(viewModel.value, {
          hour,
          minute,
          second,
          millisecond,
          timezoneOffset,
          timeHash,
        });
      }

      const newHash = tempYear + '/' + pad(month) + '/01';

      if (newHash !== viewModel.value.dateHash) {
        monthDirection.value =
          viewModel.value.dateHash < newHash === ($q.lang.rtl !== true) ? 'left' : 'right';
        if (tempYear !== viewModel.value.year) {
          yearDirection.value = monthDirection.value;
        }

        nextTick(() => {
          startYear.value =
            tempYear - (tempYear % yearsInterval) - (tempYear < 0 ? yearsInterval : 0);
          Object.assign(viewModel.value, {
            year: tempYear,
            month,
            day: 1,
            dateHash: newHash,
          });
        });
      }
    }

    function emitValue(val, action, date) {
      const value = val !== null && val.length === 1 && props.multiple === false ? val[0] : val;

      lastEmitValue = value;

      const { reason, details } = getEmitParams(action, date);

      emit('update:modelValue', value, reason, details);
    }

    function emitImmediately(reason) {
      const date =
        daysModel.value[0] !== undefined && daysModel.value[0].dateHash !== null
          ? { ...daysModel.value[0] }
          : { ...viewModel.value }; // inherit day, hours, minutes, milliseconds...

      // nextTick required because of animation delay in viewModel
      nextTick(() => {
        date.year = viewModel.value.year;
        date.month = viewModel.value.month;

        const maxDay = new Date(date.year, date.month, 0).getDate();

        date.day = Math.min(Math.max(1, date.day), maxDay);

        const value = encodeEntry(date);
        lastEmitValue = value;

        const { details } = getEmitParams('', date);
        emit('update:modelValue', value, reason, details);
      });
    }

    function getEmitParams(action, date) {
      return date.from !== undefined
        ? {
            reason: `${action}-range`,
            details: {
              ...getShortDate(date.target),
              from: getShortDate(date.from),
              to: getShortDate(date.to),
            },
          }
        : {
            reason: `${action}-day`,
            details: getShortDate(date),
          };
    }

    function encodeEntry(date, tempMask, tempLocale) {
      return date.from !== undefined
        ? {
            from: encodeObjectFn.value(date.from, tempMask, tempLocale),
            to: encodeObjectFn.value(date.to, tempMask, tempLocale),
          }
        : encodeObjectFn.value(date, tempMask, tempLocale);
    }

    function addToModel(date) {
      let value;

      if (props.multiple === true) {
        if (date.from !== undefined) {
          // we also need to filter out intersections

          const fromHash = getDayHash(date.from);
          const toHash = getDayHash(date.to);

          const tempDays = daysModel.value.filter(
            (day) => day.dateHash < fromHash || day.dateHash > toHash,
          );

          const ranges = rangeModel.value.filter(
            ({ from, to }) => to.dateHash < fromHash || from.dateHash > toHash,
          );

          value = tempDays
            .concat(ranges)
            .concat(date)
            .map((entry) => encodeEntry(entry));
        } else {
          const model = normalizedModel.value.slice();
          model.push(encodeEntry(date));
          value = model;
        }
      } else {
        value = encodeEntry(date);
      }

      emitValue(value, 'add', date);
    }

    function removeFromModel(date) {
      if (props.noUnset === true) {
        return;
      }

      let model = null;

      if (props.multiple === true && Array.isArray(props.modelValue) === true) {
        const val = encodeEntry(date);

        if (date.from !== undefined) {
          model = props.modelValue.filter((tempDate) =>
            tempDate.from !== undefined
              ? tempDate.from !== val.from && tempDate.to !== val.to
              : true,
          );
        } else {
          model = props.modelValue.filter((tempDate) => tempDate !== val);
        }

        if (model.length === 0) {
          model = null;
        }
      }

      emitValue(model, 'remove', date);
    }

    function updateValue(tempMask, tempLocale, reason) {
      const model = daysModel.value
        .concat(rangeModel.value)
        .map((entry) => encodeEntry(entry, tempMask, tempLocale))
        .filter((entry) => {
          return entry.from !== undefined
            ? entry.from.dateHash !== null && entry.to.dateHash !== null
            : entry.dateHash !== null;
        });

      emit('update:modelValue', (props.multiple === true ? model : model[0]) || null, reason);
    }

    function getHeader() {
      if (props.minimal === true) return null;
      return h(
        'div',
        {
          class: 'q-date__header ' + headerClass.value,
        },
        [
          h(
            'div',
            {
              class: 'relative-position',
            },
            [
              h(
                Transition,
                {
                  name: 'q-transition--fade',
                },
                () =>
                  h(
                    'div',
                    {
                      key: 'h-yr-' + headerSubtitle.value,
                      class:
                        'q-date__header-subtitle q-date__header-link ' +
                        (view.value === 'Years' ? 'q-date__header-link--active' : 'cursor-pointer'),
                      tabindex: tabindex.value,
                      ...getCache('vY', {
                        onClick() {
                          view.value = 'Years';
                        },
                        onKeyup(e) {
                          if (e.keyCode === 13) {
                            view.value = 'Years';
                          }
                        },
                      }),
                    },
                    [headerSubtitle.value],
                  ),
              ),
            ],
          ),

          h(
            'div',
            {
              class: 'q-date__header-title relative-position flex no-wrap',
            },
            [
              h(
                'div',
                {
                  class: 'relative-position col',
                },
                [
                  h(
                    Transition,
                    {
                      name: 'q-transition--fade',
                    },
                    () =>
                      h(
                        'div',
                        {
                          key: 'h-sub' + headerTitle.value,
                          class:
                            'q-date__header-title-label q-date__header-link ' +
                            (view.value === 'Calendar'
                              ? 'q-date__header-link--active'
                              : 'cursor-pointer'),
                          tabindex: tabindex.value,
                          ...getCache('vC', {
                            onClick() {
                              view.value = 'Calendar';
                            },
                            onKeyup(e) {
                              if (e.keyCode === 13) {
                                view.value = 'Calendar';
                              }
                            },
                          }),
                        },
                        [headerTitle.value],
                      ),
                  ),
                ],
              ),

              props.todayBtn === true
                ? h(QBtn, {
                    class: 'q-date__header-today self-start',
                    icon: $q.iconSet.datetime.today,
                    flat: true,
                    size: 'sm',
                    round: true,
                    tabindex: tabindex.value,
                    onClick: setToday,
                  })
                : null,
            ],
          ),
        ],
      );
    }

    function getNavigation({ label, type, key, dir, goTo, boundaries, cls }) {
      return [
        h(
          'div',
          {
            class: 'row items-center q-date__arrow',
          },
          [
            h(QBtn, {
              round: true,
              dense: true,
              size: 'sm',
              flat: true,
              icon: dateArrow.value[0],
              tabindex: tabindex.value,
              disable: boundaries.prev === false,
              ...getCache('go-#' + type, {
                onClick() {
                  goTo(-1);
                },
              }),
            }),
          ],
        ),

        h(
          'div',
          {
            class: 'relative-position overflow-hidden flex flex-center' + cls,
          },
          [
            h(
              Transition,
              {
                name: 'q-transition--jump-' + dir,
              },
              () =>
                h('div', { key }, [
                  h(QBtn, {
                    flat: true,
                    dense: true,
                    noCaps: true,
                    label,
                    tabindex: tabindex.value,
                    ...getCache('view#' + type, {
                      onClick: () => {
                        view.value = type;
                      },
                    }),
                  }),
                ]),
            ),
          ],
        ),

        h(
          'div',
          {
            class: 'row items-center q-date__arrow',
          },
          [
            h(QBtn, {
              round: true,
              dense: true,
              size: 'sm',
              flat: true,
              icon: dateArrow.value[1],
              tabindex: tabindex.value,
              disable: boundaries.next === false,
              ...getCache('go+#' + type, {
                onClick() {
                  goTo(1);
                },
              }),
            }),
          ],
        ),
      ];
    }

    const renderViews = {
      Calendar: () => [
        h(
          'div',
          {
            key: 'calendar-view',
            class: 'q-date__view q-date__calendar',
          },
          [
            h(
              'div',
              {
                class: 'q-date__navigation row items-center no-wrap',
              },
              getNavigation({
                label: convertLabelYear(viewModel.value.year),
                type: 'Years',
                key: viewModel.value.year,
                dir: yearDirection.value,
                goTo: goToYear,
                boundaries: navBoundaries.value.year,
                cls: '',
              }).concat(
                getNavigation({
                  label: innerLocale.value.months[viewModel.value.month - 1],
                  type: 'Months',
                  key: viewModel.value.month,
                  dir: monthDirection.value,
                  goTo: goToMonth,
                  boundaries: navBoundaries.value.month,
                  cls: ' col',
                }),
              ),
            ),

            h(
              'div',
              {
                class: 'q-date__calendar-weekdays row items-center no-wrap',
              },
              daysOfWeek.value.map((day) =>
                h('div', { class: 'q-date__calendar-item' }, [h('div', day)]),
              ),
            ),

            h(
              'div',
              {
                class: 'q-date__calendar-days-container relative-position overflow-hidden',
              },
              [
                h(
                  Transition,
                  {
                    name: 'q-transition--slide-' + monthDirection.value,
                  },
                  () =>
                    h(
                      'div',
                      {
                        key: viewMonthHash.value,
                        class: 'q-date__calendar-days fit',
                      },
                      days.value.map((day) =>
                        h('div', { class: day.classes }, [
                          day.in === true
                            ? h(
                                QBtn,
                                {
                                  class: day.today === true ? 'q-date__today' : '',
                                  dense: true,
                                  flat: day.flat,
                                  unelevated: day.unelevated,
                                  color: day.color,
                                  textColor: day.textColor,
                                  label: day.i,
                                  tabindex: tabindex.value,
                                  ...getCache('day#' + day.i, {
                                    onClick: () => {
                                      onDayClick(day.i);
                                    },
                                    onMouseover: () => {
                                      onDayMouseover(day.i);
                                    },
                                  }),
                                },
                                day.event !== false
                                  ? () =>
                                      h('div', {
                                        class: 'q-date__event bg-' + day.event,
                                      })
                                  : null,
                              )
                            : h('div', '' + day.i),
                        ]),
                      ),
                    ),
                ),
              ],
            ),
          ],
        ),
      ],

      Months() {
        const currentYear = viewModel.value.year === today.value.year;
        const isDisabled = (month) => {
          return (
            (minNav.value !== null &&
              viewModel.value.year === minNav.value.year &&
              minNav.value.month > month) ||
            (maxNav.value !== null &&
              viewModel.value.year === maxNav.value.year &&
              maxNav.value.month < month)
          );
        };

        const content = innerLocale.value.monthsShort.map((month, i) => {
          const active = viewModel.value.month === i + 1;

          return h(
            'div',
            {
              class: 'q-date__months-item flex flex-center',
            },
            [
              h(QBtn, {
                class: currentYear === true && today.value.month === i + 1 ? 'q-date__today' : null,
                flat: active !== true,
                label: month,
                unelevated: active,
                color: active === true ? computedColor.value : null,
                textColor: active === true ? computedTextColor.value : null,
                tabindex: tabindex.value,
                disable: isDisabled(i + 1),
                ...getCache('month#' + i, {
                  onClick: () => {
                    setMonth(i + 1);
                  },
                }),
              }),
            ],
          );
        });

        if (props.yearsInMonthView) {
          content.unshift(
            h('div', { class: 'row no-wrap full-width' }, [
              getNavigation({
                label: viewModel.value.year,
                type: 'Years',
                key: viewModel.value.year,
                dir: yearDirection.value,
                goTo: goToYear,
                boundaries: navBoundaries.value.year,
                cls: ' col',
              }),
            ]),
          );
        }

        return h(
          'div',
          {
            key: 'months-view',
            class: 'q-date__view q-date__months flex flex-center',
          },
          content,
        );
      },

      Years() {
        const start = startYear.value;
        const stop = start + yearsInterval;
        const years = [];

        const isDisabled = (tempYear) => {
          return (
            (minNav.value !== null && minNav.value.year > tempYear) ||
            (maxNav.value !== null && maxNav.value.year < tempYear)
          );
        };

        for (let i = start; i <= stop; i++) {
          const active = viewModel.value.year === i;

          years.push(
            h(
              'div',
              {
                class: 'q-date__years-item flex flex-center',
              },
              [
                h(QBtn, {
                  key: 'yr' + i,
                  class: today.value.year === i ? 'q-date__today' : null,
                  flat: !active,
                  label: props.calendar === 'ROC' ? parseInt(i, 10) - 1911 : i,
                  dense: true,
                  unelevated: active,
                  color: active === true ? computedColor.value : null,
                  textColor: active === true ? computedTextColor.value : null,
                  tabindex: tabindex.value,
                  disable: isDisabled(i),
                  ...getCache('yr#' + i, {
                    onClick: () => {
                      setYear(i);
                    },
                  }),
                }),
              ],
            ),
          );
        }

        return h(
          'div',
          {
            class: 'q-date__view q-date__years flex flex-center',
          },
          [
            h(
              'div',
              {
                class: 'col-auto',
              },
              [
                h(QBtn, {
                  round: true,
                  dense: true,
                  flat: true,
                  icon: dateArrow.value[0],
                  tabindex: tabindex.value,
                  disable: isDisabled(start),
                  ...getCache('y-', {
                    onClick: () => {
                      startYear.value -= yearsInterval;
                    },
                  }),
                }),
              ],
            ),

            h(
              'div',
              {
                class: 'q-date__years-content col self-stretch row items-center',
              },
              years,
            ),

            h(
              'div',
              {
                class: 'col-auto',
              },
              [
                h(QBtn, {
                  round: true,
                  dense: true,
                  flat: true,
                  icon: dateArrow.value[1],
                  tabindex: tabindex.value,
                  disable: isDisabled(stop),
                  ...getCache('y+', {
                    onClick: () => {
                      startYear.value += yearsInterval;
                    },
                  }),
                }),
              ],
            ),
          ],
        );
      },
    };

    function onDayClick(dayIndex) {
      const day = { ...viewModel.value, day: dayIndex };

      if (props.range === false) {
        toggleDate(day, viewMonthHash.value);
        return;
      }

      if (editRange.value === null) {
        const dayProps = days.value.find(
          (tempDay) => tempDay.fill !== true && tempDay.i === dayIndex,
        );

        if (props.noUnset !== true && dayProps.range !== undefined) {
          removeFromModel({
            target: day,
            from: dayProps.range.from,
            to: dayProps.range.to,
          });
          return;
        }

        if (dayProps.selected === true) {
          removeFromModel(day);
          return;
        }

        const initHash = getDayHash(day);

        editRange.value = {
          init: day,
          initHash,
          final: day,
          finalHash: initHash,
        };

        emit('rangeStart', getShortDate(day));
      } else {
        const initHash = editRange.value.initHash;
        const finalHash = getDayHash(day);
        const payload =
          initHash <= finalHash
            ? { from: editRange.value.init, to: day }
            : { from: day, to: editRange.value.init };

        editRange.value = null;
        addToModel(initHash === finalHash ? day : { target: day, ...payload });

        emit('rangeEnd', {
          from: getShortDate(payload.from),
          to: getShortDate(payload.to),
        });
      }
    }

    function onDayMouseover(dayIndex) {
      if (editRange.value !== null) {
        const final = { ...viewModel.value, day: dayIndex };

        Object.assign(editRange.value, {
          final,
          finalHash: getDayHash(final),
        });
      }
    }

    // expose public methods
    Object.assign(proxy, {
      setToday,
      setView,
      offsetCalendar,
      setCalendarTo,
      setEditingRange,
    });

    return () => {
      const content = [
        h(
          'div',
          {
            class: 'q-date__content col relative-position',
          },
          [
            h(
              Transition,
              {
                name: 'q-transition--fade',
              },
              renderViews[view.value],
            ),
          ],
        ),
      ];

      const def = hSlot(slots.default);
      if (def !== undefined) {
        content.push(h('div', { class: 'q-date__actions' }, def));
      }

      if (props.name !== undefined && props.disable !== true) {
        injectFormInput(content, 'push');
      }

      return h(
        'div',
        {
          class: classes.value,
          ...attributes.value,
        },
        [
          getHeader(),

          h(
            'div',
            {
              ref: blurTargetRef,
              class: 'q-date__main col column',
              tabindex: -1,
            },
            content,
          ),
        ],
      );
    };
  },
});
