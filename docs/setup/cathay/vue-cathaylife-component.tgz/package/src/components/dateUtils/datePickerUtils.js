export const regex = {
  ROC: /^([0-9]{3})\/(0[1-9]|1[0-2])\/([0-2][0-9]|3[0-1])/,
  AD: /^([0-9]{4})\/(0[1-9]|1[0-2])\/([0-2][0-9]|3[0-1])/,
};

export const defaultLocale = {
  weekday: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  todayBtn: 'Today',
  clearBtn: 'Clear',
  closeBtn: 'Close',
};

// 民國年與西元年物件差異
export const yearCountDiff = {
  index: {
    year: 1,
    month: 2,
    day: 3,
  },
  row: {
    ROC: 9, // 先設定民國年字串 最大長度
    AD: 10, // 先設定西元年字串 最大長度
  },
  filed: {
    // 民國年與西元年 預期字串長度
    ROC: {
      year: 3,
      month: 2,
      day: 2,
    },
    AD: {
      year: 4,
      month: 2,
      day: 2,
    },
  },
  slash: {
    text: '/',
    offset: {
      ROC: [4, 7],
      AD: [5, 8],
    },
  },
};

/**
 * 確認日期合法性與轉譯日期(轉為西元年)
 * @param { string } date 輸入框字串
 * @returns {Date} 日期物件
 */
export const parseDateObject = (date) => {
  // 不是西元也不是民國格式
  if (!regex.AD.test(date) && !regex.ROC.test(date)) {
    return null;
  }
  const dateList = date.split('/');
  let year = Number(dateList[0]);
  const month = Number(dateList[1]);
  const day = Number(dateList[2]);
  if (regex.ROC.test(date)) {
    year += 1911;
  }
  const fullDay = new Date(year, month, 0);
  if (day > fullDay.getDate() || day < 1) {
    return null;
  }
  return new Date(year, month - 1, day);
};

/**
 * 轉譯時間物件成日期字串
 * @param {Date} date 時間物件
 * @param {string} method 西元年(AD)或民國年(ROC)
 * @returns {string} 日期字串
 */
export const parseDateString = (date, method) => {
  const core = new Date(date);
  let yyyy = core.getFullYear();
  if (method === 'ROC') {
    const rocYear = core.getFullYear() - 1911;
    yyyy = rocYear.toString().padStart(3, 0);
  }
  const mm = (core.getMonth() + 1).toString().padStart(2, 0);
  const dd = core.getDate().toString().padStart(2, 0);
  return `${yyyy}/${mm}/${dd}`;
};

/**
 * 設定年分並格式化日期(YYYY/MM/DD)
 * @param {object} doFormatDate 格式化日期
 * @param {number} setYear 要設定的年
 * @returns {string} 設定並格式化後的日期
 */
const formatDateWithSet = (doFormatDate, setYear) => {
  const year = setYear || doFormatDate.getFullYear();
  const month = (doFormatDate.getMonth() + 1).toString().padStart(2, 0);
  const date = doFormatDate.getDate().toString().padStart(2, 0);
  return parseDateString(new Date(year, month, date), 'AD', false);
};

/**
 * 取得日期選擇其預設值資料物件
 * @param {object} props 元件設定值
 * @returns {object} 日期選擇器用預設資料物件
 */
export const getDatePickerDefault = (props) => {
  const today = new Date();
  // from、to傳入格式應為YYYY/MM/DD，如格式錯誤不另外處理，
  const propsFrom = props.from;
  // 有設定年份起始使用設定值，若無設定或設定格式有誤使用當前日期-80
  const tmpFromDate = new Date(propsFrom || formatDateWithSet(today, today.getFullYear() - 80));
  // 取得年份類型(AD|ROC)，預設西元年(AD)
  const yearCountWay = props.yearCountWay || 'AD';
  // 設定為民國年時且年份起始小於1911將年份設定為1911(民國1年)
  const defaultFromDate =
    yearCountWay === 'ROC' && tmpFromDate.getFullYear() < 1911
      ? formatDateWithSet(today, 1911)
      : parseDateString(tmpFromDate, 'AD', false);

  const propsTo = props.to;

  return {
    today: parseDateString(today, 'AD', false),
    show: false,
    year: today.getFullYear(),
    month: today.getMonth() + 1,
    yearCountWay,
    yearsRange: props.yearsRange || 80, // 取得下拉選單年份每次展開範圍
    from: defaultFromDate,
    // 年份迄有設定年份起始使用設定值，若無設定使用當前日期+80
    to: propsTo || formatDateWithSet(today, today.getFullYear() + 80),
    excludeDays: props.excludeDays || {
      weekday: [],
      days: [],
    },
  };
};

/**
 * 上一個月按鈕
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {object} 回傳年月資料結果
 */
export const goPrevMonth = (datepicker) => {
  const tempPrevYear = datepicker.month == 1 ? datepicker.year - 1 : datepicker.year;
  const tempPrevMonth = datepicker.month == 1 ? 12 : datepicker.month - 1;
  const target = new Date(tempPrevYear, tempPrevMonth - 1);

  if (datepicker.from) {
    const lower = parseDateObject(datepicker.from);
    if (lower.getTime() > target.getTime()) {
      return { goPrev: false };
    }
  }
  return { goPrev: true, nextYear: tempPrevYear, nextMonth: tempPrevMonth };
};

/**
 * 下一個月按鈕
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {object} 回傳年月資料結果
 */
export const goNextMonth = (datepicker) => {
  const tempNextYear = datepicker.month == 12 ? datepicker.year + 1 : datepicker.year;
  const tempNextMonth = datepicker.month == 12 ? 1 : datepicker.month + 1;
  const target = new Date(tempNextYear, tempNextMonth - 1);
  if (datepicker.to) {
    const upper = parseDateObject(datepicker.to);
    if (upper.getTime() < target.getTime()) {
      return { goNext: false };
    }
  }
  return { goNext: true, nextYear: tempNextYear, nextMonth: tempNextMonth };
};

/**
 * 輸出dayList的物件
 * @param {Date} date 日期物件
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {object} 當前/前/後月 的日清單物件
 */
const parseDay = (date, datepicker) => {
  const temp = new Date(date);

  let overRange = false;
  // 上界處理
  if (datepicker.from) {
    overRange ||= parseDateObject(datepicker.from) > temp;
  }

  // 下界處理
  if (datepicker.to) {
    overRange ||= parseDateObject(datepicker.to) < temp;
  }
  // 去除特定星期
  if (datepicker.excludeDays) {
    if (datepicker.excludeDays.weekday) {
      overRange ||= datepicker.excludeDays.weekday.includes(temp.getDay());
    }
    // 去除特定日期
    if (datepicker.excludeDays.days.length) {
      overRange ||= parseDateString(temp, 'AD').includes(datepicker.excludeDays.days);
    }
  }
  overRange ||= datepicker.month < 1 || datepicker.month > 12;

  const today = parseDateString(Date.now(), datepicker.yearCountWay);
  return {
    year: temp.getFullYear(),
    month: temp.getMonth() + 1,
    day: temp.getDate(),
    weekday: temp.getDay(),
    dateString: parseDateString(temp, datepicker.yearCountWay),
    isToday: parseDateString(temp, datepicker.yearCountWay) === today,
    isDisabled: overRange,
  };
};

/**
 * 取得日期選擇器年月日選單
 * @param {object} datepicker 日期選擇器資料物件
 * @param {string} type 取得選單類型(year|month|day)
 * @returns {object} 年份選單 / 月份選單 / 日選單
 */
export const getDateList = (datepicker, type) => {
  if (type === 'year') {
    return getYearList(datepicker);
  }
  if (type === 'month') {
    return getMonthList(datepicker);
  }
  if (type === 'day') {
    return getDayList(datepicker);
  }
  return null;
};

/**
 * 取得年份選單
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {Array} 年份選單
 */
const getYearList = (datepicker) => {
  // 取得上下界
  const yearIndex = yearCountDiff.index.year;
  // from、to 均有預設值
  const fromDate = datepicker.from.match(regex.AD);
  const toDate = datepicker.to.match(regex.AD);
  // 取得界限週期
  // yearsRange 跟上下界也有很大關聯
  const endYear = Math.max(datepicker.year - datepicker.yearsRange, 1911);

  const tempYearList = [];
  // 改code 由最近滾到最遠
  for (let i = Number(toDate[yearIndex]); i > endYear; i--) {
    if (fromDate && i < Number(fromDate[yearIndex])) {
      continue;
    }
    if (toDate && i > Number(toDate[yearIndex])) {
      continue;
    }
    tempYearList.push(i);
  }
  return tempYearList;
};

/**
 * 取得月份選單
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {Array} 月份選單
 */
const getMonthList = (datepicker) => {
  const fromDate = datepicker.from.match(regex.AD);
  const toDate = datepicker.to.match(regex.AD);
  const yearIndex = yearCountDiff.index.year;
  const monIndex = yearCountDiff.index.month;

  let startMonth = 1;
  let endMonth = 12;

  const fromYear = Number(fromDate[yearIndex]);
  const toYear = Number(toDate[yearIndex]);
  // 當他選到下限年時
  if (fromDate && datepicker.year == fromYear) {
    startMonth = Number(fromDate[monIndex]);
  }
  // 當他選到上限年時
  if (toDate && datepicker.year == toYear) {
    endMonth = Number(toDate[monIndex]);
  }
  const tempMonthList = [];
  for (let index = startMonth; index <= endMonth; index++) {
    tempMonthList.push(index);
  }
  return tempMonthList;
};

/**
 * 取得日選單
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {Array} 日選單
 */
const getDayList = (datepicker) => {
  let rows = [];
  // 處理上月日期 計算偏移量
  const tempPreYear = datepicker.month == 1 ? datepicker.year - 1 : datepicker.year;
  const tempPreMonth = datepicker.month == 1 ? 12 : datepicker.month - 1;
  const preDay = new Date(tempPreYear, tempPreMonth, 1).getDay();
  for (let index = preDay; index > 0; index--) {
    const temp = new Date(tempPreYear, tempPreMonth, -index + 1);
    rows.push(parseDay(temp, datepicker));
  }

  const chooseYearMon = new Date(datepicker.year, datepicker.month, 0);
  const tempDayList = [];

  // 處理當月日期
  const curDay = chooseYearMon.getDate();
  for (let index = 1; index <= curDay; index++) {
    const temp = new Date(datepicker.year, datepicker.month - 1, index);
    rows.push(parseDay(temp, datepicker));
    if (rows.length >= 7) {
      tempDayList.push(rows);
      rows = [];
    }
  }

  // 處理下月日期 計算偏移量
  const nextDay = 6 - chooseYearMon.getDay();
  for (let index = 1; index <= nextDay; index++) {
    const temp = new Date(datepicker.year, datepicker.month, index);
    rows.push(parseDay(temp, datepicker));
    if (rows.length >= 7) {
      tempDayList.push(rows);
      rows = [];
    }
  }
  return tempDayList;
};

/**
 * 格式化輸入文字
 * @param {string} newVal 當前資料
 * @param {string} prevVal 前一次資料
 * @param {object} datepicker 日期選擇器資料物件
 * @returns {string} 格式化後結果
 */
export const formatInput = (newVal, prevVal, datepicker) => {
  const ycw = datepicker.yearCountWay;
  const newValLen = newVal?.length || 0;
  const prevValLen = prevVal?.length || 0;
  // 正常鍵入 增加文字
  if (newValLen > prevValLen) {
    // 但避免使用者在斜線補上後 又鍵入則不異動
    if (yearCountDiff.slash.offset[ycw].includes(prevValLen)) {
      if (yearCountDiff.slash.text == newVal.slice(prevValLen, newValLen)) {
        return prevVal;
      }
    }
    // 正常鍵入 補齊斜線
    if (yearCountDiff.slash.offset[ycw].includes(newValLen + 1)) {
      return newVal + yearCountDiff.slash.text;
    }
  }

  // 刪除文字 確保格式
  if (newValLen < prevValLen) {
    // 當遇到斜線時 多刪除一個文字
    if (
      prevVal[newValLen] == yearCountDiff.slash.text &&
      yearCountDiff.slash.offset[ycw].includes(prevValLen)
    ) {
      return newVal.slice(0, newValLen - 1);
    }
    // 刪除文字 補齊斜線
    if (yearCountDiff.slash.offset[ycw].includes(newValLen + 1)) {
      return newVal + yearCountDiff.slash.text;
    }
  }
  return newVal;
};

/**
 * 檢查傳入的字串是否符合某種模式（目前未定義），並回傳是否符合此模式。
 * @param {string} val - 要檢查的字串。
 * @returns {boolean} - 如果字串符合定義的模式則回傳true，否則回傳false。
 */
export const isRocEmptyPattern = (val) => {
  return /^\d*\/?\d*\/?\d*$/.test(val);
};
