<template>
  <q-input
    ref="qInputRef"
    v-model="modelValue"
    :class="[
      // 根據 isTsMode 動態決定根 class
      isTsMode ? 'cxl-input-ts' : 'cxl-input',
      {
        // 根據 isTsMode 動態切換 class
        'cxl-input-ts-error-msg': isTsMode && error,
        'cxl-input-ts-group-before': isTsMode && slots['before'],
        'cxl-input-ts-group-after': isTsMode && slots['after'],
        'cxl-input-ts-filled': isTsMode && !!modelValue,
        'cxl-input-error-msg': !isTsMode && error,
        'cxl-input-group-before': !isTsMode && slots['before'],
        'cxl-input-group-after': !isTsMode && slots['after'],
      },
    ]"
    :input-class="isTsMode ? 'cxl-input-ts-root' : 'cxl-input-root'"
    outlined
    dense
    :error="error"
    hide-bottom-space
    no-error-icon
    :mask="isComposing ? undefined : props.mask"
  >
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </q-input>
</template>

<script setup>
import {
  ref,
  onMounted,
  onUnmounted,
  reactive,
  watch,
  useAttrs,
  useSlots,
  computed,
  nextTick,
} from 'vue';

const modelValue = defineModel({ type: [String, Number, null] });

const props = defineProps({
  mask: String,
  error: {
    type: Boolean,
    default: false,
  },
});

const attrs = useAttrs();
const slots = useSlots();

// 判斷 class 是否包含 'cxl-input-ts' 來決定模式
const isTsMode = computed(() => attrs.class?.includes('cxl-input-ts'));

const isComposing = ref(false);

const properties = [
  'resetValidation',
  'validate',
  'focus',
  'blur',
  'select',
  'getNativeElement',
  'hasError',
  'nativeEl',
];

const qInputRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    // 確保 qInputRef.value 存在
    if (qInputRef.value) {
      exposedProperties[key] = qInputRef.value[key];
    }
  });
  bindIMESetting();
});

onUnmounted(() => {
  unBindIMESetting();
});

// 綁定IME設定
const bindIMESetting = () => {
  const inputEl = qInputRef.value?.$el?.querySelector('input');
  if (!inputEl) return;

  inputEl.removeEventListener('compositionstart', onCompositionStart);
  inputEl.removeEventListener('compositionend', onCompositionEnd);

  inputEl.addEventListener('compositionstart', onCompositionStart);
  inputEl.addEventListener('compositionend', onCompositionEnd);
};

// 解除綁定IME設定
const unBindIMESetting = () => {
  const inputEl = qInputRef.value?.$el?.querySelector('input');
  if (!inputEl) return;

  inputEl.removeEventListener('compositionstart', onCompositionStart);
  inputEl.removeEventListener('compositionend', onCompositionEnd);
};

// IME啟動 hook
const onCompositionStart = () => {
  isComposing.value = true;
};

// IME結束 hook
const onCompositionEnd = (event) => {
  isComposing.value = false;
  modelValue.value = event.target.value;
  // 除現有vue 也需要等quasar mask作用結束後才可設定，故須兩層nextTick
  nextTick(() => {
    nextTick(() => {
      const inputEl = qInputRef.value?.$el?.querySelector('input');
      if (inputEl) {
        const len = inputEl.value.length;
        inputEl.setSelectionRange(len, len);
      }
    });
  });
};

watch(
  () => [qInputRef.value?.hasError, qInputRef.value?.nativeEl],
  ([hasError, nativeEl]) => {
    exposedProperties.hasError = hasError;
    exposedProperties.nativeEl = nativeEl;
  },
  { deep: true }, // 監聽 ref 內部的變化
);

defineExpose(exposedProperties);
</script>
