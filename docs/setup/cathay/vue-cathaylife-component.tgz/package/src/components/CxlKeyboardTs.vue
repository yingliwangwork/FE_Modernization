<template>
  <q-dialog class="cxl-modal cxl-keyboard-ts">
    <q-card class="cxl-keyboard-radis-10">
      <q-bar
        v-if="!hideCloseButton"
        class="cxl-modal-header__height-24 absolute-top q-mx-sm q-my-sm q-px-none"
      >
        <span
          v-close-popup
          class="cxl-icon-close-ts cxl-font-40 cxl-text-gray-a7 q-mt-md q-ml-auto cursor-pointer"
        ></span>
      </q-bar>
      <q-card-section class="column">
        <div v-if="props.title" class="cxl-modal-title">{{ props.title }}</div>
        <CxlInput v-model="inputVal" readonly :type="password ? 'password' : 'number'" />
      </q-card-section>
      <div class="cxl-keyboard-number-container">
        <CxlButton
          v-for="item in numbers.slice(0, 9)"
          :key="item"
          :label="item.toString()"
          class="cxl-keyboard-number"
          @click="append(`${item}`)"
        />
        <CxlButton label="清除" class="cxl-keyboard-number cxl-keyboard-action" @click="clear" />
        <CxlButton
          :key="numbers[9]"
          :label="numbers[9].toString()"
          class="cxl-keyboard-number"
          @click="append(`${numbers[9]}`)"
        />
        <CxlButton
          prevIcon="cxl-icon-deletearrow-ts"
          class="cxl-keyboard-number cxl-keyboard-action"
          @click="backspace"
        />
      </div>
      <q-card-actions class="row justify-center">
        <CxlButton
          class="q-mt-sm cxl-font-24 col cxl-keyboard-confirm"
          label="完成"
          @click="confirm()"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { ref, watch, onMounted, onBeforeUpdate } from 'vue';
import CxlButton from './CxlButton.vue';
import CxlInput from './CxlInput.vue';

const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  password: {
    type: Boolean,
    default: false,
  },
  shuffle: {
    type: Boolean,
    default: false,
  },
  maxLength: {
    type: [String, Number],
    default: 100,
  },
  hideCloseButton: {
    type: Boolean,
    default: false,
  },
});

const numbers = ref([]);
// 按鈕位置更新
/**
 *
 */
const updateNumbers = () => {
  numbers.value = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
  if (props.shuffle) {
    numbers.value.sort(() => 0.5 - Math.random());
  }
};

onBeforeUpdate(() => {
  if (props.shuffle) {
    numbers.value.sort(() => 0.5 - Math.random());
  }
});

onMounted(() => {
  updateNumbers();
});

watch(
  () => props.shuffle,
  () => {
    updateNumbers();
  },
);

// 綁定 input 輸入的值
const inputVal = ref('');

// 增加數字
/**
 *
 * @param number
 */
const append = (number) => {
  if (props.maxLength > 0 && inputVal.value.length >= props.maxLength) {
    return;
  }
  inputVal.value = `${inputVal.value}${number}`;
};

// 清除數字
/**
 *
 */
const clear = () => {
  inputVal.value = '';
};

// 刪除數字
/**
 *
 */
const backspace = () => {
  inputVal.value = inputVal.value.slice(0, -1);
};

const emit = defineEmits(['confirm']);
/**
 *
 */
const confirm = () => {
  emit('confirm', inputVal.value);
};
</script>
