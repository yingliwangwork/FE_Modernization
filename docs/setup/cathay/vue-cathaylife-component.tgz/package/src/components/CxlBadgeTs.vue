<template>
  <div
    class="cxl-badge-ts cxl-text-white-ff"
    :class="[
      props.theme,
      `cxl-badge-ts-${props.size}`,
      isFirstOrLast && `cxl-badge-ts-${props.size}-shape`,
    ]"
  >
    {{ label }}
  </div>
</template>
<script setup>
const props = defineProps({
  label: {
    type: String,
    default: '',
  },
  theme: {
    type: String,
    default: 'cxl-bg-gray-a7',
  },
  size: {
    type: String,
    default: 'lg',
    validator: (value) => ['lg', 'sm'].includes(value),
  },
  isFirstOrLast: {
    type: Boolean,
    default: false,
  },
});
</script>
