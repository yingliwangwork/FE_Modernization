<template>
  <div :class="tagClasses">
    <span :class="[iconClass, fontSize]"></span>
    <span>{{ text }}</span>
  </div>
</template>
<script setup>
import { computed } from 'vue';

const props = defineProps({
  type: {
    type: String,
    default: 'success',
    validator: (value) => ['success', 'warning', 'error'].includes(value),
  },
  theme: {
    type: String,
    default: 'none',
    validator: (value) => ['none', 'light', 'dark'].includes(value),
  },
  text: {
    type: String,
    required: true,
  },
});

const tagClasses = computed(() => {
  return ['cxl-tag', `cxl-tag--${props.type}`, `cxl-tag--${props.theme}`];
});

const fontSize = computed(() => (props.theme === 'dark' ? 'cxl-font-18' : 'cxl-font-24'));

const iconClass = computed(() => {
  const iconMap = {
    success: {
      none: 'cxl-icon-check-ts',
      light: 'cxl-icon-finish-ts',
      dark: 'cxl-icon-check-ts',
    },
    warning: {
      none: 'cxl-icon-exclamation-ts',
      light: 'cxl-icon-warning-ts',
      dark: 'cxl-icon-exclamation-ts',
    },
    error: {
      none: 'cxl-icon-close-ts',
      light: 'cxl-icon-error-ts',
      dark: 'cxl-icon-close-ts',
    },
  };
  return iconMap[props.type]?.[props.theme];
});
</script>
