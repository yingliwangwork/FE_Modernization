<template>
  <div
    class="cxl-paginator"
    :class="{
      'cxl-border-gray-overlay': withBorder,
      'cxl-paginator-left': props.pageAlign === 'left',
    }"
  >
    <div class="cxl-paginator-spacer"></div>

    <div class="cxl-paginator-page">
      <button type="button" class="q-mr-sm" :class="{ disabled: page <= 1 }" @click="prev">
        <span class="cxl-paginator-icon cxl-paginator-previous-icon"></span>
      </button>
      <input type="text" :value="page" @input="changeCurrentPage" />
      <span class="cxl-paginator-total">/ {{ pagesNumber }}</span>
      <button
        type="button"
        class="q-ml-sm"
        :class="{ disabled: page >= pagesNumber }"
        @click="next"
      >
        <span class="cxl-paginator-icon cxl-paginator-next-icon"></span>
      </button>
    </div>
    <div class="cxl-paginator-info">
      <CxlDropdown
        v-model="dropdownValue"
        :options="props.dropdownOptions"
        class="q-mr-sm"
        @update:modelValue="updDropVal"
      />
      <span class="ng-star-inserted">筆 / 頁</span>
      <span class="cxl-paginator-info-totalitem ng-star-inserted">
        ，共 {{ totalItemLength }} 筆
      </span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onBeforeMount } from 'vue';
import CxlDropdown from './CxlDropdown.vue';

const props = defineProps({
  // 新版props參數，添加結構須與quasar table initPagination相符
  initPagination: {
    type: Object,
    default: () => {
      return {
        page: 1, // 當前頁數 currentPage
        rowsPerPage: 10, // 一頁顯示幾筆 perPage
      };
    },
  },
  // 是否啟用邊框樣式，預設為啟用。
  withBorder: {
    type: Boolean,
    default: true,
  },
  // 當前頁數, 已棄用 舊版參數
  currentPage: {
    type: Number,
    default: -1,
  },
  // 一頁顯示幾筆, 已棄用 舊版參數
  perPage: {
    type: Number,
    default: -1,
  },
  // 資料總筆數
  totalItemLength: {
    type: [Number, String],
    default: 0,
  },
  // 一頁幾筆顯示在右邊或左邊
  pageAlign: {
    type: String,
    default: 'right',
  },
  dropdownOptions: {
    type: Array,
    default: () => [
      { label: '5', value: 5 },
      { label: '10', value: 10 },
      { label: '30', value: 30 },
      { label: '50', value: 50 },
      { label: '100', value: 100 },
      { label: 'All', value: 'All' },
    ],
  },
});

// 新版參數，添加結構須與quasar table initPagination相符
const page = ref(1);
const rowsPerPage = ref(1);

const isNewParamMode = ref(false);
onBeforeMount(() => {
  // 檢查是新版參數還是舊版參數
  if (props.perPage < 0 || props.currentPage < 0) {
    isNewParamMode.value = true;
    page.value = props.initPagination.page;
    rowsPerPage.value = props.initPagination.rowsPerPage;
    dropdownValue.value = props.initPagination.rowsPerPage;
  } else {
    page.value = props.currentPage;
    rowsPerPage.value = props.perPage;
    dropdownValue.value = props.perPage;
  }
});

// 監聽props參數 並更新到pagination
watch(
  () => props.initPagination,
  (newInitPagination) => {
    // 判斷是否需要將現在的頁碼恢復成 1 (父元件的值不等於現在的值, 且當前頁面不為 1)
    const resetCurrPage =
      newInitPagination.rowsPerPage != rowsPerPage.value && newInitPagination.page != 1;

    page.value = resetCurrPage ? 1 : newInitPagination.page;
    rowsPerPage.value = newInitPagination.rowsPerPage;
    dropdownValue.value = newInitPagination.rowsPerPage;

    // 必須將當前頁面(page = 1) 更新回父元件, 讓雙方一致
    if (resetCurrPage) {
      updateData(page.value, rowsPerPage.value);
    }
  },
  { deep: true },
);

watch(
  () => props.currentPage,
  (newCurrentPage) => {
    if (isNewParamMode.value) {
      return;
    }
    page.value = newCurrentPage;
  },
);

watch(
  () => props.perPage,
  (newPerPage) => {
    if (isNewParamMode.value) {
      return;
    }
    rowsPerPage.value = newPerPage;
  },
);

/**
 * 將當前頁碼減少一，如果當前頁碼小於等於1，則不進行任何操作。
 * @returns {void}
 */
const prev = () => {
  if (page.value <= 1) {
    return;
  }
  updatePropsData(page.value - 1, rowsPerPage.value);
};

// 總頁數
const pagesNumber = computed(() => Math.ceil(props.totalItemLength / rowsPerPage.value));

/**
 * 將當前頁碼增加一，如果當前頁碼大於等於總頁數，則不進行任何操作。
 * @returns {void}
 */
const next = () => {
  if (page.value >= pagesNumber.value) {
    return;
  }
  updatePropsData(page.value + 1, rowsPerPage.value);
};

/**
 * 根據輸入值更改當前頁面。
 * @param {object} event - 事件對象。
 * @returns {void}
 */
const changeCurrentPage = (event) => {
  // 僅限輸入數字
  const regex = /^[0-9\s]*$/;
  if (!regex.test(event.target.value)) {
    return;
  }

  if (!event.target.value || event.target.value > pagesNumber.value) {
    return;
  }
  updatePropsData(parseInt(event.target.value, 10), rowsPerPage.value);
};

// 切換每頁顯示筆數時，當前頁數變回第一頁
const dropdownValue = ref(props.initPagination.rowsPerPage);

/**
 * 根據輸入值更新RowsPerPage的值，或者如果輸入值為"All"，則更新為總數。
 * @param {object} val - 包含值屬性的物件。
 * @returns {void}
 */
const updDropVal = (val) => {
  if (val.value === 'All') {
    updatePropsData(page.value, props.totalItemLength);
    return;
  }
  updatePropsData(page.value, val.value);
};

/**
 * 更新與分頁相關的屬性。
 * @param {number} updPage - 當前頁碼。
 * @param {number} updRowsPerPage - 每頁的行數。
 * @returns {void}
 */
const updatePropsData = (updPage, updRowsPerPage) => {
  // 檢查當前行數是否與更新後的值不同
  const _updPage = rowsPerPage.value !== updRowsPerPage ? 1 : updPage;

  updateData(_updPage, updRowsPerPage);
};

// 設定emit項目
const emit = defineEmits(['update:currentPage', 'update:perPage', 'update:initPagination']);

/**
 * 執行 emit, 通知父元件值有被修改
 * @param {number} _updPage - 當前頁碼
 * @param {number} updRowsPerPage - 每頁的行數
 */
const updateData = (_updPage, updRowsPerPage) => {
  // 針對新版參數進行emit更新
  emit('update:initPagination', {
    page: _updPage,
    rowsPerPage: updRowsPerPage,
  });

  // 針對舊版參數進行emit更新
  emit('update:currentPage', _updPage);
  emit('update:perPage', updRowsPerPage);
};
</script>
