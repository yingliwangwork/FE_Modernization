<template>
  <div class="cxl-tabs-ts">
    <q-tabs
      v-model="currentTab"
      align="left"
      content-class="cxl-tabs-ts-area"
      active-class="cxl-tabs-ts-is-selected"
      indicator-color="transparent"
      :breakpoint="0"
      no-caps
    >
      <template v-for="tab in props.tabs" :key="tab">
        <q-tab
          v-if="!tab.hide"
          class="cxl-tab-ts"
          content-class="cxl-tab-ts-content"
          :name="tab.name"
          :label="tab.label"
          :ripple="false"
          :disable="tab.disable"
          @click="buttonClick(tab.name)"
        >
          <q-badge v-if="tab.number || tab.number === 0" rounded class="cxl-tab-ts-badge">
            <span>
              {{ tab.number }}
            </span>
          </q-badge>
        </q-tab>
      </template>
    </q-tabs>
    <div v-if="hasTabsAppendSlot" class="cxl-tabs-ts-append-slot">
      <slot name="tabs-append"></slot>
    </div>
  </div>
  <q-tab-panels v-model="currentTab" class="cxl-tab-ts-panels" keep-alive>
    <slot></slot>
  </q-tab-panels>
</template>
<script setup>
import { computed, useSlots } from 'vue';

const currentTab = defineModel('currentTab', { type: String, default: '' });
const slots = useSlots();

const props = defineProps({
  tabs: {
    type: Array,
    default: () => [],
  },
});

// 檢測是否有 'tabs-append' slot
const hasTabsAppendSlot = computed(() => {
  return !!slots['tabs-append'];
});

const emit = defineEmits(['buttonClick']);
// 用來實作 add tabs 用的 method
const buttonClick = (val) => {
  emit('buttonClick', val);
};
</script>
