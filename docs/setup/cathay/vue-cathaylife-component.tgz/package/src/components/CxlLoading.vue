<template>
  <div v-show="props.display" class="cxl-loading">
    <div class="cxl-loading__frame">
      <div class="cxl-loading__circle"></div>
      <p class="cxl-loading__label">{{ props.label }}</p>
    </div>
    <div class="cxl-loading__bg"></div>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted, watch } from 'vue';

const props = defineProps({
  display: { type: Boolean, default: false },
  label: {
    type: String,
    default: 'Loading',
  },
  unLockScrollbar: {
    type: Boolean,
    default: false,
  },
});

const html = document.querySelector('html');
const body = document.body;
let scrollT;
let scrollL;

const hideScroll = () => {
  // 打開遮罩時，遮蔽背景 scrollbar + 產生假的 scrollbar
  scrollT = html.scrollTop;
  scrollL = html.scrollLeft;
  body.classList.add('q-body--force-scrollbar-y', 'q-body--prevent-scroll');
  body.style.top = `-${scrollT}px`;
  body.style.left = `-${scrollL}px`;
};

const showScroll = () => {
  // 關閉遮罩時，顯示背景 scrollbar + 解除假的 scrollbar
  body.classList.remove('q-body--force-scrollbar-y', 'q-body--prevent-scroll');
  body.style = null;
  html.scrollTop = scrollT;
  html.scrollLeft = scrollL;
};

onMounted(() => {
  if (props.display && !props.unLockScrollbar) {
    hideScroll();
  }
});

watch(
  () => props.display,
  (val) => {
    if (props.unLockScrollbar) {
      return;
    }
    if (val) {
      hideScroll();
    } else {
      showScroll();
    }
  },
);

watch(
  () => props.unLockScrollbar,
  (val) => {
    if (val) {
      showScroll();
    }
  },
);

onUnmounted(() => {
  showScroll();
});
</script>
