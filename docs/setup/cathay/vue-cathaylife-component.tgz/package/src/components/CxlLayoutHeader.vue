<template>
  <q-header class="cxl-navbar">
    <q-toolbar>
      <span
        v-if="props.showLeftMenu"
        class="cub-icon-menu_40_m cxl-font-40 pt-4"
        @click="updateDrawerStatus"
      ></span>
      <q-toolbar-title>
        <slot name="logoLink">
          <router-link :to="'/'" :class="props.showLeftMenu ? 'q-mr-lg' : ''">
            <img src="/src/assets/images/cathaylifeLogo_W.svg" alt="Logo" />
          </router-link>
        </slot>
        <span class="cxl-text-warning-light q-ml-md">
          <span v-if="VITE_NODE_ENV === `development`">[本機開發]</span>
          <span v-else-if="VITE_NODE_ENV === `testing`">[測試環境]</span>
          <span v-else-if="VITE_NODE_ENV === `staging`">[平測環境]</span>
        </span>
        <slot name="headerTitle">
          <span>共用模板 Title > 請記得修改</span>
        </slot>
      </q-toolbar-title>
      <div class="cxl-navbar-info" :class="props.userIp ? 'q-gutter-x-md' : ''">
        <span v-if="props.userIp">{{ props.userIp }}</span>
        <slot name="backIndex">
          <CxlButton
            label="回首頁"
            theme="navbar-outline"
            prevIcon="cub-icon-chevronleft_24"
            :class="authStore?.EmpName ? '' : 'q-mr-lg'"
            @click="goHomePage('/')"
          />
        </slot>
      </div>
      <div v-if="authStore?.EmpName" class="cxl-navbar-divider"></div>
      <div v-if="authStore?.EmpName" class="cursor-pointer non-selectable cxl-navbar-user">
        <div class="row ui-dropdown-label-container">
          <span class="ui-dropdown-subtitle">
            {{ authStore?.DivShortName }}
          </span>
          <span class="ui-dropdown-title">
            {{ authStore?.EmpName }}
          </span>
          <span class="cxl-icon-dropdown-white-ff"></span>
        </div>
        <!-- 右上角的下拉選單 -->
        <q-menu anchor="bottom right" self="top right" square class="cxl-header-menu">
          <q-list class="cxl-list" dense>
            <slot name="topMenuList"></slot>
            <template v-if="authStore?.EmpName">
              <q-item clickable class="cxl-list-logout" @click="logoutHandler">
                <q-item-section>
                  <div class="row items-center">
                    <span class="cub-icon-logout_40_m cxl-font-28 cxl-text-black-4a"></span>
                    <slot name="logoutName">登出</slot>
                  </div>
                </q-item-section>
              </q-item>
            </template>
          </q-list>
        </q-menu>
      </div>
    </q-toolbar>
  </q-header>
</template>
<script setup>
import { ref } from 'vue';
import CxlButton from './CxlButton.vue';

const VITE_NODE_ENV = ref(import.meta.env.VITE_NODE_ENV);

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  userIp: {
    type: String,
    default: '',
  },
  authStore: {
    type: Object,
    default: () => {},
  },
  showLeftMenu: {
    type: Boolean,
    default: true,
  },
  router: {
    type: Object,
    default: () => {
      console.warn('⚠ 匯入 vue-router 異常, 請在 CxlLayoutHeader 傳入 :router"useRouter()"');
      return {
        push: () => {
          console.warn('⚠ 匯入 vue-router 異常, 請在 CxlLayoutHeader 傳入 :router"useRouter()"');
        },
      };
    },
  },
  route: {
    type: Object,
    default: () => {
      console.warn('⚠ 匯入 vue-router 異常, 請在 CxlLayoutHeader 傳入 :route="useRoute()"');
      return { path: '', name: '' };
    },
  },
});

const myDrawer = defineModel({
  type: Boolean,
  default: true,
});

const emit = defineEmits(['routerReload', 'logoutHandler']);
/**
 * 更新選單狀態
 */
const updateDrawerStatus = () => {
  myDrawer.value = !myDrawer.value;
};

/**
 * 回首頁
 * @param toUrl
 */
const goHomePage = (toUrl) => {
  if (toUrl == props.route.path) {
    emit('routerReload');
  } else if (props.route.name == 'error') {
    emit('routerReload');
  } else {
    props.router.push(toUrl); // eslint-disable-line vue/no-mutating-props
  }
};

/**
 *
 */
const logoutHandler = () => {
  emit('logoutHandler');
};
</script>
