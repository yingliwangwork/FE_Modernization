<template>
  <div>
    <div class="row relative" :class="tabsClass">
      <q-tabs
        v-model="currentTab"
        align="justify"
        class="col"
        active-class="active"
        indicator-color="transparent"
        outside-arrows
      >
        <template v-for="tab in tabs" :key="tab">
          <q-tab
            v-if="!tab.hide"
            :class="tabsBorderStyle"
            :name="tab.name"
            :label="tab.label"
            :ripple="false"
            :disable="tab.disable"
            @click="buttonClick(tab.name)"
          >
            <q-badge v-if="tab.number || tab.number === 0" rounded>
              {{ tab.number }}
            </q-badge>
          </q-tab>
        </template>
      </q-tabs>
      <div class="tabs-append-slot">
        <slot name="tabs-append"></slot>
      </div>
    </div>
    <q-tab-panels v-model="currentTab" class="cxl-tab-panels" keep-alive>
      <slot></slot>
    </q-tab-panels>
  </div>
</template>
<script setup>
import { computed } from 'vue';

const currentTab = defineModel('currentTab', { type: String, default: '' });

const props = defineProps({
  tabs: {
    type: Array,
    default: () => [],
  },
  isYellowStyle: {
    type: Boolean,
    default: false,
  },
});

// 透過 isYellowStyle 決定顯示的 tab 樣式
const tabsClass = computed(() => 'cxl-tabs ' + (props.isYellowStyle ? 'cxl-tabs-yellow' : ''));
const tabsBorderStyle = computed(() => (props.isYellowStyle ? 'q-tab-yellow' : ''));

const emit = defineEmits(['buttonClick']);
// 用來實作 add tabs 用的 method
const buttonClick = (val) => {
  emit('buttonClick', val);
};
</script>
