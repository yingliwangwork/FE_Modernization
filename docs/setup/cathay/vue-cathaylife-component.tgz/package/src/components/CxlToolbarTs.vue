<template>
  <div class="cxl-toolbar-ts row">
    <section class="cxl-toolbar-ts-btn-area">
      <slot name="btn-area">
        <CxlButton
          v-for="(btn, index) in buttonItems"
          :key="`${index}${btn.label}`"
          theme="warning"
          class="cxl-btn-ts"
          :label="btn.label.length > 6 ? btn.label.slice(0, 6) + '...' : btn.label"
          prevIcon="cxl-icon-plus-ts"
          @click="handleItemClick(btn.action)"
        />
      </slot>
    </section>
    <section class="cxl-toolbar-ts-icon-area">
      <CxlButton
        v-if="props.showListTypeIcon"
        theme="default"
        :prevIcon="listType === 'list' ? 'cxl-icon-card-ts' : 'cxl-icon-column-ts'"
        @click.stop="listTypeClick"
      />
      <CxlButton
        v-if="props.showSearchIcon"
        theme="default"
        prevIcon="cxl-icon-search-ts"
        @click.stop="searchClick"
      />
      <CxlButton
        v-if="props.showDeleteIcon"
        theme="default"
        prevIcon="cxl-icon-delete-ts"
        @click.stop="deleteClick"
      />
      <CxlButton v-if="props.showMoreIcon" theme="default" prevIcon="cxl-icon-more-ts">
        <CxlSidebarTs
          v-model="showSidebarTs"
          :items="menuItems"
          :keep-menu-open="keepMenuOpen"
          anchor="bottom right"
          self="top right"
          :offset="[15, 8]"
        />
      </CxlButton>
    </section>
  </div>
</template>
<script setup>
import CxlButton from './CxlButton.vue';
import CxlSidebarTs from './CxlSidebarTs.vue';
import { ref } from 'vue';

const props = defineProps({
  showListTypeIcon: {
    type: Boolean,
    default: false,
  },
  showSearchIcon: {
    type: Boolean,
    default: false,
  },
  showDeleteIcon: {
    type: Boolean,
    default: false,
  },
  showMoreIcon: {
    type: Boolean,
    default: false,
  },
  buttonItems: {
    type: Array,
    default: () => [],
  },
  menuItems: {
    type: Array,
    default: () => [],
  },
  keepMenuOpen: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['listTypeChange', 'searchClick', 'deleteClick']);

// icon listType
const listType = ref('list');

/**
 *   列表樣式按鈕 開關icon
 */
const listTypeClick = () => {
  listType.value = listType.value === 'list' ? 'card' : 'list';
  emit('listTypeChange', listType.value);
};

/**
 *   搜尋按鈕 開關icon
 */
const searchClick = () => {
  emit('searchClick');
};

/**
 *  刪除按鈕 開關icon
 */
const deleteClick = () => {
  emit('deleteClick');
};

// 開啟 SidebarTs (更多清單)
const showSidebarTs = ref(false);

/**
 * 執行外部傳來的方法
 * @param {Function} action click 方法內容
 */
const handleItemClick = (action) => {
  if (typeof action === 'function') {
    action();
  }
};
</script>
