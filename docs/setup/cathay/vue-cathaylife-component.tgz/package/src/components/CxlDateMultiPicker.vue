<!--
　參考來源：https://linmasahiro.github.io/vue3-datepicker-lite/dist/
-->
<template>
  <div class="cxl-calendar">
    <div class="row" style="position: relative">
      <div v-if="error || innerError" role="alert" class="cxl-text-danger-bright">
        {{ innerErrorMessage || errorMessage }}
      </div>
      <button
        v-if="useIconBtn"
        type="button"
        class="cxl-date-multi__btn"
        style="cursor: pointer"
        @click="onFocusEvent"
      >
        <span class="cub-icon-date_24 cxl-font-24" style="vertical-align: -0.2em"></span>
      </button>
      <button v-else type="button" class="cxl-btn cxl-btn-primary-outline" @click="onFocusEvent">
        <span class="cub-icon-date_24 cxl-font-24" style="vertical-align: -0.2em"></span>
        選擇日期
      </button>
    </div>
    <div v-if="datepicker.show" class="cxl-calendar-picker__mask" @click="close"></div>
    <div
      v-if="datepicker.show"
      class="cxl-calendar-picker__frame"
      :class="{ 'cxl-calendar-picker__frame_up': needMoveToUp }"
    >
      <div class="cxl-calendar-picker__warp">
        <div class="cxl-calendar-picker__box">
          <div class="cxl-calendar-picker__header">
            <div class="cxl-calendar-picker__year">
              <select v-model="datepicker.year">
                <option v-for="year in datepicker.yearList" :key="year" :value="year">
                  {{ datepicker.yearCountWay === 'ROC' ? '民國' + (year - 1911) : '西元' + year }}年
                </option>
              </select>
            </div>
            <div class="cxl-calendar-picker__month">
              <select v-model="datepicker.month">
                <option v-for="mon in datepicker.monthList" :key="mon" :value="mon">
                  {{
                    `${modifiedLocale.months[mon - 1] + (/[a-z]/.test(modifiedLocale.months[mon - 1]) ? '' : '月')}`
                  }}
                </option>
              </select>
            </div>

            <div class="cxl-calendar-picker__nav--prev" @click="prevMonth">
              <span class="cub-icon-chevronleft_24 cxl-font-14" style="margin-right: -10px"></span>
              <span class="cub-icon-chevronleft_24 cxl-font-14"></span>
            </div>
            <div class="cxl-calendar-picker__nav--next" @click="nextMonth">
              <span class="cub-icon-chevronright_24 cxl-font-14"></span>
              <span class="cub-icon-chevronright_24 cxl-font-14" style="margin-left: -10px"></span>
            </div>
          </div>
          <table class="cxl-calendar-picker__table">
            <thead>
              <tr>
                <th
                  v-for="weekday in modifiedLocale.weekday"
                  :key="weekday"
                  class="cxl-calendar-picker__weekday"
                >
                  {{ weekday }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(dateRow, i) in datepicker.dayList" :key="`row${dateRow[i].dateString}`">
                <td v-for="date in dateRow" :key="date.dateString" role="presentation">
                  <div
                    class="cxl-calendar-picker__day"
                    :class="{
                      'cxl-calendar-picker__day--outfocus': date.month != datepicker.month,
                      'cxl-calendar-picker__day--infocus': date.month == datepicker.month,
                      'cxl-calendar-picker__day--today': date.isToday,
                      'cxl-calendar-picker__day--disabled': date.isDisabled,
                      'cxl-calendar-picker__day--selected cxl-calendar-picker__day--highlighted':
                        tmpSelectedValues.includes(date.dateString),
                    }"
                    @click="date.isDisabled ? false : select(date.dateString)"
                  >
                    {{ date.day }}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div v-if="showBottomButton" class="cxl-calendar-picker__footer">
            <button class="cxl-calendar-picker__button--today" type="button" @click="selectToday">
              {{ modifiedLocale.todayBtn }}
            </button>
            <button class="cxl-calendar-picker__button--clear" type="button" @click="clear">
              {{ modifiedLocale.clearBtn }}
            </button>
          </div>

          <div class="cxl-calendar-picker__footer">
            <button
              type="button"
              class="cxl-btn cxl-btn-primary-outline q-mx-xs"
              flat
              @click="cancelDates"
            >
              取消
            </button>
            <button
              type="button"
              class="cxl-btn cxl-btn-primary q-mx-xs"
              flat
              @click="confirmDates"
            >
              確認
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, watch } from 'vue';
import {
  regex,
  defaultLocale,
  getDatePickerDefault,
  parseDateString,
  parseDateObject,
  goNextMonth,
  goPrevMonth,
  getDateList,
} from './dateUtils/datePickerUtils.js';

const props = defineProps({
  // 參數：placeholder
  placeholderAttr: {
    type: String,
    default: '',
  },
  // 參數：autocomplete
  autocompleteAttr: {
    type: String,
    default: 'off',
  },
  // 日期選擇器顯示資料用(變數datepicker)
  yearCountWay: {
    type: String,
    default: 'AD',
  },
  // 調整小日曆年份下拉選單一次出現範圍
  yearsRange: {
    type: Number,
    default: 113,
  },
  // 在限定年份下 from date 數值
  from: {
    type: String,
    default: '',
  },
  // 在限定年份下 end date 數值
  to: {
    type: String,
    default: '',
  },
  // 在地化設定，預設值在變數modifiedLocale中的defaultLocale設定。
  locale: {
    type: Object,
    default: () => {},
  },
  // 小日曆上是否出現今日、清除、關閉之按鈕
  showBottomButton: {
    type: Boolean,
    default: true,
  },
  error: {
    type: Boolean,
    default: false,
  },
  errorMessage: {
    type: String,
    default: '',
  },
  maximumDays: {
    type: Number,
    default: 0,
  },
  excludeDays: {
    type: Object,
    default: () => {},
  },
  // 小日曆按鈕是否用 icon 顯示（false 只顯示文字）
  useIconBtn: {
    type: Boolean,
    default: false,
  },
});

const emits = defineEmits(['updateValueAttr', 'valueVaildate']);

const modifiedLocale = {
  ...defaultLocale,
  ...props.locale,
};

/**
 * 檢查設定的上下限值格式(YYYY/MM/DD)
 */
const checkDateUpperAndLowerLimits = () => {
  try {
    // from、to傳入格式應為YYYY/MM/DD，如格式錯誤不另外處理，
    const propsFrom = props.from;
    if (propsFrom && !regex.AD.test(propsFrom)) {
      throw new Error('日期下限(props.from)格式應為YYYY/MM/DD');
    }
    const propsTo = props.to;
    if (propsTo && !regex.AD.test(propsTo)) {
      throw new Error('日期上限(props.to)格式應為YYYY/MM/DD');
    }
  } catch (err) {
    throw ('catch:', err);
  }
};
checkDateUpperAndLowerLimits();

// 日期選擇器用資料物件
const datepicker = reactive({
  ...getDatePickerDefault(props),
  ...{
    yearList: computed(() => getDateList(datepicker, 'year')),
    monthList: computed(() => getDateList(datepicker, 'month')),
    dayList: computed(() => getDateList(datepicker, 'day')),
  },
});

/**
 * 上一個月按鈕
 */
const prevMonth = () => {
  const prevObj = goPrevMonth(datepicker);
  if (prevObj.goPrev) {
    datepicker.year = prevObj.nextYear;
    datepicker.month = prevObj.nextMonth;
  }
};

/**
 * 下一個月按鈕
 */
const nextMonth = () => {
  const nextObj = goNextMonth(datepicker);
  if (nextObj.goNext) {
    datepicker.year = nextObj.nextYear;
    datepicker.month = nextObj.nextMonth;
  }
};

/**
 * 日期資料檢核
 * @param {Array} valueList 輸入的日期資料清單
 * @returns {object} 檢核結果(錯誤訊息)
 */
const validDate = (valueList) => {
  innerError.value = false;
  innerErrorMessage.value = '';
  const errItems = [];
  if (valueList.length > props.maximumDays) {
    errItems.push({
      errorItem: 'length',
      errorMsg: `最多僅可以被選取${props.maximumDays}天`,
    });
    return errItems;
  }
  valueList.forEach((checkDateItem) => {
    const target = parseDateObject(checkDateItem);
    // 當輸入內容 與日期格式不符時 日期格式有誤
    if (target === null) {
      errItems.push({
        errorItem: checkDateItem,
        errorMsg: '日期格式有誤',
      });
      return;
    }
    //日期低於有效範圍
    if (datepicker.from) {
      const lower = parseDateObject(datepicker.from);
      if (lower > target) {
        errItems.push({
          errorItem: checkDateItem,
          errorMsg: '日期低於有效範圍',
        });
        return;
      }
    }

    // 日期高於有效範圍
    if (datepicker.to) {
      const upper = parseDateObject(datepicker.to);
      if (upper < target) {
        errItems.push({
          errorItem: checkDateItem,
          errorMsg: '日期高於有效範圍',
        });
        return;
      }
    }

    // 去除特定星期
    if (datepicker.excludeDays.weekday.includes(target.getDay())) {
      errItems.push({
        errorItem: checkDateItem,
        errorMsg: '日期不可被特定星期選取',
      });
      return;
    }

    // 去除特定日期
    if (
      datepicker.excludeDays.days.length > 0 &&
      parseDateString(target, 'AD').includes(datepicker.excludeDays.days)
    ) {
      errItems.push({
        errorItem: checkDateItem,
        errorMsg: '日期不可被特定日期選取',
      });
    }
  });
  return errItems;
};

const innerError = ref(false);
const innerErrorMessage = ref('');

const selectedValues = defineModel('valueAttr', {
  type: Array,
  default: [],
});

/**
 * 預設值處理(props.valueAttr)
 * @param {Array} value 預設值清單
 */
const doSetSelectedValues = (value) => {
  // 空值 歸零
  if (value.length === 0) {
    if (selectedValues.value.length > 0) {
      selectedValues.value = [];
    }
    return;
  }
  const tmpSelected = value.map((dateItem) => {
    // 格式不對進行轉換
    if (!regex[datepicker.yearCountWay].test(dateItem)) {
      // 西元/民國年轉譯
      return parseDateString(parseDateObject(dateItem), datepicker.yearCountWay);
    }
    return dateItem;
  });
  if (selectedValues.value.every((item) => tmpSelected.includes(item))) {
    return;
  }
  selectedValues.value = tmpSelected;
};

//預設值處理
doSetSelectedValues(props.valueAttr);

/**
 * 檢查初始值
 */
const checkPropDefaultSelected = () => {
  const errItem = validDate(selectedValues.value);
  if (errItem.length <= 0) {
    emits('valueVaildate', '');
    return;
  }
  innerError.value = true;
  // 刪除錯誤預設值
  errItem.forEach((errorDateItem) => {
    if (errorDateItem.errorItem === 'length') {
      innerErrorMessage.value = errorDateItem.errorMsg;
      return;
    }
    if (innerErrorMessage.value.indexOf(errorDateItem.errorMsg) === -1) {
      innerErrorMessage.value += `${errorDateItem.errorMsg}; `;
    }
  });
  emits('valueVaildate', innerErrorMessage.value);
};
checkPropDefaultSelected();

const tmpSelectedValues = ref([]);

/**
 * 處理本次暫時點選資料
 * @param {string} value 修改值
 */
const select = (value) => {
  // 沒有值不做事
  if (!value) {
    return;
  }
  // // 已存在的資料則視為取消
  if (tmpSelectedValues.value.includes(value)) {
    const removeIndex = tmpSelectedValues.value.indexOf(value);
    tmpSelectedValues.value.splice(removeIndex, 1);
  } else {
    tmpSelectedValues.value.push(value);
  }
};

/**
 * 點擊今天將內容改為今天日期
 */
const selectToday = () => {
  const today = parseDateObject(datepicker.today);
  if (datepicker.from && regex.AD.test(datepicker.from)) {
    if (today < parseDateObject(datepicker.from)) {
      innerError.value = true;
      innerErrorMessage.value = '日期低於有效範圍';
      emits('valueVaildate', innerErrorMessage.value);
      return;
    }
  }
  if (datepicker.to && regex.AD.test(datepicker.to)) {
    if (today > parseDateObject(datepicker.to)) {
      innerError.value = true;
      innerErrorMessage.value = '日期高於有效範圍';
      emits('valueVaildate', innerErrorMessage.value);
      return;
    }
  }

  datepicker.year = today.getFullYear();
  datepicker.month = today.getMonth() + 1;
  select(parseDateString(today, datepicker.yearCountWay, false));
};

/**
 * 監聽: selectedValue
 */
watch(
  () => selectedValues.value,
  (value) => {
    const errItem = validDate(value);
    // 檢核沒錯誤，且年份類型均正確時發出更新事件
    if (
      errItem.length <= 0 &&
      !value.find((dateItem) => !regex[datepicker.yearCountWay].test(dateItem))
    ) {
      emits('updateValueAttr', value);
      emits('valueVaildate', '');
      return;
    }
    innerError.value = true;
    // 刪除錯誤預設值
    errItem.forEach((errorDateItem) => {
      if (errorDateItem.errorItem === 'length') {
        innerErrorMessage.value = errorDateItem.errorMsg;
        return;
      }
      if (innerErrorMessage.value.indexOf(errorDateItem.errorMsg) === -1) {
        innerErrorMessage.value += `${errorDateItem.errorMsg}`;
      }
    });
    emits('valueVaildate', innerErrorMessage.value);
  },
  { deep: true },
);

/**
 * 監聽datepicker.show
 */
watch(
  () => datepicker.show,
  (state) => {
    if (state) {
      if (tmpSelectedValues.value.length > 0) {
        const lastSelectItem = parseDateObject(
          tmpSelectedValues.value[tmpSelectedValues.value.length - 1],
        );
        if (lastSelectItem) {
          datepicker.year = lastSelectItem.getFullYear();
          datepicker.month = lastSelectItem.getMonth() + 1;
          return;
        }
      }
      const today = parseDateObject(datepicker.today);
      const upper = parseDateObject(datepicker.to);
      // 用上限日期
      if (today > upper) {
        datepicker.year = upper.getFullYear();
        datepicker.month = upper.getMonth() + 1;
        return;
      }
      // 用今天日期
      datepicker.year = today.getFullYear();
      datepicker.month = today.getMonth() + 1;
    }
  },
);

/**
 * Watch valueAttr's state
 */
watch(
  () => props.valueAttr,
  (value) => {
    doSetSelectedValues(value);
  },
);

/**
 * 本次選擇資料及已選擇資料均清空
 */
const clear = () => {
  close();
};

/**
 * 關閉小日曆並清除暫存資料
 */
const close = () => {
  tmpSelectedValues.value = [];
  datepicker.show = false;
};

/**
 * 取消選取日期
 */
const cancelDates = () => {
  close();
};

/**
 * Modified datepicker position
 */
const needMoveToUp = ref(false);

/**
 * onFocusEvent
 * 開啟小月曆
 * @param {object} event 點擊事件資料物件
 */
const onFocusEvent = (event) => {
  const potisionY = event.target.getBoundingClientRect().y;
  // 元件位置高度至少要 290 才在上方顯示，避免高度不足(往上增長不會有scroll bar)
  needMoveToUp.value = potisionY >= 290 && window.innerHeight - potisionY <= 290;
  tmpSelectedValues.value = JSON.parse(JSON.stringify(selectedValues.value));
  datepicker.show = true;
};

/**
 * 確認並過濾選取日期
 */
const confirmDates = () => {
  // 最後結果
  if (tmpSelectedValues.value.length === props.maximumDays) {
    innerError.value = true;
    innerErrorMessage.value = `最多僅可以被選取${props.maximumDays}天`;
    emits('valueVaildate', innerErrorMessage.value);
    return;
  }

  innerError.value = false;
  innerErrorMessage.value = '';
  selectedValues.value = tmpSelectedValues.value.map((item) => item);
  tmpSelectedValues.value = [];
  datepicker.show = false;
};
</script>
