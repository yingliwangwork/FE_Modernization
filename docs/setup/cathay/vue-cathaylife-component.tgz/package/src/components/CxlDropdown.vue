<template>
  <q-select
    ref="qSelectRef"
    v-model="dropdownValue"
    :options="options"
    behavior="menu"
    options-selected-class="cxl-dropdown-is-selected"
    :optionLabel="optionLabel"
    :optionValue="optionValue"
    :popup-content-class="contentClass"
    :class="[
      // 根據 isTsMode 動態決定根 class
      isTsMode ? 'cxl-dropdown-ts' : 'cxl-dropdown',
      {
        // Ts版
        'cxl-dropdown-ts-error-msg': isTsMode && props.errorMessage,
        'cxl-dropdown-ts-ellipsis-has-value': isTsMode && !!dropdownValue,
        'cxl-dropdown-ts-ellipsis-no-value': isTsMode && !dropdownValue,
        // 一般版
        'cxl-dropdown-error-msg': !isTsMode && props.errorMessage,
        'cxl-dropdown-label-disable': !isTsMode && props.disable,
        // 共用 class
        'cxl-font-eudc': props.showHanlink,
      },
    ]"
    :disable="props.disable"
    :display-value="displayValue"
    dense
    outlined
    options-dense
    hide-bottom-space
    no-error-icon
  >
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
    <template v-if="!$slots.append" #append>
      <span class="cub-icon-chevrondown_24 cxl-font-24"></span>
    </template>
    <template v-if="props.errorMessage && !$slots.error" #error>
      {{ props.errorMessage }}
    </template>
  </q-select>
</template>

<script setup>
import { ref, onMounted, reactive, watch, computed, useAttrs } from 'vue';

const attrs = useAttrs();
// 判斷 class 是否包含 'cxl-dropdown-ts' 來決定模式
const isTsMode = computed(() => attrs.class?.includes('cxl-dropdown-ts'));

const dropdownValue = defineModel({
  type: [String, Number, Object],
  default: '',
});

const props = defineProps({
  options: {
    type: Array,
    default: () => [],
  },
  disable: {
    type: Boolean,
    default: false,
  },
  label: {
    type: String,
    default: '請選擇',
  },
  showHanlink: {
    type: Boolean,
    default: false,
  },
  errorMessage: {
    type: String,
    default: '',
  },
  optionLabel: {
    type: [Function, String],
    default: 'label',
  },
  optionValue: {
    type: [Function, String],
    default: 'value',
  },
});

/**
 * 處裡要顯示在 select 欄位的資料
 * @type {ComputedRef<*>}
 */
const displayValue = computed(() => {
  const options = props.options || [];
  const value = dropdownValue.value;
  const labelKey = props.optionLabel || 'label';
  const valueKey = props.optionValue || 'value';

  const match = options.find((opt) => {
    if (typeof opt === 'object' && opt !== null) {
      return opt[valueKey] === value;
    }
    return opt === value;
  });

  if (match) {
    if (typeof match === 'object' && match !== null) {
      return match[labelKey] ?? value;
    }
    return match;
  }

  return props.label;
});

// 根據 isTsMode 動態決定難字的 class
const contentClass = computed(() => {
  const baseClass = isTsMode.value ? 'cxl-dropdown-ts-options' : 'cxl-dropdown-options';
  return props.showHanlink ? `${baseClass} cxl-font-eudc` : baseClass;
});

const properties = [
  'scrollTo',
  'reset',
  'refresh',
  'resetValidation',
  'validate',
  'focus',
  'blur',
  'showPopup',
  'hidePopup',
  'removeAtIndex',
  'add',
  'toggleOption',
  'getOptionIndex',
  'setOptionIndex',
  'moveOptionSelection',
  'filter',
  'updateMenuPosition',
  'updateInputValue',
  'isOptionSelected',
  'getEmittingOptionValue',
  'getOptionValue',
  'getOptionLabel',
  'isOptionDisabled',
  'hasError',
];

const qSelectRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qSelectRef.value[key];
  });
});

watch(
  () => qSelectRef.value?.hasError,
  (val) => {
    exposedProperties.hasError = val;
  },
);

defineExpose(exposedProperties);
</script>
