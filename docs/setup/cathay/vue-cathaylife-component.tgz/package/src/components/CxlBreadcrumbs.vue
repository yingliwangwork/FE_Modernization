<template>
  <component :is="targetComp" v-bind="props"></component>
</template>

<script setup>
import { shallowRef } from 'vue';
import CxlBreadcrumbsNew from './CxlBreadcrumbsNew.vue';
import CxlBreadcrumbsOld from './CxlBreadcrumbsOld.vue';

const props = defineProps({
  breadcrumbs: {
    type: [Object, Array],
    default: () => [],
  },
  routerPath: {
    type: String,
    default: '/',
  },
  rootPath: {
    type: Object,
    default: null,
  },
});

// 透過傳入屬性判斷是否為 BFF 新版的前端架構, new 等於 BFF 版
const targetComp = shallowRef(
  Array.isArray(props.breadcrumbs) ? CxlBreadcrumbsNew : CxlBreadcrumbsOld,
);
</script>
