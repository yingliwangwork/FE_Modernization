<template>
  <q-breadcrumbs class="cxl-breadcrumbs">
    <!-- 設定箭頭圖示 -->
    <template #separator>
      <div class="triangle-right pc-only"></div>
      <div v-if="isMobileWidth" class="triangle-left"></div>
    </template>
    <!-- 首頁 -->
    <q-breadcrumbs-el
      v-if="props.rootPath && Object.keys(props.rootPath).length !== 0"
      :label="props.rootPath.label"
      :to="props.rootPath.url"
      class="pc-only"
    />
    <template v-if="!isMobileWidth">
      <template v-for="el in breadcrumbEl" :key="el">
        <q-breadcrumbs-el :label="el.label" v-bind="el.url ? { to: el.url } : {}" />
      </template>
    </template>
    <template v-else>
      <!-- 手機模式僅留當頁麵包屑 -->
      <q-breadcrumbs-el
        :label="breadcrumbEl[breadcrumbEl.length - 1].label"
        v-bind="
          breadcrumbEl[breadcrumbEl.length - 1].url
            ? { to: breadcrumbEl[breadcrumbEl.length - 1].url }
            : {}
        "
      />
    </template>
  </q-breadcrumbs>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const props = defineProps({
  breadcrumbs: {
    type: Array,
    default: () => [],
  },
  routerPath: {
    type: String,
    default: '/',
  },
  rootPath: {
    type: Object,
    default: () => {},
  },
});

const isMobileWidth = ref(false);
onMounted(() => {
  isMobileWidth.value = window.innerWidth < 768;
  window.addEventListener('resize', () => {
    isMobileWidth.value = window.innerWidth < 768;
  });
});

/**
 * 找出所有父節點
 * @param {Array} breadcrumbs - 來源資料
 * @param {string} url - 當前頁面的url
 * @returns {Array} 整理完畢的 array
 */
const findPath = (breadcrumbs, url) => {
  for (let i = 0; i < breadcrumbs.length; i++) {
    const item = breadcrumbs[i];
    if (item.url === url) {
      return [{ label: item.label, url: item.url }];
    }
    if (item.items) {
      // 遞迴
      const result = findPath(item.items, url);
      // 往下走且有拿到 result 代表一定有找到 url 相符的子節點
      if (result) {
        return [{ label: item.label, url: item.url }].concat(result);
      }
    }
  }
  return null;
};

const breadcrumbEl = ref(findPath(props.breadcrumbs, props.routerPath));
</script>
