<template>
  <Calendar
    ref="refCxlCalendar"
    v-model="internalValue"
    :calendar="calendar"
    :title="titleBuilder"
    :subtitle="subtitleBuilder"
    class="cxl-date"
    :class="{ 'header-no-events': disableHeaderClick }"
    :default-view="defaultView"
    @update:model-value="onQDateValChange"
  >
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </Calendar>
</template>
<script setup>
import Calendar from '@/components/dateUtils/calendar.js';
import { computed, onMounted, ref, watchEffect } from 'vue';
import { formatToOutput, parseFromInput } from '@/components/dateUtils/CxlCalendarUtils.js';

const modelValue = defineModel();

const internalValue = ref(null);
const props = defineProps({
  mask: {
    type: String,
    default: 'YYYY/MM/DD',
  },
  outputType: {
    type: String,
    default: 'gregorian', // gregorian, ROC
  },
  calendar: {
    type: String,
    default: 'gregorian', // gregorian, ROC
  },
  defaultView: {
    type: String,
    default: 'Calendar',
  },
  pickMode: {
    type: String,
    default: '',
    validator: (v) => ['', 'Years', 'Months', 'YearsMonths'].includes(v),
  },
  title: {
    type: String,
    default: '',
  },
});

const refCxlCalendar = ref(null); // ref
const disableHeaderClick = computed(() =>
  ['Years', 'Months', 'YearsMonths'].includes(props.pickMode),
);

const titleBuilder = computed(() => {
  if (props.title !== '') {
    return props.title;
  }
  if (['Years', 'Months', 'YearsMonths'].includes(props.pickMode)) {
    return '- -';
  }
  return '';
});
const subtitleBuilder = computed(() => {
  if (props.title !== '') {
    return props.title;
  }
  if ('Months' === props.pickMode) {
    return '- -';
  }
  return '';
});

/**
 * 拆解calendar資料結構做文字轉換
 * @param input
 * @param convertFn
 * @returns {{}|*}
 */
const convertDates = (input, convertFn) => {
  if (typeof input === 'string') {
    return convertFn(input);
  }

  if (Array.isArray(input)) {
    return input.map((item) => convertDates(item, convertFn));
  }

  if (!(input && typeof input === 'object')) {
    return input; // null 或 undefined 直接返回
  }

  const result = {};
  Object.keys(input).forEach((k) => {
    result[k] = convertDates(input[k], convertFn);
  });
  return result;
};

onMounted(() => {
  internalValue.value = convertDates(modelValue.value, (str) =>
    parseFromInput(str, props.outputType, props.mask),
  );
});

watchEffect(
  () => modelValue.value,
  (val) => {
    internalValue.value = convertDates(val, (str) =>
      parseFromInput(str, props.outputType, props.mask),
    );
  },
);

const currentView = ref(props.defaultView);
const onQDateValChange = (valFromQDate) => {
  const output = convertDates(valFromQDate, (str) =>
    formatToOutput(str, props.outputType, props.mask),
  );
  if (output !== modelValue.value) {
    modelValue.value = output;
  }

  if (props.pickMode === 'Months') {
    refCxlCalendar.value.setView('Months');
    return;
  }

  if (props.pickMode === 'Years') {
    refCxlCalendar.value.setView('Years');
    return;
  }

  if (props.pickMode === 'YearsMonths') {
    currentView.value = currentView.value == 'Years' ? 'Months' : 'Years';
    refCxlCalendar.value.setView(currentView.value);
  }
};
/**
 * 開放 calendar 方法
 */
defineExpose({
  setToday: (...args) => refCxlCalendar.value?.setToday(...args),
  setView: (...args) => refCxlCalendar.value?.setView(...args),
  offsetCalendar: (...args) => refCxlCalendar.value?.offsetCalendar(...args),
  setCalendarTo: (...args) => refCxlCalendar.value?.setCalendarTo(...args),
  setEditingRange: (...args) => refCxlCalendar.value?.setEditingRange(...args),
});
</script>
