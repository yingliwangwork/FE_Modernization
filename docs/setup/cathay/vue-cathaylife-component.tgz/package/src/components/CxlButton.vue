<template>
  <q-btn
    ref="qBtnRef"
    class="cxl-btn"
    :class="[
      themeClass,
      stackClass,
      { 'has-prev-icon': prevIcon },
      { 'has-next-icon': nextIcon },
      { 'cxl-btn-card': card },
    ]"
    :stack="props.stack"
    flat
  >
    <template #default="slotProps">
      <span v-if="props.prevIcon" class="cxl-font-24" :class="prevIcon"></span>
      <span v-if="props.label">{{ props.label }}</span>
      <span v-if="props.nextIcon" class="cxl-font-24" :class="nextIcon"></span>
      <span v-if="props.number" class="cxl-btn-number">{{ number }}</span>
      <slot name="default" v-bind="slotProps || {}"></slot>
    </template>
    <template v-if="$slots?.loading" #loading="slotProps">
      <slot name="loading" v-bind="slotProps || {}"></slot>
    </template>
  </q-btn>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue';

const props = defineProps({
  label: {
    type: String,
    default: '',
  },
  theme: {
    type: String,
    default: 'primary',
  },
  prevIcon: {
    type: String,
    default: '',
  },
  nextIcon: {
    type: String,
    default: '',
  },
  number: {
    type: String,
    default: '',
  },
  card: {
    type: Boolean,
    default: false,
  },
  stack: {
    type: Boolean,
    default: false,
  },
});

const themeClass = computed(() => `cxl-btn-${props.theme}`);
const stackClass = computed(() => (props.stack ? 'cxl-btn-stack' : ''));

const qBtnRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  exposedProperties.click = qBtnRef.value.click;
});

defineExpose(exposedProperties);
</script>
