<template>
  <q-input
    ref="qInputRef"
    class="cxl-textarea"
    :class="{
      'cxl-input-error-msg': attrs.error,
    }"
    type="textarea"
    outlined
    dense
    hide-bottom-space
    no-error-icon
    :rows="props.rows"
  >
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </q-input>
</template>

<script setup>
import { ref, useAttrs, onMounted, reactive, watch } from 'vue';

const attrs = useAttrs();

const props = defineProps({
  rows: {
    type: String,
    default: '4',
  },
});

const properties = [
  'resetValidation',
  'validate',
  'focus',
  'blur',
  'select',
  'getNativeElement',
  'hasError',
  'nativeEl',
];

const qInputRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qInputRef.value[key];
  });
});

watch(
  () => [qInputRef.value?.hasError, qInputRef.value?.nativeEl],
  ([hasError, nativeEl]) => {
    exposedProperties.hasError = hasError;
    exposedProperties.nativeEl = nativeEl;
  },
);

defineExpose(exposedProperties);
</script>
