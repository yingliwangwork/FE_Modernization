<template>
  <q-dialog class="cxl-modal" :class="sizeClass">
    <q-card>
      <q-bar
        :class="
          !props.disableCloseButton
            ? 'q-pt-md cxl-modal-header__height-48'
            : 'cxl-modal-header__height-24'
        "
      >
        <q-space />
        <span
          v-if="!props.disableCloseButton"
          v-close-popup
          class="cub-icon-close_40_s cxl-font-40 cxl-text-gray-a7"
        ></span>
      </q-bar>
      <q-card-section class="column">
        <div v-if="props.title" class="cxl-modal-title">{{ props.title }}</div>
        <div v-if="props.subtitle" class="cxl-modal-subtitle">
          {{ props.subtitle }}
        </div>
      </q-card-section>

      <q-card-section :class="props.contentScroll ? 'scroll cxl-modal-content' : ''">
        <!-- 內容 -->
        <slot></slot>
      </q-card-section>

      <q-card-actions class="row justify-center">
        <slot name="bottom">
          <CxlButton
            v-if="props.cancelText"
            padding="8px 54px"
            :label="props.cancelText"
            theme="primary-outline"
            @click="cancel()"
          />
          <CxlButton
            v-if="props.confirmText"
            padding="8px 54px"
            :label="props.confirmText"
            @click="confirm()"
          />
        </slot>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { computed } from 'vue';
import CxlButton from './CxlButton.vue';

const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  subtitle: {
    type: String,
    default: '',
  },
  cancelText: {
    type: String,
    default: '',
  },
  confirmText: {
    type: String,
    default: '',
  },
  size: {
    type: String,
    default: 'sm',
  },
  disableCloseButton: {
    type: Boolean,
    default: false,
  },
  contentScroll: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['confirm', 'cancel']);
const confirm = () => {
  emit('confirm');
};

const cancel = () => {
  emit('cancel');
};

// modal 寬度
const sizeClass = computed(() => `cxl-modal-${props.size}`);
</script>
