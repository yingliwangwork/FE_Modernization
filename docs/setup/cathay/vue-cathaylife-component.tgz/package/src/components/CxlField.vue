<template>
  <q-field ref="qFieldRef" class="cxl-field" borderless no-error-icon hide-bottom-space dense>
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </q-field>
</template>
<script setup>
import { ref, onMounted, reactive, watch } from 'vue';

const properties = ['resetValidation', 'validate', 'focus', 'blur', 'hasError'];
const qFieldRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qFieldRef.value[key];
  });
});

watch(
  () => qFieldRef.value?.hasError,
  (val) => {
    exposedProperties.hasError = val;
  },
);

defineExpose(exposedProperties);
</script>
