<template>
  <q-expansion-item
    group="group"
    class="cxl-accordion"
    expand-icon-class="cxl-accordion-icon"
    dense
  >
    <template #header>
      <q-item-section>
        <div class="q-item__label">
          <slot name="header"></slot>
        </div>
      </q-item-section>
    </template>
    <div class="cxl-accordion-card">
      <slot v-if="haveContent" name="content"></slot>
      <p v-else class="fatal-msg"> content slot 為必填 </p>
    </div>
  </q-expansion-item>
</template>
<script setup>
import { computed, useSlots } from 'vue';

const slots = useSlots();
const haveContent = computed(() => {
  return slots?.content;
});
</script>
