<template>
  <span class="cxl-badge" :class="[themeClass, { 'cxl-badge-circle': props.shape === 'circle' }]">
    {{ content }}
  </span>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  // 顏色主題
  theme: {
    type: String,
    default: 'primary',
  },
  // 徽章文字(裡面)
  text: {
    type: String,
    default: '徽章',
  },
  // 形狀：長方形或圓形
  shape: {
    type: String,
    default: 'rectangle',
  },
  // 徽章內顯示的數值最大值
  maxNumber: {
    type: Number,
    default: 99,
  },
});

const themeClass = computed(() => {
  return `cxl-badge-${props.theme}`;
});

const content = computed(() => {
  // 當超過設定數值時，會以"最大值+"顯示。例如：設定最大值為 99，在數值大於 99 時以 99+ 顯示。
  if (props.shape === 'circle' && !isNaN(props.text) && props.text > props.maxNumber) {
    return props.maxNumber + '+';
  }
  return props.text;
});
</script>
