<template>
  <div class="cxl-sub-tabs-ts">
    <q-tabs
      v-model="currentTab"
      align="left"
      content-class="cxl-sub-tabs-ts-area"
      active-class="cxl-sub-tabs-ts-is-selected"
      indicator-color="transparent"
      :breakpoint="0"
      no-caps
    >
      <template v-for="tab in props.tabs" :key="tab">
        <q-tab
          v-if="!tab.hide"
          class="cxl-sub-tab-ts"
          content-class="cxl-sub-tab-ts-content"
          :name="tab.name"
          :label="tab.label"
          :ripple="false"
          :disable="tab.disable"
          @click="buttonClick(tab.name)"
        >
          <q-badge
            v-if="tab.iconType"
            rounded
            class="cxl-sub-tab-badge"
            :class="badgeBgColor(tab.iconType, !tab.number && tab.number !== 0)"
          >
            <span v-if="tab.number || tab.number === 0">
              {{ tab.number }}
            </span>
            <span v-else class="cxl-font-24 cxl-sub-tabs-ts-icon" :class="iconClass(tab.iconType)">
            </span>
          </q-badge>
        </q-tab>
      </template>
    </q-tabs>
    <div v-if="hasTabsAppendSlot" class="cxl-sub-tabs-ts-append-slot">
      <slot name="tabs-append"></slot>
    </div>
  </div>
  <q-tab-panels v-model="currentTab" class="cxl-sub-tab-ts-panels" keep-alive>
    <slot></slot>
  </q-tab-panels>
</template>
<script setup>
import { computed, useSlots } from 'vue';

const currentTab = defineModel('currentTab', { type: String, default: '' });
const slots = useSlots();

const props = defineProps({
  tabs: {
    type: Array,
    default: () => [],
  },
});

const iconClass = (iconType) => {
  return {
    'cxl-icon-disabled-ts cxl-text-gray-a7': iconType === 'disabled',
    'cxl-icon-finish-ts cxl-text-primary': iconType === 'finish',
    'cxl-icon-warning-ts cxl-text-warning-dark': iconType === 'warning',
    'cxl-icon-error-ts cxl-text-danger-dark': iconType === 'error',
    'cxl-icon-info-ts cxl-text-info': iconType === 'info',
  };
};

const badgeBgColor = (iconType, isOnlyIcon) => {
  if (isOnlyIcon) {
    return {};
  }
  return {
    'cxl-bg-gray-a7': iconType === 'disabled',
    'cxl-bg-primary': iconType === 'finish',
    'cxl-bg-warning-dark': iconType === 'warning',
    'cxl-bg-danger-dark': iconType === 'error',
    'cxl-bg-info': iconType === 'info',
  };
};

// 檢測是否有 'tabs-append' slot
const hasTabsAppendSlot = computed(() => {
  return !!slots['tabs-append'];
});

const emit = defineEmits(['buttonClick']);
// 用來實作 add tabs 用的 method
const buttonClick = (val) => {
  emit('buttonClick', val);
};
</script>
