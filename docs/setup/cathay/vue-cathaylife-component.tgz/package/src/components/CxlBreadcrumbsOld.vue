<template>
  <q-breadcrumbs class="cxl-breadcrumbs">
    <!-- 設定箭頭圖示 -->
    <template #separator>
      <div class="triangle-right pc-only"></div>
      <div v-if="isMobileWidth" class="triangle-left"></div>
    </template>
    <!-- 首頁 -->
    <q-breadcrumbs-el :label="homeName" :to="homeUrl" class="pc-only" />
    <template v-if="!isMobileWidth">
      <template v-for="el in breadcrumbEl[props.routerPath]" :key="el">
        <q-breadcrumbs-el :label="el.name" />
      </template>
    </template>
    <template v-else-if="breadcrumbEl[props.routerPath]">
      <!-- 手機模式僅留當頁標籤 -->
      <q-breadcrumbs-el
        :label="breadcrumbEl[props.routerPath][0].name"
        :to="breadcrumbEl[props.routerPath][0].url"
      />
    </template>
  </q-breadcrumbs>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';

const props = defineProps({
  breadcrumbs: {
    type: Object,
    default: () => {},
  },
  routerPath: {
    type: String,
    default: '/',
  },
  rootPath: {
    type: Object,
    default: null,
  },
});

const isMobileWidth = ref(false);
onMounted(() => {
  isMobileWidth.value = window.innerWidth < 768;
  window.addEventListener('resize', () => {
    isMobileWidth.value = window.innerWidth < 768;
  });
});

const generatePath = () => {
  const output = {};
  props.breadcrumbs.menu.forEach(function (item) {
    if (item.subMenu) {
      item.subMenu.forEach(function (subItem) {
        output[subItem.url] = output[subItem.url] || [];
        output[subItem.url].push({ name: item.name }, { name: subItem.name, url: subItem.url });
      });
    }
  });
  return output;
};

const breadcrumbEl = ref(generatePath());

const homeName = computed(
  () => props.rootPath?.name || props.breadcrumbs.home?.name || props.breadcrumbs.info?.name,
);
const homeUrl = computed(
  () => props.rootPath?.url || props.breadcrumbs.home?.url || props.breadcrumbs.info?.url,
);
</script>
