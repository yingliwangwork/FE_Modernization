<template>
  <q-expansion-item
    class="cxl-accordion-ts"
    expand-icon-class="cxl-accordion-ts-icon"
    :headerClass="headerClass"
    dense
  >
    <template #header>
      <div class="col row items-center justify-between">
        <div v-if="labelName" class="row no-wrap items-center" :class="labelClass">
          <span
            v-if="labelIconClass.length"
            class="cxl-font-22 q-mr-md"
            :class="labelIconClass"
          ></span>
          <span>{{ labelName }}</span>
        </div>
        <slot name="headerLeft"></slot>
        <div
          v-if="title"
          class="q-item__label row items-center justify-center cxl-accordion-ts-title"
          :class="titleClass"
        >
          {{ title }}
        </div>
        <div v-if="$slots.headerRight" class="col">
          <slot name="headerRight"></slot>
        </div>
      </div>
    </template>
    <div class="cxl-accordion-ts-card">
      <slot></slot>
    </div>
  </q-expansion-item>
</template>
<script setup>
import { computed } from 'vue';

const props = defineProps({
  mode: {
    type: String,
    default: 'main',
  },
  title: {
    type: String,
    default: '',
  },
  titleClass: {
    type: Array,
    default: () => [],
  },
  labelClass: {
    type: Array,
    default: () => [],
  },
  labelIconClass: {
    type: Array,
    default: () => [],
  },
  labelName: {
    type: String,
    default: '',
  },
});

/**
 * 替換不同樣式，分別為 main（原始）、sub、aux
 */
const headerClass = computed(() => {
  const base = 'cxl-accordion-ts-header';
  if (props.mode === 'sub') {
    return [base, 'cxl-accordion-ts-header-sub'];
  }
  if (props.mode === 'aux') {
    return [base, 'cxl-accordion-ts-header-aux'];
  }
  return base;
});
</script>
