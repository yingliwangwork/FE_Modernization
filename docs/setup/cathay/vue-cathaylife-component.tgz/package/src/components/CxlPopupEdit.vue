<template>
  <q-popup-edit ref="qPopupEditRef">
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </q-popup-edit>
</template>
<script setup>
import { ref, onMounted, reactive } from 'vue';

const properties = ['set', 'cancel', 'show', 'hide', 'updatePosition'];
const qPopupEditRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qPopupEditRef.value[key];
  });
});

defineExpose(exposedProperties);
</script>
