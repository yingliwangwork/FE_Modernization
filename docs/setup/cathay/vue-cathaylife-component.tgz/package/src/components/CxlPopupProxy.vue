<template>
  <q-popup-proxy ref="qPopupProxyRef" v-bind="$attrs">
    <template v-for="(slotContent, slotName) in $slots" #[slotName]="slotProps">
      <slot :name="slotName" v-bind="slotProps || {}"></slot>
    </template>
  </q-popup-proxy>
</template>
<script setup>
import { ref, onMounted, reactive, watch } from 'vue';

defineOptions({
  inheritAttrs: false,
});

const properties = ['show', 'hide', 'toggle', 'currentComponent'];
const qPopupProxyRef = ref(null);
const exposedProperties = reactive({});
onMounted(() => {
  properties.forEach((key) => {
    exposedProperties[key] = qPopupProxyRef.value[key];
  });
});

watch(
  () => qPopupProxyRef.value?.currentComponent,
  (val) => {
    exposedProperties.currentComponent = val;
  },
);

defineExpose(exposedProperties);
</script>
