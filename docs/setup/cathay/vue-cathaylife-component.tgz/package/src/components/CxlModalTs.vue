<template>
  <q-dialog v-model="showDialog" class="cxl-modal-ts" :class="sizeClass">
    <q-card>
      <!-- Header -->
      <q-bar class="cxl-modal-ts-header">
        <div class="cxl-modal-ts-header-title text-center text-h6">
          <slot name="header-title">{{ title }}</slot>
        </div>
        <span
          v-if="!props.disableCloseButton"
          v-close-popup
          class="cxl-modal-ts-close cxl-icon-close-ts cxl-font-40 cxl-text-gray-a7"
        ></span>
      </q-bar>
      <!-- 標題下方敘述 -->
      <div v-if="props.showHeaderContent" class="cxl-modal-ts-description">
        <slot name="header-text"></slot>
      </div>

      <!-- Content -->
      <q-card-section class="cxl-modal-ts-content">
        <!-- 帶有內建表單 -->
        <div v-if="useFormLayout" class="cxl-modal-ts-content-form" :style="contentFormStyle">
          <!-- 陰影容器 -->
          <div class="cxl-modal-ts-form" :class="tableContainerClasses">
            <!-- 內建表格 -->
            <q-markup-table
              class="cxl-table cxl-table-ts cxl-table-horizontal cxl-table-ts-search"
              square
              bordered
              flat
              separator="cell"
            >
              <tbody>
                <tr>
                  <th class="text-center cxl-modal-ts-search-title">{{ searchTitle }}</th>
                  <td class="cxl-modal-ts-search-input">
                    <CxlInput v-model="searchValue" class="cxl-input-ts" v-bind="searchAttrs">
                      <template v-if="showSearchButton" #after>
                        <CxlButton
                          theme="primary-outline"
                          class="cxl-btn-ts"
                          @click="$emit('submit')"
                        >
                          <span class="q-ml-xs">{{ searchBtnText }}</span>
                        </CxlButton>
                      </template>
                    </CxlInput>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>

            <!-- 使用者傳入的內容 -->
            <div class="cxl-modal-ts-form-slot">
              <slot></slot>
            </div>
          </div>
        </div>

        <!-- 全版 Slot -->
        <div
          v-else
          class="cxl-modal-ts-content-full"
          :class="contentWrapperClasses"
          :style="contentFormStyle"
        >
          <slot></slot>
        </div>
      </q-card-section>

      <!-- footer 敘述 -->
      <div v-if="props.showFooterDescription" class="cxl-modal-ts-footer-description">
        <slot name="footer-text">
          {{ footerDescription }}
        </slot>
      </div>

      <!-- Footer -->
      <q-card-actions class="cxl-modal-ts-footer" :class="footerClasses">
        <div>{{ footerTitle }}</div>
        <slot name="footer">
          <!-- 預設按鈕 -->
          <CxlButton
            v-if="showConfirmButton"
            class="cxl-btn-ts"
            theme="primary"
            :label="confirmText"
            @click="$emit('confirm')"
          />
        </slot>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>
<script setup>
import { useSlots, computed } from 'vue';
import CxlButton from './CxlButton.vue';
import CxlInput from './CxlInput.vue';

const showDialog = defineModel({ type: Boolean, default: false });
const searchValue = defineModel('searchValue', { type: [String, Number], default: '' });

const props = defineProps({
  title: {
    type: String,
    default: '預設標題',
  },
  confirmText: {
    type: String,
    default: '確認',
  },
  showSearchButton: { type: Boolean, default: false },
  searchBtnText: {
    type: String,
    default: '查詢',
  },
  searchTitle: { type: String, default: '請輸入查詢' },
  searchAttrs: { type: Object, default: () => ({ placeholder: '請輸入關鍵字' }) },
  noPadding: { type: Boolean, default: false },
  useFormLayout: {
    type: Boolean,
    default: false,
  },
  contentCenter: {
    type: Boolean,
    default: false,
  },
  contentShadow: {
    type: Boolean,
    default: false,
  },
  showConfirmButton: {
    type: Boolean,
    default: true,
  },
  size: {
    type: String,
    default: 'sm',
  },
  disableCloseButton: {
    type: Boolean,
    default: false,
  },
  showHeaderContent: {
    type: Boolean,
    default: false,
  },
  contentPadding: {
    type: String,
    default: '',
  },
  contentSetMinHeight: {
    type: Boolean,
    default: false,
  },
  showFooterDescription: {
    type: Boolean,
    default: false,
  },
  footerDescription: {
    type: String,
    default: '',
  },
  footerTitle: {
    type: String,
    default: '',
  },
});

const slots = useSlots();

// 判斷 Footer 是否完全沒有內容
const isFooterEmpty = computed(() => !props.showConfirmButton && !slots.footer);

const footerClasses = computed(() => ({
  'no-padding': isFooterEmpty.value,
}));

const tableContainerClasses = computed(() => ({
  'cxl-modal-ts-content-shadow': props.contentShadow,
}));

const contentWrapperClasses = computed(() => ({
  'items-center justify-center': props.contentCenter,
  'no-padding': props.noPadding,
}));

defineEmits(['submit', 'confirm']);

// modal 寬度
const sizeClass = computed(() => `cxl-modal-ts-${props.size}`);

const contentFormStyle = computed(() => {
  return {
    ...(props.contentPadding ? { padding: props.contentPadding } : {}),
    ...(props.contentSetMinHeight ? { minHeight: '470px' } : {}),
  };
});
</script>
