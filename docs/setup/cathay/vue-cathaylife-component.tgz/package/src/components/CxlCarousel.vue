<template>
  <q-carousel
    v-model="model"
    class="cxl-carousel"
    :autoplay="selfAutoplay"
    @mouseenter="mouseEnterAction"
    @mouseleave="mouseLeaveAction"
  >
    <slot>
      <!-- 如果沒有給 slot 就透過 props.datas 產出default版本-->
      <template v-for="data in props.datas" :key="data">
        <q-carousel-slide :name="data.name" :img-src="data.img" />
      </template>
    </slot>
  </q-carousel>
</template>
<script setup>
import { ref } from 'vue';

// 第幾張輪播
const model = defineModel({ type: [Number, String], default: '1' });

const props = defineProps({
  datas: { type: Array, default: () => [] },
  autoplay: { type: [Number, Boolean], default: true },
  mouseKeepAutoplay: {
    type: Boolean,
    default: false,
  },
});

// 輪播秒數
const selfAutoplay = ref(props.autoplay);

const mouseEnterAction = () => {
  if (!props.mouseKeepAutoplay) {
    selfAutoplay.value = false;
  }
};
const mouseLeaveAction = () => {
  if (!props.mouseKeepAutoplay) {
    selfAutoplay.value = props.autoplay;
  }
};
</script>
