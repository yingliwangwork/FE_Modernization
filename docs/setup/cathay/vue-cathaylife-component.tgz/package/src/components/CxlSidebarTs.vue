<template>
  <q-menu v-model="showing" class="cxl-sidebar-ts">
    <q-list class="cxl-font-20">
      <template v-for="(item, index) in props.items" :key="`${index}${item.label}`">
        <q-item clickable @click="handleItemClick(item.action)">
          <q-item-section v-if="item.prevIcon" class="q-pr-xs" side>
            <q-icon :class="item.prevIcon" />
          </q-item-section>
          <q-item-section>{{ item.label }}</q-item-section>
        </q-item>
        <q-separator v-if="index < props.items.length - 1" />
      </template>
    </q-list>
  </q-menu>
</template>
<script setup>
const showing = defineModel({ type: Boolean, default: false });

const props = defineProps({
  items: {
    type: Array,
    default: () => [],
  },
  keepMenuOpen: {
    type: Boolean,
    default: false,
  },
});

/**
 * 執行外部傳來的方法
 * @param {Function} action click 方法內容
 */
const handleItemClick = (action) => {
  if (typeof action === 'function') {
    action();
  }

  // 根據 props 的值來決定是否要點擊後關閉選單
  if (!props.keepMenuOpen) {
    showing.value = false;
  }
};
</script>
